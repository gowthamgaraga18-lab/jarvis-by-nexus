-- ============================================================================
-- JARVIS AI — Supabase schema
-- Run this in the Supabase SQL editor (Dashboard → SQL Editor → New query).
-- It is idempotent: safe to re-run.
--
-- Model: single-user "Operator" app. All rows carry user_id = the fixed
-- OPERATOR_ID below. RLS is ENABLED on every table, with a permissive policy
-- that allows the anon key (and service role) to read/write all rows. This is
-- honest for a single-user local app where the database is the owner's own
-- Supabase project. For a true multi-user deployment, replace the
-- `USING (true)` policies with `USING (user_id = auth.uid())` and wire up
-- Supabase Auth.
-- ============================================================================

-- The fixed Operator UUID (must match src/lib/supabase.ts OPERATOR_ID).
-- 00000000-0000-0000-0000-000000000001

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- Profiles
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id          uuid primary key,
  email       text not null,
  display_name text not null default 'Operator',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

insert into public.profiles (id, email, display_name)
values ('00000000-0000-0000-0000-000000000001', 'operator@jarvis.local', 'Operator')
on conflict (id) do nothing;

-- ---------------------------------------------------------------------------
-- Conversations & messages
-- ---------------------------------------------------------------------------
create table if not exists public.conversations (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles(id) on delete cascade,
  title      text not null default 'New conversation',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists conversations_user_id_idx on public.conversations(user_id);
create index if not exists conversations_updated_at_idx on public.conversations(updated_at desc);

create table if not exists public.messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  role            text not null check (role in ('user','assistant','system')),
  content         text not null,
  created_at      timestamptz not null default now()
);
create index if not exists messages_conversation_id_idx on public.messages(conversation_id);
create index if not exists messages_created_at_idx on public.messages(created_at);

-- ---------------------------------------------------------------------------
-- Tasks
-- ---------------------------------------------------------------------------
create table if not exists public.tasks (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.profiles(id) on delete cascade,
  title        text not null,
  description  text not null default '',
  priority     text not null default 'medium' check (priority in ('low','medium','high')),
  status       text not null default 'todo' check (status in ('todo','in_progress','done')),
  category     text not null default '',
  due_date     timestamptz,
  project_id   uuid,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  completed_at timestamptz
);
create index if not exists tasks_user_id_idx on public.tasks(user_id);
create index if not exists tasks_status_idx on public.tasks(status);
create index if not exists tasks_due_date_idx on public.tasks(due_date);
create index if not exists tasks_project_id_idx on public.tasks(project_id);

-- ---------------------------------------------------------------------------
-- Notes
-- ---------------------------------------------------------------------------
create table if not exists public.notes (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles(id) on delete cascade,
  title      text not null,
  content    text not null default '',
  project_id uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists notes_user_id_idx on public.notes(user_id);
create index if not exists notes_updated_at_idx on public.notes(updated_at desc);
create index if not exists notes_project_id_idx on public.notes(project_id);

-- ---------------------------------------------------------------------------
-- Projects
-- ---------------------------------------------------------------------------
create table if not exists public.projects (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id) on delete cascade,
  name        text not null,
  description text not null default '',
  goal        text not null default '',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists projects_user_id_idx on public.projects(user_id);

-- FK from tasks/notes to projects (added after table creation so it survives
-- re-runs). Drop first to avoid "already exists" on re-run.
do $$
begin
  if not exists (
    select 1 from information_schema.table_constraints
    where constraint_name = 'tasks_project_id_fkey' and table_name = 'tasks'
  ) then
    alter table public.tasks
      add constraint tasks_project_id_fkey
      foreign key (project_id) references public.projects(id) on delete set null;
  end if;
  if not exists (
    select 1 from information_schema.table_constraints
    where constraint_name = 'notes_project_id_fkey' and table_name = 'notes'
  ) then
    alter table public.notes
      add constraint notes_project_id_fkey
      foreign key (project_id) references public.projects(id) on delete set null;
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- Preferences (settings + memory)
-- ---------------------------------------------------------------------------
create table if not exists public.preferences (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles(id) on delete cascade,
  category   text not null default 'settings' check (category in ('settings','memory')),
  key        text not null,
  value      text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, category, key)
);
create index if not exists preferences_user_category_idx on public.preferences(user_id, category);

-- ---------------------------------------------------------------------------
-- Audit events
-- ---------------------------------------------------------------------------
create table if not exists public.audit_events (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles(id) on delete cascade,
  tool_name  text not null,
  input      text not null default '',
  result     text not null default '',
  status     text not null default 'success' check (status in ('success','denied','error')),
  created_at timestamptz not null default now()
);
create index if not exists audit_events_user_id_idx on public.audit_events(user_id);
create index if not exists audit_events_created_at_idx on public.audit_events(created_at desc);

-- ---------------------------------------------------------------------------
-- Row Level Security
-- ---------------------------------------------------------------------------
alter table public.profiles     enable row level security;
alter table public.conversations enable row level security;
alter table public.messages     enable row level security;
alter table public.tasks         enable row level security;
alter table public.notes         enable row level security;
alter table public.projects     enable row level security;
alter table public.preferences  enable row level security;
alter table public.audit_events  enable row level security;

-- Permissive policies for the single-user Operator model. The anon key (and
-- service role) can read/write all rows. Replace with
-- `using (user_id = auth.uid())` for multi-user + Supabase Auth.
do $$
declare t text;
begin
  foreach t in array array['profiles','conversations','messages','tasks','notes','projects','preferences','audit_events'] loop
    begin
      execute format('create policy %I on public.%I for all using (true) with check (true);', t || '_all', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;

-- updated_at trigger helper
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

do $$
declare t text;
begin
  foreach t in array array['profiles','conversations','tasks','notes','projects','preferences'] loop
    begin
      execute format('drop trigger if exists %I on public.%I;', t || '_touch', t);
      execute format('create trigger %I before update on public.%I for each row execute function public.touch_updated_at();', t || '_touch', t);
    exception when others then null;
    end;
  end loop;
end $$;

-- Default settings rows for the Operator (idempotent).
insert into public.preferences (user_id, category, key, value) values
  ('00000000-0000-0000-0000-000000000001', 'settings', 'model', 'auto'),
  ('00000000-0000-0000-0000-000000000001', 'settings', 'responseStyle', 'balanced'),
  ('00000000-0000-0000-0000-000000000001', 'settings', 'voiceEnabled', 'true'),
  ('00000000-0000-0000-0000-000000000001', 'settings', 'ttsVoice', 'default'),
  ('00000000-0000-0000-0000-000000000001', 'settings', 'ttsRate', '1'),
  ('00000000-0000-0000-0000-000000000001', 'settings', 'theme', 'dark'),
  ('00000000-0000-0000-0000-000000000001', 'settings', 'reducedMotion', 'false'),
  ('00000000-0000-0000-0000-000000000001', 'settings', 'memoryEnabled', 'true')
on conflict (user_id, category, key) do nothing;
