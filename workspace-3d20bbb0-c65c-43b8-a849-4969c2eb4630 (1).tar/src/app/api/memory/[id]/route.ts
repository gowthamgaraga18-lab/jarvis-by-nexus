import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { deleteMemory } from "@/lib/data";

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  try {
    await deleteMemory(id);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to delete." }, { status: 500 });
  }
}
