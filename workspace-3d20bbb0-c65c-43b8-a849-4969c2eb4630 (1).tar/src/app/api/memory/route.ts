import { NextResponse } from "next/server";
import { getCurrentUser, requireUser } from "@/lib/auth";
import { getMemory, saveMemory as saveMemoryRow, clearMemory } from "@/lib/data";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  try {
    const memory = await getMemory();
    return NextResponse.json({ ok: true, memory });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to load memory." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const { key, value } = body ?? {};
  try {
    const k = String(key ?? "").trim().slice(0, 80);
    const v = String(value ?? "").trim().slice(0, 2000);
    if (!k || !v) return NextResponse.json({ ok: false, error: "Key and value are required." }, { status: 400 });
    const entry = await saveMemoryRow(k, v);
    return NextResponse.json({ ok: true, entry });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to save." }, { status: 500 });
  }
}

export async function DELETE() {
  await requireUser();
  try {
    await clearMemory();
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to clear." }, { status: 500 });
  }
}
