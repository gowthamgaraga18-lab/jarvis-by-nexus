import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { visionChat } from "@/lib/jarvis-ai";

// POST /api/vision  { image (data URL or http URL), prompt? } -> { ok, description }
export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const image = typeof body.image === "string" ? body.image.trim() : "";
  if (!image) return NextResponse.json({ ok: false, error: "Image is required." }, { status: 400 });
  // Validate it's a URL or a reasonable base64 data URL (cap size to ~6MB).
  if (!image.startsWith("http") && !image.startsWith("data:image/")) {
    return NextResponse.json({ ok: false, error: "Image must be a URL or a data:image/... URL." }, { status: 400 });
  }
  if (image.startsWith("data:") && image.length > 6_000_000) {
    return NextResponse.json({ ok: false, error: "Image too large (max ~4.5MB)." }, { status: 413 });
  }
  const prompt = typeof body.prompt === "string" && body.prompt.trim() ? body.prompt.trim() : "Describe this image in detail.";
  try {
    const description = await visionChat(prompt, image);
    return NextResponse.json({ ok: true, description });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Vision failed." }, { status: 502 });
  }
}
