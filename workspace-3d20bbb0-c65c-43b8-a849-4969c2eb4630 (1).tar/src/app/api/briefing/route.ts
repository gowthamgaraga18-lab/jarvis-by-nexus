import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { listTasks, countTasks, listProjects } from "@/lib/data";
import { chatCompletion } from "@/lib/jarvis-ai";
import type { Task } from "@/lib/types";

// GET /api/briefing — daily briefing from the user's REAL stored data.
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });

  const now = new Date();
  const startOfDay = new Date(now); startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(now); endOfDay.setHours(23, 59, 59, 999);
  const in7 = new Date(now.getTime() + 7 * 86400000);

  try {
    const tasksToday = (await listTasks({ view: "today" })).slice(0, 8);
    const upcoming = (await listTasks({ view: "upcoming" })).slice(0, 8);
    const overdue = (await listTasks({})).filter((t) => t.status !== "done" && t.dueDate && new Date(t.dueDate) < startOfDay).slice(0, 8);
    const totalOpen = await countTasks({ statusNot: "done" });
    const totalDone = await countTasks({ status: "done" });
    const projects = await listProjects({});

    const projectLines = projects.length
      ? projects.map((p) => `- ${p.name}: ${p.completedTaskCount}/${p.taskCount} tasks (${p.progress}%)`).join("\n")
      : "Projects: none";
    const taskLines = (label: string, list: Task[]) =>
      list.length ? `${label}:\n` + list.map((t) => `- ${t.title}${t.priority === "high" ? " (high)" : ""}`).join("\n") : `${label}: none`;
    const summary = [
      taskLines("Today", tasksToday),
      taskLines("Upcoming (7d)", upcoming),
      taskLines("Overdue", overdue),
      `Open tasks: ${totalOpen} • Completed: ${totalDone}`,
      projectLines,
    ].join("\n\n");

    let narrative: string | null = null;
    let narrativeError: string | null = null;
    try {
      narrative = await chatCompletion(
        [
          {
            role: "system",
            content:
              "You are JARVIS giving the user a concise, motivating daily briefing based ONLY on the real task/project data provided. Do not invent calendar events, news, weather, or any data not present. If a section is empty, say so briefly. Keep it under 120 words. Use a calm, capable tone.",
          },
          { role: "user", content: `User display name: ${user.displayName}\n\n${summary}` },
        ],
        { maxTokens: 500 }
      );
    } catch (e) {
      narrativeError = e instanceof Error ? e.message : String(e);
    }

    return NextResponse.json({
      ok: true,
      briefing: {
        greeting: `Good ${hourGreeting(now)}, ${user.displayName}.`,
        narrative,
        narrativeError,
        counts: { totalOpen, totalDone, overdue: overdue.length, today: tasksToday.length, upcoming: upcoming.length },
        tasksToday: tasksToday.map(serializeTask),
        upcoming: upcoming.map(serializeTask),
        overdue: overdue.map(serializeTask),
        projects: projects.map((p) => ({ id: p.id, name: p.name, progress: p.progress ?? 0 })),
      },
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Briefing failed." }, { status: 500 });
  }
}

function hourGreeting(d: Date): string {
  const h = d.getHours();
  if (h < 12) return "morning";
  if (h < 18) return "afternoon";
  return "evening";
}

function serializeTask(t: Task) {
  return { id: t.id, title: t.title, priority: t.priority, status: t.status, category: t.category, dueDate: t.dueDate };
}
