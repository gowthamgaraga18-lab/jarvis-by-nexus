import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { pingZai, AVAILABLE_MODELS } from "@/lib/jarvis-ai";
import { isSupabaseConfigured, OPERATOR_ID } from "@/lib/supabase";
import { probeTables } from "@/lib/data";
import type { ConnectionStatus } from "@/lib/types";

// Honest connectivity + capability status. ?probe=1 performs a live z.ai test.
export async function GET(req: Request) {
  const user = await getCurrentUser();
  const probe = new URL(req.url).searchParams.get("probe") === "1";

  let zai: ConnectionStatus = {
    id: "zai",
    name: "z.ai Model (chat, TTS, ASR)",
    description: "Conversational brain via z-ai-web-dev-sdk.",
    status: "connected",
    detail: "Configured via /etc/.z-ai-config (SDK auto-loaded).",
  };
  if (probe) {
    const p = await pingZai();
    zai = { ...zai, status: p.ok ? "connected" : "error", detail: p.ok ? "Responded to a live test prompt." : p.detail };
  }

  // Supabase: reflect the REAL state of the connection + schema.
  const sbConfigured = isSupabaseConfigured();
  let supabase: ConnectionStatus;
  if (!sbConfigured) {
    supabase = {
      id: "supabase",
      name: "Supabase",
      description: "Database backend (profiles, tasks, notes, projects, conversations, memory, audit).",
      status: "not_configured",
      detail: "NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY are not set.",
    };
  } else {
    let schemaReady = false;
    let tables: string[] = [];
    try {
      const probeRes = await probeTables();
      schemaReady = probeRes.ready;
      tables = probeRes.tables;
    } catch {
      /* ignore */
    }
    supabase = {
      id: "supabase",
      name: "Supabase",
      description: "Database backend (profiles, tasks, notes, projects, conversations, memory, audit).",
      status: schemaReady ? "connected" : "error",
      detail: schemaReady
        ? `Project ${process.env.NEXT_PUBLIC_SUPABASE_URL?.replace("https://", "").replace(".supabase.co", "")} — all 8 tables ready. Operator id ${OPERATOR_ID}.`
        : `Project reachable but schema not applied. Run supabase/schema.sql in the Supabase SQL editor. (Found ${tables.length}/8 tables.)`,
    };
  }

  const connections: ConnectionStatus[] = [
    zai,
    supabase,
    {
      id: "browser_stt",
      name: "Browser Speech Recognition",
      description: "Push-to-talk microphone input via Web Speech API.",
      status: "connected",
      detail: "Provided by the browser when supported. Permission requested on first use.",
    },
    {
      id: "browser_tts",
      name: "Browser Speech Synthesis",
      description: "Spoken answers via Web Speech API.",
      status: "connected",
      detail: "Provided by the browser when supported. A z.ai TTS fallback is also available.",
    },
  ];

  return NextResponse.json({ ok: true, user: user ?? null, connections, models: AVAILABLE_MODELS });
}
