import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { generateImage, type ImageSize } from "@/lib/jarvis-ai";

// POST /api/images/generate  { prompt, size? } -> { ok, images: [dataUrl...] }
export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  if (prompt.length < 3) return NextResponse.json({ ok: false, error: "Prompt must be at least 3 characters." }, { status: 400 });
  const size = (body.size as ImageSize) ?? "1024x1024";
  const allowed = ["1024x1024", "768x1344", "864x1152", "1344x768", "1152x864", "1440x720", "720x1440"];
  if (!allowed.includes(size)) return NextResponse.json({ ok: false, error: "Unsupported size." }, { status: 400 });
  try {
    const images = await generateImage(prompt, size);
    if (images.length === 0) return NextResponse.json({ ok: false, error: "No image returned." }, { status: 502 });
    return NextResponse.json({ ok: true, images });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Image generation failed." }, { status: 502 });
  }
}
