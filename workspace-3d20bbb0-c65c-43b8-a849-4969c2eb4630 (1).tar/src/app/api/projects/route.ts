import { NextResponse } from "next/server";
import { getCurrentUser, requireUser } from "@/lib/auth";
import { listProjects, createProject } from "@/lib/data";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const q = url.searchParams.get("q") ?? "";
  try {
    const projects = await listProjects({ q: q || undefined });
    return NextResponse.json({ ok: true, projects });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to load projects." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const { name, description, goal } = body ?? {};
  if (!name || typeof name !== "string") return NextResponse.json({ ok: false, error: "Name is required." }, { status: 400 });
  try {
    const project = await createProject({ name, description, goal });
    return NextResponse.json({ ok: true, project });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to create project." }, { status: 500 });
  }
}
