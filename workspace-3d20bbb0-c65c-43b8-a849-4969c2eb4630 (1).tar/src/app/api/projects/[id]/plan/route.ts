import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { getProject } from "@/lib/data";
import { chatCompletion } from "@/lib/jarvis-ai";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  try {
    const project = await getProject(id);
    if (!project) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
    const taskLines = project.tasks.length
      ? project.tasks.map((t) => `- [${t.status}] ${t.title}${t.dueDate ? ` (due ${t.dueDate.slice(0, 10)})` : ""}`).join("\n")
      : "(no tasks yet)";
    const plan = await chatCompletion(
      [
        {
          role: "system",
          content:
            "You are JARVIS. The user wants a milestone plan for a project. Produce a concrete, ordered plan in markdown. Suggest 3-6 milestones. For each, give a short name, a one-line objective, and 1-3 suggested tasks. Mark which tasks already exist. Do not invent external deadlines or people. End with a one-line 'Next step' suggestion. This is a draft — do not claim it has been saved.",
        },
        {
          role: "user",
          content:
            `Project: ${project.name}\nGoal: ${project.goal || "(not set)"}\nDescription: ${project.description || "(none)"}\n\nExisting tasks:\n${taskLines}`,
        },
      ],
      { maxTokens: 1200 }
    );
    return NextResponse.json({ ok: true, plan });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Planning failed." }, { status: 502 });
  }
}
