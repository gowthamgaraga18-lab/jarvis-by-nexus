import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { webSearch, type WebSearchResult } from "@/lib/jarvis-ai";

// POST /api/search  { query, num?, recencyDays? } -> { ok, results: [...] }
export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const query = typeof body.query === "string" ? body.query.trim() : "";
  if (query.length < 2) return NextResponse.json({ ok: false, error: "Query too short." }, { status: 400 });
  const num = Math.min(Math.max(Number(body.num) || 5, 1), 10);
  const recencyDays = body.recencyDays ? Math.min(Math.max(Number(body.recencyDays), 1), 365) : undefined;
  try {
    const results: WebSearchResult[] = await webSearch(query, num, recencyDays);
    return NextResponse.json({ ok: true, results });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Web search failed." }, { status: 502 });
  }
}
