import { requireUser } from "@/lib/auth";
import { streamChatCompletion } from "@/lib/jarvis-ai";
import { buildSystemPrompt } from "@/lib/prompt";
import { parseToolCalls } from "@/lib/prompt";
import type { ZaiChatMessage } from "@/lib/jarvis-ai";
import { createConversation, addMessage, listMessages, touchConversation, getConversation } from "@/lib/data";

// POST /api/chat/send  (Server-Sent Events stream)
// Body: { conversationId?: string, message: string }
export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch {
    return new Response(JSON.stringify({ ok: false, error: "Invalid JSON." }), { status: 400, headers: { "Content-Type": "application/json" } });
  }
  const { conversationId, message } = body ?? {};
  const userText = typeof message === "string" ? message.slice(0, 8000) : "";
  if (!userText.trim()) {
    return new Response(JSON.stringify({ ok: false, error: "Empty message." }), { status: 400, headers: { "Content-Type": "application/json" } });
  }

  // Load or create the conversation.
  let convId = typeof conversationId === "string" ? conversationId : null;
  if (convId) {
    const owned = await getConversation(convId);
    if (!owned) convId = null;
  }
  if (!convId) {
    const title = userText.slice(0, 50).replace(/\s+/g, " ").trim() || "New conversation";
    try {
      const conv = await createConversation(title);
      convId = conv.id;
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to start conversation.";
      return new Response(JSON.stringify({ ok: false, error: msg }), { status: 500, headers: { "Content-Type": "application/json" } });
    }
  }

  // Persist the user's message.
  try {
    await addMessage(convId, "user", userText);
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Failed to persist message.";
    return new Response(JSON.stringify({ ok: false, error: msg }), { status: 500, headers: { "Content-Type": "application/json" } });
  }

  // Load recent history for context (last ~12 messages).
  const history = await listMessages(convId);
  const recent = history.slice(-13);
  const { system, model } = await buildSystemPrompt("operator");

  const msgs: ZaiChatMessage[] = [{ role: "system", content: system }];
  for (const m of recent) {
    msgs.push({ role: m.role as "user" | "assistant", content: m.content });
  }
  if (msgs[msgs.length - 1].role !== "user" || msgs[msgs.length - 1].content !== userText) {
    msgs.push({ role: "user", content: userText });
  }

  const abort = new AbortController();
  req.signal?.addEventListener("abort", () => abort.abort());

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (obj: Record<string, unknown>) => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));
      };
      send({ type: "conv", conversationId: convId });

      let full = "";
      let started = 0;
      try {
        await streamChatCompletion(msgs, { model, temperature: 0.7 }, {
          onDelta(delta) {
            full += delta;
            const { prose, calls } = parseToolCalls(full);
            if (calls.length) {
              for (const c of calls) send({ type: "tool", tool: c.tool, input: c.input });
              if (prose && prose.length > started) {
                send({ type: "delta", text: prose.slice(started) });
                started = prose.length;
              }
              full = "";
            } else {
              if (full.length > started) {
                let safe = full;
                const tagIdx = full.lastIndexOf("<<<TOOL_CALL");
                if (tagIdx >= 0 && tagIdx >= started) safe = full.slice(0, tagIdx);
                if (safe.length > started) {
                  send({ type: "delta", text: safe.slice(started) });
                  started = safe.length;
                }
              }
            }
          },
          onDone() {
            const { prose, calls } = parseToolCalls(full);
            for (const c of calls) send({ type: "tool", tool: c.tool, input: c.input });
            const finalProse = prose.length > started ? prose.slice(started) : "";
            if (finalProse) send({ type: "delta", text: finalProse });
            void addMessage(convId!, "assistant", prose).then(() => {
              void touchConversation(convId!);
            });
            send({ type: "done" });
            try { controller.close(); } catch { /* already closed */ }
          },
          onError(err) {
            send({ type: "error", message: err.message });
            try { controller.close(); } catch { /* noop */ }
          },
          signal: abort.signal,
        });
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        send({ type: "error", message: msg });
        try { controller.close(); } catch { /* noop */ }
      }
    },
    cancel() {
      abort.abort();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
