import { NextResponse } from "next/server";
import { getCurrentUser, requireUser } from "@/lib/auth";
import { listConversations, createConversation } from "@/lib/data";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  try {
    const conversations = await listConversations();
    return NextResponse.json({ ok: true, conversations });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to load conversations." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  await requireUser();
  let body: any = {};
  try { body = await req.json(); } catch { /* empty body is fine */ }
  const title = (body.title && String(body.title)) || "New conversation";
  try {
    const conversation = await createConversation(title);
    return NextResponse.json({ ok: true, conversation });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to create conversation." }, { status: 500 });
  }
}
