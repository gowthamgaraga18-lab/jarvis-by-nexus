import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { renameConversation, deleteConversation, getConversation } from "@/lib/data";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const title = body.title ? String(body.title).slice(0, 120) : undefined;
  try {
    const conv = await renameConversation(id, title ?? "Untitled");
    if (!conv) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
    return NextResponse.json({ ok: true, conversation: conv });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to rename." }, { status: 500 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  const conv = await getConversation(id);
  if (!conv) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
  try {
    await deleteConversation(id);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to delete." }, { status: 500 });
  }
}
