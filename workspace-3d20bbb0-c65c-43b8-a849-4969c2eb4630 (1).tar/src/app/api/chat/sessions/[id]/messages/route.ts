import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getConversation, listMessages } from "@/lib/data";
import type { ChatMessage } from "@/lib/types";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  const { id } = await params;
  try {
    const conv = await getConversation(id);
    if (!conv) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
    const messages: ChatMessage[] = await listMessages(id);
    return NextResponse.json({ ok: true, conversationId: conv.id, title: conv.title, messages });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to load messages." }, { status: 500 });
  }
}
