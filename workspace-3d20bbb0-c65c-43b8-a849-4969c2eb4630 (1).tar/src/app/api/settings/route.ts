import { NextResponse } from "next/server";
import { getCurrentUser, requireUser } from "@/lib/auth";
import { loadSettings, saveSetting } from "@/lib/data";
import { AVAILABLE_MODELS } from "@/lib/jarvis-ai";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  try {
    const settings = await loadSettings();
    return NextResponse.json({ ok: true, settings, models: AVAILABLE_MODELS });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to load settings." }, { status: 500 });
  }
}

export async function PATCH(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const allowed: Record<string, (v: unknown) => string> = {
    model: (v) => {
      const s = String(v);
      if (!AVAILABLE_MODELS.some((m) => m.id === s)) throw new Error("Unsupported model");
      return s;
    },
    responseStyle: (v) => ["concise", "balanced", "detailed"].includes(String(v)) ? String(v) : "balanced",
    voiceEnabled: (v) => (v ? "true" : "false"),
    ttsVoice: (v) => String(v).slice(0, 60),
    ttsRate: (v) => {
      const n = Number(v);
      if (!isFinite(n) || n < 0.5 || n > 2) return "1";
      return String(n);
    },
    theme: (v) => (String(v) === "light" ? "light" : "dark"),
    reducedMotion: (v) => (v ? "true" : "false"),
    memoryEnabled: (v) => (v ? "true" : "false"),
  };

  if (body.displayName) {
    await saveSetting("displayName", String(body.displayName).slice(0, 60) || "Operator");
  }
  const updates = body.settings ?? body;
  for (const [key, raw] of Object.entries(updates ?? {})) {
    if (key in allowed) {
      try {
        const value = allowed[key](raw);
        await saveSetting(key, value);
      } catch (e) {
        return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Invalid setting" }, { status: 400 });
      }
    }
  }
  try {
    const settings = await loadSettings();
    return NextResponse.json({ ok: true, settings, models: AVAILABLE_MODELS });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to reload settings." }, { status: 500 });
  }
}
