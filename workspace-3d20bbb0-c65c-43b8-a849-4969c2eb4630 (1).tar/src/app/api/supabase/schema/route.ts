import { NextResponse } from "next/server";
import { readFileSync } from "fs";
import { join } from "path";

// GET /api/supabase/schema — returns the raw schema SQL so the UI can display
// and let the user copy it into the Supabase SQL editor.
export async function GET() {
  try {
    const sqlPath = join(process.cwd(), "supabase", "schema.sql");
    const sql = readFileSync(sqlPath, "utf-8");
    const editorUrl = `https://supabase.com/dashboard/project/${process.env.NEXT_PUBLIC_SUPABASE_URL?.replace("https://", "").replace(".supabase.co", "") ?? ""}/sql/new`;
    return NextResponse.json({ ok: true, sql, editorUrl });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to read schema." }, { status: 500 });
  }
}
