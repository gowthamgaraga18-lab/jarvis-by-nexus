import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { probeTables } from "@/lib/data";
import { isSupabaseConfigured } from "@/lib/supabase";

// GET /api/supabase/setup — reports whether the schema is ready and what to do
// if it isn't. Used by the client to show a setup banner.
export async function GET() {
  await requireUser();
  const configured = isSupabaseConfigured();
  if (!configured) {
    return NextResponse.json({ ok: true, configured: false, ready: false, tables: [] });
  }
  try {
    const probe = await probeTables();
    return NextResponse.json({ ok: true, configured: true, ready: probe.ready, tables: probe.tables });
  } catch (e) {
    return NextResponse.json({ ok: true, configured: true, ready: false, tables: [], error: e instanceof Error ? e.message : "probe failed" });
  }
}
