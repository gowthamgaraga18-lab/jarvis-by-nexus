import { NextResponse } from "next/server";
import { getCurrentUser, requireUser } from "@/lib/auth";
import { listTasks, createTask } from "@/lib/data";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const view = url.searchParams.get("view") ?? "all";
  const q = url.searchParams.get("q") ?? "";
  const projectId = url.searchParams.get("projectId") ?? undefined;
  try {
    const tasks = await listTasks({ view, q: q || undefined, projectId });
    return NextResponse.json({ ok: true, tasks });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to load tasks." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const { title, description, priority, status, category, dueDate, projectId } = body ?? {};
  if (!title || typeof title !== "string") {
    return NextResponse.json({ ok: false, error: "Title is required." }, { status: 400 });
  }
  try {
    const task = await createTask({
      title, description, priority, status, category, dueDate, projectId,
    });
    return NextResponse.json({ ok: true, task });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to create task." }, { status: 500 });
  }
}
