import { NextResponse } from "next/server";
import { getCurrentUser, requireUser } from "@/lib/auth";
import { listNotes, createNote } from "@/lib/data";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const q = url.searchParams.get("q") ?? "";
  const projectId = url.searchParams.get("projectId") ?? undefined;
  try {
    const notes = await listNotes({ q: q || undefined, projectId });
    return NextResponse.json({ ok: true, notes });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to load notes." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const { title, content, projectId } = body ?? {};
  if (!title || typeof title !== "string") {
    return NextResponse.json({ ok: false, error: "Title is required." }, { status: 400 });
  }
  try {
    const note = await createNote({ title, content, projectId });
    return NextResponse.json({ ok: true, note });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Failed to create note." }, { status: 500 });
  }
}
