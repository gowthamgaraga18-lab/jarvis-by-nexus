import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { getNote } from "@/lib/data";
import { chatCompletion } from "@/lib/jarvis-ai";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  try {
    const note = await getNote(id);
    if (!note) return NextResponse.json({ ok: false, error: "Not found" }, { status: 404 });
    if (!note.content.trim()) return NextResponse.json({ ok: false, error: "Note is empty." }, { status: 400 });
    const summary = await chatCompletion(
      [
        { role: "system", content: "You are JARVIS. Summarize the user's note in 3-5 concise bullet points in markdown. Preserve key facts." },
        { role: "user", content: `Title: ${note.title}\n\n${note.content}` },
      ],
      { maxTokens: 800 }
    );
    return NextResponse.json({ ok: true, summary });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Summarization failed." }, { status: 502 });
  }
}
