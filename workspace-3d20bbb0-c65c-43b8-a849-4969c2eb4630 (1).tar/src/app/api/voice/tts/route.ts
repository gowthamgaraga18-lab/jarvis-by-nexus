import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { getZAI } from "@/lib/jarvis-ai";

// POST /api/voice/tts  { text, voice?, rate? } -> audio/wav blob.
// Server-side fallback for when the browser lacks speechSynthesis or the user
// explicitly chooses the z.ai voice in Settings.
export async function POST(req: Request) {
  const user = await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const { text, voice, rate } = body ?? {};
  if (!text || typeof text !== "string") {
    return NextResponse.json({ ok: false, error: "Text is required." }, { status: 400 });
  }
  const trimmed = text.slice(0, 2000);
  if (!trimmed.trim()) return NextResponse.json({ ok: false, error: "Empty text." }, { status: 400 });

  try {
    const zai = await getZAI();
    const response = (await zai.audio.tts.create({
      input: trimmed,
      voice: voice && voice !== "default" ? String(voice) : "tongtong",
      speed: typeof rate === "number" && rate >= 0.5 && rate <= 2 ? rate : 1,
      response_format: "wav",
      stream: false,
    } as never)) as Response;
    if (!response.ok) {
      const errTxt = await response.text().catch(() => "");
      return NextResponse.json({ ok: false, error: `TTS failed: ${response.status} ${errTxt.slice(0, 200)}` }, { status: 502 });
    }
    const buf = await response.arrayBuffer();
    // Mark as used by user (light audit only — we do not store the audio or text).
    void user.id;
    return new NextResponse(buf, {
      status: 200,
      headers: { "Content-Type": "audio/wav", "Cache-Control": "no-store" },
    });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "TTS failed." }, { status: 502 });
  }
}
