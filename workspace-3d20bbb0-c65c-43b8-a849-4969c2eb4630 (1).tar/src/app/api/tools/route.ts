import { NextResponse } from "next/server";
import { getCurrentUser, requireUser } from "@/lib/auth";
import { listTools, runTool } from "@/lib/tools/registry";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  return NextResponse.json({ ok: true, tools: listTools() });
}

export async function POST(req: Request) {
  await requireUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid JSON." }, { status: 400 }); }
  const { name, input } = body ?? {};
  if (!name || typeof name !== "string") {
    return NextResponse.json({ ok: false, error: "Tool name required." }, { status: 400 });
  }
  try {
    const result = await runTool(name, input ?? {}, "operator");
    return NextResponse.json({ ok: result.ok, result });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : "Tool failed." }, { status: 500 });
  }
}
