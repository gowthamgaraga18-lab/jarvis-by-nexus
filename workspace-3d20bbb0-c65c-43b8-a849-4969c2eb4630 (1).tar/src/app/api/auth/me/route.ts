import { NextResponse } from "next/server";
import { ensureDefaultUser } from "@/lib/auth";

// With the sign-in page removed, this endpoint auto-provisions the default
// local Operator account on first contact so the app boots straight into the
// shell. The returned user is used by the AuthProvider on the client.
export async function GET() {
  const user = await ensureDefaultUser();
  return NextResponse.json({ ok: true, user });
}
