"use client";

import { useAuth } from "@/components/providers/auth-provider";
import { AppShell } from "@/components/jarvis/app-shell";
import { JarvisOrb } from "@/components/jarvis/orb";

export default function Home() {
  const { user, loading } = useAuth();

  // With the sign-in page removed, the only "loading" state is the brief
  // moment while /api/auth/me auto-provisions the local Operator session.
  if (loading || !user) {
    return (
      <div className="min-h-screen grid place-items-center">
        <div className="flex flex-col items-center gap-4">
          <JarvisOrb state="processing" size={160} />
          <p className="text-sm text-muted-foreground animate-pulse">Initializing JARVIS…</p>
        </div>
      </div>
    );
  }
  return <AppShell />;
}
