"use client";

import { useQuery } from "@tanstack/react-query";
import type { ToolField } from "@/lib/types";

export function useTools() {
  return useQuery<{ tools: { name: string; label: string; description: string; requiresConfirmation: boolean; schema: ToolField[] }[] }>({
    queryKey: ["tools"],
    queryFn: async () => {
      const r = await fetch("/api/tools", { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
      return j;
    },
    staleTime: 60_000,
  });
}

export async function runTool(name: string, input: Record<string, unknown>) {
  const r = await fetch("/api/tools", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, input }),
  });
  return r.json();
}
