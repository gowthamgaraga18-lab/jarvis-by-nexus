"use client";

import { useQuery } from "@tanstack/react-query";

interface SetupState {
  ok: boolean;
  configured: boolean;
  ready: boolean;
  tables: string[];
  error?: string;
}

export function useSupabaseSetup() {
  return useQuery<SetupState>({
    queryKey: ["supabase-setup"],
    queryFn: async () => {
      const r = await fetch("/api/supabase/setup", { cache: "no-store" });
      return r.json();
    },
    staleTime: 15_000,
    refetchInterval: (q) => {
      // Keep polling until the schema is ready, then stop.
      return q.state.data?.ready ? false : 10000;
    },
  });
}
