"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback } from "react";
import type { Settings } from "@/lib/types";

export function useSettings() {
  const qc = useQueryClient();
  const q = useQuery<{ settings: Settings; models: { id: string; label: string }[] }>({
    queryKey: ["settings"],
    queryFn: async () => {
      const r = await fetch("/api/settings", { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || "Failed to load settings");
      return j;
    },
  });
  const update = useCallback(
    async (patch: Partial<Settings> & { displayName?: string }) => {
      const r = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error || "Failed to save setting");
      qc.setQueryData(["settings"], j);
      return j.settings as Settings;
    },
    [qc]
  );
  return { settings: q.data?.settings, models: q.data?.models, update, ...q };
}
