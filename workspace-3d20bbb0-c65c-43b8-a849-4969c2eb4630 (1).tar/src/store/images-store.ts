import { create } from "zustand";

export interface GeneratedImage {
  id: string;
  src: string; // data:image/png;base64,...
  prompt: string;
  size: string;
  createdAt: string;
}

interface ImagesState {
  images: GeneratedImage[];
  addImage: (img: Omit<GeneratedImage, "id" | "createdAt">) => void;
  removeImage: (id: string) => void;
  clear: () => void;
}

export const useImagesStore = create<ImagesState>((set) => ({
  images: [],
  addImage: (img) =>
    set((s) => ({
      images: [
        { id: crypto.randomUUID(), src: img.src, prompt: img.prompt, size: img.size, createdAt: new Date().toISOString() },
        ...s.images,
      ].slice(0, 30),
    })),
  removeImage: (id) => set((s) => ({ images: s.images.filter((i) => i.id !== id) })),
  clear: () => set({ images: [] }),
}));
