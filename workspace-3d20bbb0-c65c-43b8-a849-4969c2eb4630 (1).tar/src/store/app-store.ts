import { create } from "zustand";

export type View =
  | "dashboard"
  | "chat"
  | "voice"
  | "tasks"
  | "notes"
  | "projects"
  | "studio"
  | "memory"
  | "settings";

interface AppState {
  view: View;
  setView: (v: View) => void;
  // Quick-action launcher state so Dashboard "New Task" can jump into Tasks view
  // with the create dialog pre-opened.
  quickAction: { target: View; action: string | null } | null;
  launchQuick: (target: View, action: string) => void;
  clearQuick: () => void;
  // Selected conversation id for the chat view.
  activeConversationId: string | null;
  setActiveConversation: (id: string | null) => void;
  // Selected project id for the projects view.
  activeProjectId: string | null;
  setActiveProject: (id: string | null) => void;
  // Sidebar collapse on desktop.
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  // Mobile sidebar open state.
  mobileNavOpen: boolean;
  setMobileNav: (open: boolean) => void;
}

export const useApp = create<AppState>((set) => ({
  view: "dashboard",
  setView: (view) => set({ view }),
  quickAction: null,
  launchQuick: (target, action) => set({ quickAction: { target, action }, view: target }),
  clearQuick: () => set({ quickAction: null }),
  activeConversationId: null,
  setActiveConversation: (id) => set({ activeConversationId: id }),
  activeProjectId: null,
  setActiveProject: (id) => set({ activeProjectId: id }),
  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  mobileNavOpen: false,
  setMobileNav: (open) => set({ mobileNavOpen: open }),
}));
