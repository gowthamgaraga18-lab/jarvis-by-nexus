"use client";

import ReactMarkdown from "react-markdown";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";
import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export function Markdown({ content, className }: { content: string; className?: string }) {
  return (
    <div className={cn("jarvis-prose", className)}>
      <ReactMarkdown
        components={{
          code(props) {
            const { children, className, node, ...rest } = props as any;
            void node;
            const match = /language-(\w+)/.exec(className || "");
            const inline = !className;
            if (inline || !match) {
              return <code className={className} {...rest}>{children}</code>;
            }
            const code = String(children).replace(/\n$/, "");
            return <CodeBlock language={match[1]} code={code} />;
          },
          a(props) {
            const { children, href } = props as any;
            return <a href={href} target="_blank" rel="noopener noreferrer">{children}</a>;
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}

function CodeBlock({ language, code }: { language: string; code: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="relative group">
      <button
        onClick={() => {
          navigator.clipboard?.writeText(code);
          setCopied(true);
          setTimeout(() => setCopied(false), 1200);
          toast.success("Copied");
        }}
        className="absolute right-2 top-2 rounded-md border border-border/60 bg-background/60 p-1 opacity-0 group-hover:opacity-100 transition"
        aria-label="Copy code"
      >
        {copied ? <Check className="size-3 text-emerald-400" /> : <Copy className="size-3" />}
      </button>
      <SyntaxHighlighter style={oneDark} language={language} PreTag="div" className="!bg-background/60 !text-xs">
        {code}
      </SyntaxHighlighter>
    </div>
  );
}
