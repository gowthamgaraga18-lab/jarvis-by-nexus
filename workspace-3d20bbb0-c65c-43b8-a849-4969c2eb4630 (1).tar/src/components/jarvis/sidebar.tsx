"use client";

import { LayoutDashboard, MessagesSquare, Mic, ListChecks, NotebookPen, FolderKanban, Wand2, Brain, Settings } from "lucide-react";
import { useApp, type View } from "@/store/app-store";
import { useAuth } from "@/components/providers/auth-provider";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";

const NAV: { id: View; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "chat", label: "Chat", icon: MessagesSquare },
  { id: "voice", label: "Voice", icon: Mic },
  { id: "tasks", label: "Tasks", icon: ListChecks },
  { id: "notes", label: "Notes", icon: NotebookPen },
  { id: "projects", label: "Projects", icon: FolderKanban },
  { id: "studio", label: "Studio", icon: Wand2 },
  { id: "memory", label: "Memory", icon: Brain },
  { id: "settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const { view, setView, sidebarCollapsed, mobileNavOpen, setMobileNav } = useApp();
  const { user } = useAuth();
  const collapsed = sidebarCollapsed;

  return (
    <>
      {/* Mobile overlay */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-40 bg-black/60 lg:hidden" onClick={() => setMobileNav(false)} aria-hidden />
      )}
      <aside
        className={cn(
          "z-50 flex flex-col border-r border-sidebar-border bg-sidebar/80 backdrop-blur-xl transition-all duration-300",
          "lg:static lg:translate-x-0",
          "fixed inset-y-0 left-0 w-64",
          mobileNavOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
          collapsed && "lg:w-16 lg:w-16"
        )}
      >
        <div className="flex items-center gap-3 h-16 px-4 border-b border-sidebar-border">
          <div className="size-8 rounded-full jarvis-orb-ring jarvis-spin shrink-0" />
          {!collapsed && (
            <div className="leading-tight">
              <div className="font-semibold tracking-wide">JARVIS</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">AI Assistant</div>
            </div>
          )}
        </div>

        <nav className="flex-1 p-2 jarvis-scrollbar overflow-y-auto">
          <TooltipProvider delayDuration={collapsed ? 200 : 99999}>
            <ul className="flex flex-col gap-1">
              {NAV.map((item) => {
                const active = view === item.id;
                const Icon = item.icon;
                const btn = (
                  <button
                    key={item.id}
                    onClick={() => {
                      setView(item.id);
                      setMobileNav(false);
                    }}
                    className={cn(
                      "group flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all",
                      "hover:bg-sidebar-accent/60",
                      active && "bg-sidebar-accent text-sidebar-accent-foreground jarvis-glow",
                      !active && "text-sidebar-foreground/80",
                      collapsed && "justify-center px-0"
                    )}
                    aria-current={active ? "page" : undefined}
                  >
                    <Icon className="size-4 shrink-0" />
                    {!collapsed && <span>{item.label}</span>}
                  </button>
                );
                if (collapsed) {
                  return (
                    <li key={item.id}>
                      <Tooltip>
                        <TooltipTrigger asChild>{btn}</TooltipTrigger>
                        <TooltipContent side="right">{item.label}</TooltipContent>
                      </Tooltip>
                    </li>
                  );
                }
                return <li key={item.id}>{btn}</li>;
              })}
            </ul>
          </TooltipProvider>
        </nav>

        <div className="border-t border-sidebar-border p-3">
          <div className={cn("flex items-center gap-2", collapsed && "justify-center")}>
            <div className="size-8 rounded-full bg-primary/20 grid place-items-center text-xs font-semibold text-primary shrink-0">
              {(user?.displayName?.[0] || "U").toUpperCase()}
            </div>
            {!collapsed && (
              <div className="min-w-0 flex-1">
                <div className="text-sm truncate">{user?.displayName}</div>
                <div className="text-[10px] text-muted-foreground truncate">{user?.email}</div>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
}
