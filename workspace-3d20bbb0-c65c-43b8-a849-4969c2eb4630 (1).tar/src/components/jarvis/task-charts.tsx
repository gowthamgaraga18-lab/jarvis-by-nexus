"use client";

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line } from "recharts";
import { Card } from "@/components/ui/card";
import type { Task } from "@/lib/types";
import { CircleDashed, CircleDot, CircleCheckBig, TrendingUp } from "lucide-react";

const STATUS_COLORS = { todo: "#7c8db5", in_progress: "#f5a623", done: "#3ecf8e" } as const;
const PRIORITY_COLORS = { low: "#3ecf8e", medium: "#f5a623", high: "#ef4444" } as const;

export function TaskCharts({ tasks }: { tasks: Task[] }) {
  const statusData = (["todo", "in_progress", "done"] as const).map((k) => ({
    name: k === "todo" ? "To do" : k === "in_progress" ? "In progress" : "Done",
    value: tasks.filter((t) => t.status === k).length,
    key: k,
  }));
  const priorityData = (["low", "medium", "high"] as const).map((k) => ({
    name: k.charAt(0).toUpperCase() + k.slice(1),
    value: tasks.filter((t) => t.priority === k && t.status !== "done").length,
    fill: PRIORITY_COLORS[k],
  }));
  // 7-day completion trend.
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const trend = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(today); d.setDate(d.getDate() - (6 - i));
    const next = new Date(d); next.setDate(next.getDate() + 1);
    const done = tasks.filter((t) => t.completedAt && new Date(t.completedAt) >= d && new Date(t.completedAt) < next).length;
    const created = tasks.filter((t) => new Date(t.createdAt) >= d && new Date(t.createdAt) < next).length;
    return { name: d.toLocaleDateString(undefined, { weekday: "short" }), created, done };
  });

  const total = tasks.length;
  const doneCount = tasks.filter((t) => t.status === "done").length;
  const completionRate = total ? Math.round((doneCount / total) * 100) : 0;

  if (total === 0) {
    return (
      <Card className="jarvis-panel p-5">
        <div className="flex items-center gap-2 mb-2"><TrendingUp className="size-4 text-primary" /><h3 className="font-semibold text-sm">Productivity</h3></div>
        <p className="text-xs text-muted-foreground">No tasks yet — create one to see your productivity charts.</p>
      </Card>
    );
  }

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <Card className="jarvis-panel p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-semibold text-sm flex items-center gap-2"><CircleDashed className="size-4 text-primary" /> Status</h3>
          <span className="text-xs text-muted-foreground">{completionRate}% done</span>
        </div>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={42} outerRadius={64} paddingAngle={3}>
                {statusData.map((d) => <Cell key={d.key} fill={STATUS_COLORS[d.key]} stroke="transparent" />)}
              </Pie>
              <Tooltip contentStyle={{ background: "rgba(20,20,30,0.95)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex flex-wrap gap-3 justify-center text-[11px]">
          {statusData.map((d) => (
            <span key={d.key} className="flex items-center gap-1"><span className="size-2 rounded-full" style={{ background: STATUS_COLORS[d.key] }} />{d.name}: {d.value}</span>
          ))}
        </div>
      </Card>

      <Card className="jarvis-panel p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-semibold text-sm flex items-center gap-2"><CircleDot className="size-4 text-primary" /> Open by priority</h3>
        </div>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={priorityData} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: "rgba(255,255,255,0.04)" }} contentStyle={{ background: "rgba(20,20,30,0.95)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="jarvis-panel p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-semibold text-sm flex items-center gap-2"><CircleCheckBig className="size-4 text-primary" /> 7-day trend</h3>
        </div>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trend} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fill: "#94a3b8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "rgba(20,20,30,0.95)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }} />
              <Line type="monotone" dataKey="created" name="Created" stroke="#7c8db5" strokeWidth={2} dot={{ r: 2 }} />
              <Line type="monotone" dataKey="done" name="Done" stroke="#3ecf8e" strokeWidth={2} dot={{ r: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex gap-3 justify-center text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1"><span className="size-2 rounded-full bg-[#7c8db5]" />Created</span>
          <span className="flex items-center gap-1"><span className="size-2 rounded-full bg-[#3ecf8e]" />Done</span>
        </div>
      </Card>
    </div>
  );
}
