"use client";

import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";

export interface ConfirmRequest {
  title: string;
  description?: string;
  confirmText?: string;
  cancelText?: string;
  destructive?: boolean;
  onConfirm: () => void;
}

export function ConfirmDialog({ open, request, onClose }: { open: boolean; request: ConfirmRequest | null; onClose: () => void }) {
  return (
    <AlertDialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <AlertDialogContent className="jarvis-panel">
        <AlertDialogHeader>
          <AlertDialogTitle>{request?.title ?? "Confirm"}</AlertDialogTitle>
          {request?.description && <AlertDialogDescription>{request.description}</AlertDialogDescription>}
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel asChild>
            <Button variant="ghost">{request?.cancelText ?? "Cancel"}</Button>
          </AlertDialogCancel>
          <AlertDialogAction asChild>
            <Button variant={request?.destructive ? "destructive" : "default"} onClick={() => { request?.onConfirm(); onClose(); }}>
              {request?.confirmText ?? "Confirm"}
            </Button>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
