"use client";

import { useEffect, useMemo, useState } from "react";
import { Sidebar } from "@/components/jarvis/sidebar";
import { Topbar } from "@/components/jarvis/topbar";
import { DashboardView } from "@/components/jarvis/views/dashboard";
import { ChatView } from "@/components/jarvis/views/chat";
import { VoiceView } from "@/components/jarvis/views/voice";
import { TasksView } from "@/components/jarvis/views/tasks";
import { NotesView } from "@/components/jarvis/views/notes";
import { ProjectsView } from "@/components/jarvis/views/projects";
import { ImageStudioView } from "@/components/jarvis/views/image-studio";
import { MemoryView } from "@/components/jarvis/views/memory";
import { SettingsView } from "@/components/jarvis/views/settings";
import { useApp } from "@/store/app-store";
import { useSettings } from "@/hooks/use-settings";
import { SupabaseSetupBanner, DbStatusDot } from "@/components/jarvis/supabase-setup-banner";
import { CommandPalette } from "@/components/jarvis/command-palette";

export function AppShell() {
  const { view, sidebarCollapsed } = useApp();
  const { settings } = useSettings();
  const [micGranted, setMicGranted] = useState<"unknown" | "granted" | "denied" | "unsupported">("unknown");

  // Apply reduced-motion + theme to <html>.
  useEffect(() => {
    const root = document.documentElement;
    if (settings?.reducedMotion) root.classList.add("reduced-motion");
    else root.classList.remove("reduced-motion");
    if (settings?.theme === "light") root.classList.remove("dark");
    else root.classList.add("dark");
  }, [settings?.reducedMotion, settings?.theme]);

  // Probe microphone permission status (non-invasive: only checks the existing
  // permission state; does not prompt).
  useEffect(() => {
    let cancelled = false;
    async function probe() {
      if (!("permissions" in navigator)) {
        setMicGranted("unknown");
        return;
      }
      try {
        const p = await (navigator as any).permissions.query({ name: "microphone" });
        const apply = (state: string) => {
          if (cancelled) return;
          if (state === "granted") setMicGranted("granted");
          else if (state === "denied") setMicGranted("denied");
          else setMicGranted("unknown");
        };
        apply(p.state);
        p.onchange = () => apply(p.state);
      } catch {
        setMicGranted("unknown");
      }
    }
    probe();
    return () => { cancelled = true; };
  }, []);

  const View = useMemo(() => {
    switch (view) {
      case "chat": return <ChatView />;
      case "voice": return <VoiceView />;
      case "tasks": return <TasksView />;
      case "notes": return <NotesView />;
      case "projects": return <ProjectsView />;
      case "studio": return <ImageStudioView />;
      case "memory": return <MemoryView />;
      case "settings": return <SettingsView micGranted={micGranted} />;
      default: return <DashboardView />;
    }
  }, [view, micGranted]);

  return (
    <div className="min-h-screen flex flex-col">
      <SupabaseSetupBanner />
      <CommandPalette />
      <div className="flex flex-1 min-h-0">
        <Sidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <Topbar micGranted={micGranted} />
          <main className="flex-1 min-h-0 overflow-hidden">
            <div className={"h-full transition-all " + (sidebarCollapsed ? "lg:pl-0" : "")}>
              {View}
            </div>
          </main>
        </div>
      </div>
      <footer className="mt-auto border-t border-border/70 bg-background/70 backdrop-blur-xl">
        <div className="px-4 py-2 text-[11px] text-muted-foreground flex flex-wrap items-center justify-between gap-2">
          <span>JARVIS AI · local-first personal assistant</span>
          <span className="flex items-center gap-3">
            <DbStatusDot />
            <span className="size-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Data stays on this machine
          </span>
        </div>
      </footer>
    </div>
  );
}
