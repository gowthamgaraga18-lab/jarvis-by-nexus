"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Database, Copy, Check, ExternalLink, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSupabaseSetup } from "@/hooks/use-supabase-setup";
import { toast } from "sonner";

// Shown at the top of the app when Supabase is configured but the schema
// hasn't been applied yet. Guides the user to run the SQL once.
export function SupabaseSetupBanner() {
  const { data } = useSupabaseSetup();
  const [open, setOpen] = useState(false);
  const sql = useQuery<{ sql: string; editorUrl: string }>({
    queryKey: ["supabase-sql"],
    queryFn: async () => {
      const r = await fetch("/api/supabase/schema", { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
      return j;
    },
    enabled: false,
  });

  if (!data?.ok || !data.configured || data.ready) return null;

  return (
    <div className="border-b border-amber-500/40 bg-amber-500/10 px-4 py-2.5">
      <div className="max-w-6xl mx-auto flex flex-wrap items-center gap-3 text-sm">
        <Database className="size-4 text-amber-400 shrink-0" />
        <div className="flex-1 min-w-0">
          <span className="font-medium text-amber-200">Supabase connected — schema not applied yet.</span>{" "}
          <span className="text-amber-100/80 hidden sm:inline">
            The app is fully functional now (local store). Run the schema SQL once to store your data in Supabase.
          </span>
        </div>
        <Button size="sm" variant="outline" className="border-amber-500/40 text-amber-100 hover:bg-amber-500/20" onClick={() => setOpen((o) => !o)}>
          {open ? "Hide" : "Show setup"}
        </Button>
      </div>
      {open && (
        <div className="max-w-6xl mx-auto mt-3 grid gap-3">
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              onClick={async () => {
                const res = await sql.refetch();
                if (res.data) {
                  await navigator.clipboard?.writeText(res.data.sql);
                  toast.success("Schema SQL copied — paste it into the Supabase SQL editor and Run.");
                }
              }}
            >
              <Copy className="size-4" /> Copy schema SQL
            </Button>
            <a
              href={`https://supabase.com/dashboard/project/${process.env.NEXT_PUBLIC_SUPABASE_URL?.replace("https://", "").replace(".supabase.co", "")}/sql/new`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button size="sm" variant="outline">
                <ExternalLink className="size-4" /> Open SQL editor
              </Button>
            </a>
            <span className="text-xs text-amber-100/70 self-center ml-2">
              After running the SQL, this banner disappears automatically.
            </span>
          </div>
          <div className="rounded-lg border border-amber-500/30 bg-background/60 p-3 max-h-64 overflow-auto jarvis-scrollbar text-xs font-mono whitespace-pre">
            {sql.isFetching ? <span className="flex items-center gap-2"><Loader2 className="size-3 animate-spin" /> Loading SQL…</span> : (sql.data?.sql ?? "Click “Copy schema SQL” to load.")}
          </div>
        </div>
      )}
    </div>
  );
}

// Tiny inline indicator used in the footer to show live DB readiness.
export function DbStatusDot() {
  const { data, isLoading } = useSupabaseSetup();
  const ready = data?.ok && data.configured && data.ready;
  const partial = data?.ok && data.configured && !data.ready;
  const tone = ready ? "bg-emerald-400" : partial ? "bg-amber-400 animate-pulse" : "bg-muted-foreground/40";
  const label = ready ? "Supabase ready" : partial ? "Local mode · Supabase pending" : isLoading ? "Checking DB…" : "DB idle";
  return (
    <span className="inline-flex items-center gap-1.5" title={label}>
      <span className={"size-1.5 rounded-full " + tone} />
      <span className="hidden sm:inline">{label}</span>
    </span>
  );
}
