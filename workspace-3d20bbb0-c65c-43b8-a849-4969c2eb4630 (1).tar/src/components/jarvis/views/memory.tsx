"use client";

import { useState } from "react";
import { useQueryClient, useQuery, useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Brain, Plus, Trash2, ShieldCheck, Pencil } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/components/providers/auth-provider";
import { useSettings } from "@/hooks/use-settings";
import type { MemoryEntry } from "@/lib/types";

export function MemoryView() {
  const qc = useQueryClient();
  const { settings } = useSettings();
  const memoryEnabled = settings?.memoryEnabled !== false;
  const [editing, setEditing] = useState<MemoryEntry | null>(null);
  const [key, setKey] = useState("");
  const [value, setValue] = useState("");
  const [showForm, setShowForm] = useState(false);

  const q = useQuery<{ memory: MemoryEntry[] }>({
    queryKey: ["memory"],
    queryFn: async () => {
      const r = await fetch("/api/memory", { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
      return j;
    },
    enabled: memoryEnabled,
  });

  const save = useMutation({
    mutationFn: async (payload: { key: string; value: string }) => {
      const r = await fetch("/api/memory", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
      return j.entry as MemoryEntry;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["memory"] }); setKey(""); setValue(""); setEditing(null); setShowForm(false); toast.success("Saved."); },
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const r = await fetch(`/api/memory/${id}`, { method: "DELETE" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["memory"] }); toast.success("Deleted."); },
  });

  const clearAll = useMutation({
    mutationFn: async () => {
      const r = await fetch("/api/memory", { method: "DELETE" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["memory"] }); toast.success("All memory cleared."); },
  });

  const memory = q.data?.memory ?? [];

  return (
    <div className="h-full overflow-y-auto jarvis-scrollbar">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 grid gap-4">
        <div className="flex items-center gap-3">
          <div className="flex-1">
            <h2 className="text-xl font-semibold flex items-center gap-2"><Brain className="size-5 text-primary" /> Memory</h2>
            <p className="text-sm text-muted-foreground">Preferences JARVIS remembers across conversations. You’re in full control.</p>
          </div>
          {!memoryEnabled ? (
            <Button variant="outline" size="sm" onClick={async () => { await fetch("/api/settings", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ memoryEnabled: true }) }); qc.invalidateQueries({ queryKey: ["settings"] }); }}>Enable memory</Button>
          ) : (
            <Button size="sm" onClick={() => { setEditing(null); setKey(""); setValue(""); setShowForm(true); }}><Plus className="size-4" /> Add</Button>
          )}
        </div>

        {!memoryEnabled ? (
          <Card className="jarvis-panel p-6 text-center">
            <ShieldCheck className="size-8 mx-auto text-emerald-400 mb-2" />
            <p className="text-sm text-muted-foreground">Memory is disabled. JARVIS won’t persist any preferences between sessions. You can enable it any time.</p>
          </Card>
        ) : showForm || editing ? (
          <Card className="jarvis-panel p-4">
            <h3 className="font-semibold text-sm mb-3">{editing ? "Edit preference" : "New preference"}</h3>
            <div className="grid gap-3">
              <div className="grid gap-1.5">
                <Label htmlFor="m-key">Key</Label>
                <Input id="m-key" value={editing ? editing.key : key} onChange={(e) => editing ? setEditing({ ...editing, key: e.target.value }) : setKey(e.target.value)} placeholder="e.g. preferred name, timezone, dietary" />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="m-val">Value</Label>
                <Textarea id="m-val" value={editing ? editing.value : value} onChange={(e) => editing ? setEditing({ ...editing, value: e.target.value }) : setValue(e.target.value)} rows={3} />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="ghost" size="sm" onClick={() => { setShowForm(false); setEditing(null); }}>Cancel</Button>
                <Button size="sm" onClick={() => save.mutate({ key: editing?.key ?? key, value: editing?.value ?? value })} disabled={save.isPending}>Save</Button>
              </div>
            </div>
          </Card>
        ) : q.isLoading ? (
          <div className="grid gap-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
        ) : memory.length === 0 ? (
          <Card className="jarvis-panel p-6 text-center">
            <Brain className="size-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No saved preferences yet. Add one, or ask JARVIS in chat to remember something — it will always ask first.</p>
          </Card>
        ) : (
          <div className="grid gap-2">
            {memory.map((m) => (
              <Card key={m.id} className="jarvis-panel p-3 flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium">{m.key}</div>
                  <div className="text-sm text-muted-foreground whitespace-pre-wrap break-words">{m.value}</div>
                  <div className="text-[10px] text-muted-foreground mt-1">Updated {new Date(m.updatedAt).toLocaleString()}</div>
                </div>
                <Button size="icon" variant="ghost" className="size-8" onClick={() => setEditing(m)} aria-label="Edit"><Pencil className="size-3.5" /></Button>
                <Button size="icon" variant="ghost" className="size-8 text-destructive" onClick={() => { if (confirm("Delete this preference?")) remove.mutate(m.id); }} aria-label="Delete"><Trash2 className="size-3.5" /></Button>
              </Card>
            ))}
            <div className="flex justify-end pt-2">
              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => { if (confirm("Delete ALL saved preferences? This cannot be undone.")) clearAll.mutate(); }}>Clear all memory</Button>
            </div>
          </div>
        )}

        <Card className="jarvis-panel p-4">
          <div className="flex items-start gap-2">
            <ShieldCheck className="size-4 text-primary mt-0.5" />
            <div className="text-xs text-muted-foreground">
              <p className="font-medium text-foreground mb-1">How JARVIS uses memory</p>
              <ul className="list-disc pl-4 space-y-1">
                <li>Only entries you explicitly save (or approve in chat) are stored.</li>
                <li>JARVIS never infers sensitive attributes (health, finances, identity documents).</li>
                <li>Memory is scoped to your account only — never shared across users.</li>
                <li>Conversation context is temporary; this list is the persistent layer.</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
