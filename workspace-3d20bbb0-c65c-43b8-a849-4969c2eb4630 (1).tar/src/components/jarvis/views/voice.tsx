"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { JarvisOrb } from "@/components/jarvis/orb";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Mic, MicOff, Send, Square, Volume2, Pause, Play, AlertTriangle, Settings2 } from "lucide-react";
import { toast } from "sonner";
import { useApp } from "@/store/app-store";
import { useSettings } from "@/hooks/use-settings";
import { Markdown } from "@/components/jarvis/markdown";
import { ToolCallCard } from "@/components/jarvis/tool-call-card";
import type { AssistantState } from "@/lib/types";

// Minimal types for the Web Speech API (vendor-prefixed in some browsers).
type SpeechRecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: any) => void) | null;
  onerror: ((e: any) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

export function VoiceView() {
  const { setView } = useApp();
  const { settings } = useSettings();
  const [state, setState] = useState<AssistantState>("idle");
  const [recognition, setRecognition] = useState<SpeechRecognitionLike | null>(null);
  const [supported, setSupported] = useState<{ stt: boolean; tts: boolean; zaiTts: boolean }>({ stt: false, tts: false, zaiTts: false });
  const [transcript, setTranscript] = useState("");
  const [interim, setInterim] = useState("");
  const [reply, setReply] = useState("");
  const [tools, setTools] = useState<{ tool: string; input: Record<string, unknown> }[]>([]);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [rate, setRate] = useState(1);
  const [selectedVoice, setSelectedVoice] = useState("default");
  const [useZaiTts, setUseZaiTts] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [zaiStatus, setZaiStatus] = useState<string | null>(null);

  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const stt = !!SR;
    const tts = typeof window !== "undefined" && "speechSynthesis" in window;
    setSupported({ stt, tts, zaiTts: true });
    if (stt) {
      const rec = new SR();
      rec.lang = "en-US";
      rec.continuous = false;
      rec.interimResults = true;
      rec.onresult = (e: any) => {
        let finalText = "";
        let interimText = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const r = e.results[i];
          if (r.isFinal) finalText += r[0].transcript;
          else interimText += r[0].transcript;
        }
        if (finalText) setTranscript((t) => (t ? t + " " : "") + finalText.trim());
        setInterim(interimText);
      };
      rec.onerror = (e: any) => {
        if (e.error === "not-allowed" || e.error === "service-not-allowed") {
          toast.error("Microphone permission denied. You can still type below.");
          setState("error");
        } else if (e.error === "no-speech") {
          toast.message("No speech detected. Try again.");
        } else {
          toast.error("Speech recognition error: " + e.error);
        }
        setListening(false);
        setState("idle");
      };
      rec.onend = () => {
        setListening(false);
        if (state !== "processing") setState("idle");
      };
      setRecognition(rec);
    }
    if (tts) {
      const load = () => setVoices(window.speechSynthesis.getVoices());
      load();
      window.speechSynthesis.onvoiceschanged = load;
    }
  }, []);

  useEffect(() => {
    if (settings?.ttsVoice && settings.ttsVoice !== "default") setSelectedVoice(settings.ttsVoice);
    if (settings?.ttsRate) setRate(settings.ttsRate);
  }, [settings?.ttsVoice, settings?.ttsRate]);

  const startListening = useCallback(() => {
    if (!recognition) {
      toast.error("Speech recognition is not available in this browser. Use typed input below.");
      return;
    }
    try {
      recognition.start();
      setListening(true);
      setState("listening");
    } catch (e) {
      toast.error("Could not start microphone. " + (e instanceof Error ? e.message : ""));
      setState("error");
      setTimeout(() => setState("idle"), 1200);
    }
  }, [recognition]);

  const stopListening = useCallback(() => {
    recognition?.stop();
    setListening(false);
    setState("idle");
  }, [recognition]);

  const stopSpeaking = useCallback(() => {
    if (supported.tts && !useZaiTts) window.speechSynthesis.cancel();
    if (audioRef.current) { audioRef.current.pause(); audioRef.current.currentTime = 0; }
    setSpeaking(false);
    setState("idle");
  }, [supported.tts, useZaiTts]);

  const speak = useCallback(async (text: string) => {
    if (!text.trim()) return;
    setState("speaking");
    setSpeaking(true);
    // If browser TTS selected and available, use it; else fall back to z.ai TTS.
    if (supported.tts && !useZaiTts) {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = rate;
      const v = voices.find((x) => x.name === selectedVoice);
      if (v) u.voice = v;
      u.onend = () => { setSpeaking(false); setState("idle"); };
      u.onerror = () => { setSpeaking(false); setState("error"); setTimeout(() => setState("idle"), 1200); };
      window.speechSynthesis.speak(u);
      return;
    }
    // z.ai TTS fallback: fetch audio/wav and play it.
    try {
      setZaiStatus("Synthesizing speech…");
      const r = await fetch("/api/voice/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voice: selectedVoice, rate }),
      });
      if (!r.ok) {
        const j = await r.json().catch(() => ({}));
        throw new Error(j.error || `TTS failed (${r.status})`);
      }
      const blob = await r.blob();
      const url = URL.createObjectURL(blob);
      if (audioRef.current) { audioRef.current.src = url; audioRef.current.onended = () => { setSpeaking(false); setState("idle"); URL.revokeObjectURL(url); }; audioRef.current.play(); }
      setZaiStatus(null);
    } catch (e) {
      setZaiStatus(null);
      toast.error(e instanceof Error ? e.message : "TTS failed.");
      setState("error");
      setTimeout(() => setState("idle"), 1200);
      setSpeaking(false);
    }
  }, [supported.tts, useZaiTts, rate, selectedVoice, voices]);

  async function send(text?: string) {
    const content = (text ?? transcript).trim();
    if (!content || state === "processing") return;
    setReply("");
    setTools([]);
    setTranscript("");
    setInterim("");
    setState("processing");
    const abort = new AbortController();
    abortRef.current = abort;
    try {
      const r = await fetch("/api/chat/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: content }),
        signal: abort.signal,
      });
      if (!r.ok || !r.body) throw new Error("Chat stream unavailable.");
      const reader = r.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let prose = "";
      const collected: { tool: string; input: Record<string, unknown> }[] = [];
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let nl: number;
        while ((nl = buffer.indexOf("\n\n")) !== -1) {
          const block = buffer.slice(0, nl).trim();
          buffer = buffer.slice(nl + 2);
          if (!block.startsWith("data:")) continue;
          const payload = block.slice(5).trim();
          if (!payload) continue;
          let ev: any;
          try { ev = JSON.parse(payload); } catch { continue; }
          if (ev.type === "delta" && ev.text) { prose += ev.text; setReply(prose); }
          else if (ev.type === "tool" && ev.tool) { collected.push({ tool: ev.tool, input: ev.input ?? {} }); setTools([...collected]); }
          else if (ev.type === "error") { toast.error(ev.message); setState("error"); setTimeout(() => setState("idle"), 1500); return; }
          else if (ev.type === "done") { /* finalize */ }
        }
      }
      setReply(prose);
      // Speak the final prose (excluding any tool-call text, which is empty).
      if (prose.trim() && settings?.voiceEnabled !== false) {
        await speak(prose);
      } else {
        setState("idle");
      }
    } catch (e) {
      if (!abort.signal.aborted) {
        toast.error(e instanceof Error ? e.message : "Voice request failed.");
        setState("error");
        setTimeout(() => setState("idle"), 1500);
      } else {
        setState("idle");
      }
    } finally {
      abortRef.current = null;
    }
  }

  function abort() {
    abortRef.current?.abort();
    stopSpeaking();
    setState("idle");
  }

  return (
    <div className="h-full overflow-y-auto jarvis-scrollbar">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 grid gap-6">
        <div className="flex flex-col items-center gap-4">
          <JarvisOrb state={state} size={260} reducedMotion={settings?.reducedMotion} />
          <div className="text-center">
            <div className="text-sm uppercase tracking-[0.2em] text-muted-foreground">{state}</div>
            <h2 className="text-xl font-semibold mt-1">
              {state === "listening" ? "I’m listening…" : state === "processing" ? "Thinking…" : state === "speaking" ? "Speaking…" : state === "error" ? "Something went wrong" : "Push to talk"}
            </h2>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-3">
          {!listening ? (
            <Button size="lg" className="rounded-full h-14 w-14 p-0 jarvis-glow" onClick={startListening} disabled={!supported.stt} aria-label="Start listening">
              <Mic className="size-6" />
            </Button>
          ) : (
            <Button size="lg" variant="destructive" className="rounded-full h-14 w-14 p-0" onClick={stopListening} aria-label="Stop listening">
              <MicOff className="size-6" />
            </Button>
          )}
          {(speaking || state === "processing") && (
            <Button size="lg" variant="outline" className="rounded-full h-12 w-12 p-0" onClick={abort} aria-label="Stop">
              <Square className="size-5" />
            </Button>
          )}
          {speaking && supported.tts && !useZaiTts && (
            <Button size="lg" variant="ghost" className="rounded-full h-12 w-12 p-0" onClick={() => { if (window.speechSynthesis.speaking) window.speechSynthesis.pause(); }} aria-label="Pause">
              <Pause className="size-5" />
            </Button>
          )}
          {speaking && supported.tts && !useZaiTts && (
            <Button size="lg" variant="ghost" className="rounded-full h-12 w-12 p-0" onClick={() => { window.speechSynthesis.resume(); }} aria-label="Resume">
              <Play className="size-5" />
            </Button>
          )}
        </div>

        {/* Permission/availability notice */}
        <div className="grid gap-2 text-center text-xs text-muted-foreground">
          {!supported.stt && <p className="flex items-center justify-center gap-1.5"><AlertTriangle className="size-3.5" /> Speech recognition is unavailable in this browser. Typed input is enabled below.</p>}
          {!supported.tts && <p className="flex items-center justify-center gap-1.5"><AlertTriangle className="size-3.5" /> Browser speech synthesis unavailable. Using the z.ai TTS fallback automatically.</p>}
        </div>

        {/* Recognized text (editable) */}
        <Card className="jarvis-panel p-4">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">Recognized speech — edit before sending if needed</Label>
          <textarea
            value={transcript + (interim ? " " + interim : "")}
            onChange={(e) => setTranscript(e.target.value)}
            placeholder="Tap the mic and speak, or type here…"
            rows={3}
            className="mt-2 w-full resize-none rounded-md border border-input bg-background/60 px-3 py-2 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
          <div className="flex justify-end gap-2 mt-3">
            <Button variant="ghost" size="sm" onClick={() => { setTranscript(""); setInterim(""); }} disabled={!transcript && !interim}>Clear</Button>
            <Button size="sm" onClick={() => send()} disabled={state === "processing" || (!transcript.trim() && !interim)}>
              <Send className="size-4" /> Send
            </Button>
          </div>
        </Card>

        {/* Reply */}
        {reply && (
          <Card className="jarvis-panel p-4">
            <div className="text-[10px] uppercase tracking-wider text-primary mb-2">JARVIS</div>
            <Markdown content={reply} />
            {tools.length > 0 && (
              <div className="mt-3 grid gap-2">
                {tools.map((t, i) => <ToolCallCard key={i} tool={t.tool} input={t.input} />)}
              </div>
            )}
            <div className="flex justify-end gap-2 mt-3">
              <Button size="sm" variant="ghost" onClick={() => speak(reply)} disabled={speaking}><Volume2 className="size-4" /> Replay</Button>
            </div>
          </Card>
        )}

        {zaiStatus && <p className="text-center text-xs text-muted-foreground">{zaiStatus}</p>}

        {/* Voice settings */}
        <Card className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-3">
            <Settings2 className="size-4 text-primary" />
            <h3 className="font-semibold text-sm">Voice settings</h3>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">TTS engine</Label>
              <Select value={useZaiTts ? "zai" : "browser"} onValueChange={(v) => setUseZaiTts(v === "zai")}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="browser" disabled={!supported.tts}>Browser (default)</SelectItem>
                  <SelectItem value="zai">z.ai neural voice</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Voice</Label>
              <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Default</SelectItem>
                  {supported.tts && voices.map((v) => <SelectItem key={v.name} value={v.name}>{v.name}</SelectItem>)}
                  {useZaiTts && <SelectItem value="tongtong">tongtong (z.ai)</SelectItem>}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex items-center justify-between mb-1">
              <Label className="text-xs">Speed</Label>
              <span className="text-xs text-muted-foreground">{rate.toFixed(2)}×</span>
            </div>
            <Slider value={[rate]} min={0.5} max={2} step={0.05} onValueChange={(v) => setRate(v[0])} />
          </div>
          <p className="text-[11px] text-muted-foreground mt-3">
            JARVIS listens only while you hold/press the mic button. Nothing is recorded in the background, and no audio is stored.
            <button className="text-primary hover:underline ml-1" onClick={() => setView("settings")}>Manage voice settings →</button>
          </p>
        </Card>

        <audio ref={audioRef} className="hidden" />
      </div>
    </div>
  );
}
