"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, FolderKanban, Pencil, Trash2, ArrowLeft, Sparkles, ListChecks, NotebookPen } from "lucide-react";
import { toast } from "sonner";
import { useApp } from "@/store/app-store";
import { useProjects, useCreateProject } from "@/hooks/use-data";
import { Markdown } from "@/components/jarvis/markdown";
import type { Project, Task, Note as NoteT } from "@/lib/types";

export function ProjectsView() {
  const { quickAction, clearQuick, activeProjectId, setActiveProject } = useApp();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Project | null>(null);
  const [detail, setDetail] = useState<(Project & { tasks: Task[]; notes: NoteT[] }) | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [plan, setPlan] = useState<string | null>(null);
  const [planning, setPlanning] = useState(false);
  const [planErr, setPlanErr] = useState<string | null>(null);

  const { data, isLoading, refetch } = useProjects("");
  const createM = useCreateProject();

  useEffect(() => {
    if (quickAction?.target === "projects" && quickAction.action === "new") {
      setEditing(null);
      setOpen(true);
      clearQuick();
    }
  }, [quickAction, clearQuick]);

  useEffect(() => {
    if (!activeProjectId) { setDetail(null); return; }
    let alive = true;
    (async () => {
      setLoadingDetail(true);
      try {
        const r = await fetch(`/api/projects/${activeProjectId}`, { cache: "no-store" });
        const j = await r.json();
        if (!j.ok) { toast.error(j.error); return; }
        if (alive) setDetail(j.project);
      } finally {
        if (alive) setLoadingDetail(false);
      }
    })();
    return () => { alive = false; };
  }, [activeProjectId]);

  if (detail) {
    return (
      <>
        <ProjectDetail
          project={detail}
          loading={loadingDetail}
          plan={plan}
          planning={planning}
          planErr={planErr}
          onBack={() => { setActiveProject(null); setDetail(null); setPlan(null); }}
          onPlan={async () => {
            setPlanning(true); setPlanErr(null);
            try {
              const r = await fetch(`/api/projects/${detail.id}/plan`, { method: "POST" });
              const j = await r.json();
              if (!j.ok) throw new Error(j.error);
              setPlan(j.plan);
            } catch (e) {
              setPlanErr(e instanceof Error ? e.message : "Planning failed.");
            } finally {
              setPlanning(false);
            }
          }}
          onEdit={() => { setEditing(detail); setOpen(true); }}
          onDeleted={async () => {
            if (!confirm("Delete this project? Tasks and notes will be detached (not deleted).")) return;
            const r = await fetch(`/api/projects/${detail.id}`, { method: "DELETE" });
            const j = await r.json();
            if (j.ok) { toast.success("Project deleted."); setActiveProject(null); setDetail(null); refetch(); }
            else toast.error(j.error);
          }}
        />
        {/* Dialog is always mounted so the Edit button from the detail view works. */}
        <Dialog open={open} onOpenChange={setOpen}>
          <ProjectDialog editing={editing} onClose={() => setOpen(false)} onSave={async (p) => {
            if (editing) {
              const r = await fetch(`/api/projects/${editing.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(p) });
              const j = await r.json();
              if (!j.ok) { toast.error(j.error); return; }
              toast.success("Project updated.");
              // Refresh detail in place.
              setDetail(j.project);
            } else {
              const r = await fetch("/api/projects", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(p) });
              const j = await r.json();
              if (!j.ok) { toast.error(j.error); return; }
              toast.success("Project created.");
            }
            setOpen(false);
            refetch();
          }} />
        </Dialog>
      </>
    );
  }

  const projects = data?.projects ?? [];

  return (
    <div className="h-full overflow-y-auto jarvis-scrollbar">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 grid gap-4">
        <div className="flex items-center gap-3">
          <div className="flex-1">
            <h2 className="text-xl font-semibold flex items-center gap-2"><FolderKanban className="size-5 text-primary" /> Projects</h2>
            <p className="text-sm text-muted-foreground">{projects.length} projects</p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => { setEditing(null); setOpen(true); }}><Plus className="size-4" /> New</Button>
            </DialogTrigger>
            <ProjectDialog editing={editing} onClose={() => setOpen(false)} onSave={async (p) => {
              if (editing) {
                await fetch(`/api/projects/${editing.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(p) });
                toast.success("Project updated.");
              } else {
                const r = await fetch("/api/projects", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(p) });
                const j = await r.json();
                if (j.ok) toast.success("Project created."); else throw new Error(j.error);
              }
              setOpen(false);
              refetch();
            }} />
          </Dialog>
        </div>

        {isLoading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-32" />)}</div>
        ) : projects.length === 0 ? (
          <Card className="jarvis-panel p-8 text-center">
            <FolderKanban className="size-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No projects yet. Create one to group tasks and notes.</p>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {projects.map((p) => (
              <button key={p.id} onClick={() => setActiveProject(p.id)} className="jarvis-panel p-4 text-left hover:jarvis-glow transition group">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium truncate group-hover:text-primary transition">{p.name}</span>
                  <span className="text-xs text-muted-foreground">{p.progress}%</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden mb-3">
                  <div className="h-full bg-primary" style={{ width: `${p.progress}%` }} />
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">{p.description || "No description."}</p>
                <div className="flex gap-3 text-[11px] text-muted-foreground mt-3">
                  <span className="flex items-center gap-1"><ListChecks className="size-3" /> {p.completedTaskCount}/{p.taskCount} tasks</span>
                  <span className="flex items-center gap-1"><NotebookPen className="size-3" /> {p.noteCount} notes</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ProjectDetail({ project, loading, plan, planning, planErr, onBack, onPlan, onEdit, onDeleted }: {
  project: Project & { tasks: Task[]; notes: NoteT[] };
  loading: boolean;
  plan: string | null;
  planning: boolean;
  planErr: string | null;
  onBack: () => void;
  onPlan: () => void;
  onEdit: () => void;
  onDeleted: () => void;
}) {
  return (
    <div className="h-full overflow-y-auto jarvis-scrollbar">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 grid gap-4">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onBack} aria-label="Back"><ArrowLeft className="size-4" /></Button>
          <div className="flex-1">
            <h2 className="text-xl font-semibold">{project.name}</h2>
            <p className="text-xs text-muted-foreground">{project.completedTaskCount}/{project.taskCount} tasks · {project.progress}% complete</p>
          </div>
          <Button variant="outline" size="sm" onClick={onEdit}><Pencil className="size-4" /> Edit</Button>
          <Button variant="ghost" size="sm" className="text-destructive" onClick={onDeleted}><Trash2 className="size-4" /> Delete</Button>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div className="h-full bg-primary transition-all" style={{ width: `${project.progress}%` }} />
        </div>

        {project.goal && (
          <Card className="jarvis-panel p-4">
            <div className="text-[10px] uppercase tracking-wider text-primary mb-1">Goal</div>
            <p className="text-sm">{project.goal}</p>
          </Card>
        )}
        {project.description && (
          <Card className="jarvis-panel p-4">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Description</div>
            <p className="text-sm whitespace-pre-wrap">{project.description}</p>
          </Card>
        )}

        {/* AI plan draft */}
        <Card className="jarvis-panel p-4">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="size-4 text-primary" />
            <h3 className="font-semibold text-sm">AI milestone plan</h3>
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground ml-auto">Draft only — nothing saved</span>
          </div>
          <p className="text-xs text-muted-foreground mb-3">Ask JARVIS to draft milestones based on this project’s real tasks. You’ll review before anything is saved.</p>
          <Button size="sm" onClick={onPlan} disabled={planning}><Sparkles className="size-4" /> {planning ? "Planning…" : "Draft a plan"}</Button>
          {planErr && <p className="text-sm text-destructive mt-2">{planErr}</p>}
          {plan && (
            <div className="mt-3">
              <Markdown content={plan} />
            </div>
          )}
        </Card>

        {/* Tasks */}
        <Card className="jarvis-panel p-4">
          <h3 className="font-semibold text-sm mb-2 flex items-center gap-2"><ListChecks className="size-4 text-primary" /> Tasks ({project.tasks.length})</h3>
          {project.tasks.length === 0 ? (
            <p className="text-xs text-muted-foreground">No tasks in this project.</p>
          ) : (
            <ul className="grid gap-1.5 text-sm">
              {project.tasks.map((t) => (
                <li key={t.id} className="flex items-center gap-2">
                  <span className={"size-2 rounded-full " + (t.status === "done" ? "bg-emerald-400" : t.status === "in_progress" ? "bg-amber-400" : "bg-muted-foreground/40")} />
                  <span className={t.status === "done" ? "line-through text-muted-foreground" : ""}>{t.title}</span>
                  {t.priority === "high" && <span className="text-[10px] text-destructive">high</span>}
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Notes */}
        <Card className="jarvis-panel p-4">
          <h3 className="font-semibold text-sm mb-2 flex items-center gap-2"><NotebookPen className="size-4 text-primary" /> Notes ({project.notes.length})</h3>
          {project.notes.length === 0 ? (
            <p className="text-xs text-muted-foreground">No notes in this project.</p>
          ) : (
            <ul className="grid gap-1.5 text-sm">
              {project.notes.map((n) => (
                <li key={n.id} className="truncate"><span className="font-medium">{n.title}</span> <span className="text-muted-foreground text-xs">· {new Date(n.updatedAt).toLocaleDateString()}</span></li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}

function ProjectDialog({ editing, onClose, onSave }: {
  editing: Project | null;
  onClose: () => void;
  onSave: (p: { name: string; description?: string; goal?: string }) => Promise<void>;
}) {
  const [name, setName] = useState(editing?.name ?? "");
  const [description, setDescription] = useState(editing?.description ?? "");
  const [goal, setGoal] = useState(editing?.goal ?? "");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setName(editing?.name ?? "");
    setDescription(editing?.description ?? "");
    setGoal(editing?.goal ?? "");
  }, [editing]);

  async function submit() {
    if (!name.trim()) { toast.error("Name is required."); return; }
    setBusy(true);
    try {
      await onSave({ name, description, goal });
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <DialogContent className="jarvis-panel max-w-lg">
      <DialogHeader>
        <DialogTitle>{editing ? "Edit project" : "New project"}</DialogTitle>
      </DialogHeader>
      <div className="grid gap-3 py-2">
        <div className="grid gap-1.5">
          <Label htmlFor="p-name">Name</Label>
          <Input id="p-name" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="p-goal">Goal</Label>
          <Input id="p-goal" value={goal} onChange={(e) => setGoal(e.target.value)} placeholder="What does success look like?" />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="p-desc">Description</Label>
          <Textarea id="p-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
        </div>
      </div>
      <DialogFooter>
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button onClick={submit} disabled={busy}>{busy ? "Saving…" : "Save"}</Button>
      </DialogFooter>
    </DialogContent>
  );
}
