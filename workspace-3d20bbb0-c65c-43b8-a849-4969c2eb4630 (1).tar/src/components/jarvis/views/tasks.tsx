"use client";

import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Search, Trash2, Pencil, ListChecks, Circle, CheckCircle2, Clock } from "lucide-react";
import { toast } from "sonner";
import { useApp } from "@/store/app-store";
import { useTasks, useCreateTask, useUpdateTask, useDeleteTask, useProjects } from "@/hooks/use-data";
import type { Priority, Task, TaskStatus } from "@/lib/types";

const VIEWS = [
  { id: "active", label: "Open" },
  { id: "today", label: "Today" },
  { id: "upcoming", label: "Upcoming" },
  { id: "completed", label: "Completed" },
  { id: "all", label: "All" },
] as const;

export function TasksView() {
  const { quickAction, clearQuick } = useApp();
  const [view, setView] = useState<(typeof VIEWS)[number]["id"]>("active");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Task | null>(null);

  const { data, isLoading, refetch } = useTasks(view, q);
  const { projects } = useProjects("").data ?? {};
  const createM = useCreateTask();
  const updateM = useUpdateTask();
  const deleteM = useDeleteTask();

  useEffect(() => {
    if (quickAction?.target === "tasks" && quickAction.action === "new") {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setEditing(null);
      setOpen(true);
      clearQuick();
    }
  }, [quickAction, clearQuick]);

  const tasks = data?.tasks ?? [];
  const counts = useMemo(() => ({
    open: tasks.filter((t) => t.status !== "done").length,
    done: tasks.filter((t) => t.status === "done").length,
    high: tasks.filter((t) => t.priority === "high" && t.status !== "done").length,
  }), [tasks]);

  async function toggle(t: Task) {
    await updateM.mutateAsync({ id: t.id, patch: { status: t.status === "done" ? "todo" : "done" } });
  }

  async function remove(t: Task) {
    if (!confirm(`Delete task "${t.title}"?`)) return;
    await deleteM.mutateAsync(t.id);
    toast.success("Task deleted.");
  }

  return (
    <div className="h-full overflow-y-auto jarvis-scrollbar">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 grid gap-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex-1">
            <h2 className="text-xl font-semibold flex items-center gap-2"><ListChecks className="size-5 text-primary" /> Tasks</h2>
            <p className="text-sm text-muted-foreground">{counts.open} open · {counts.high} high priority · {counts.done} completed</p>
          </div>
          <div className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search tasks…" className="pl-8 w-56 bg-background/60" />
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => { setEditing(null); setOpen(true); }}><Plus className="size-4" /> New</Button>
              </DialogTrigger>
              <TaskDialog
                editing={editing}
                projects={projects ?? []}
                onClose={() => setOpen(false)}
                onSave={async (payload) => {
                  if (editing) await updateM.mutateAsync({ id: editing.id, patch: payload });
                  else await createM.mutateAsync(payload as Task);
                  setOpen(false);
                  refetch();
                }}
              />
            </Dialog>
          </div>
        </div>

        {/* View tabs */}
        <div className="flex flex-wrap gap-1.5">
          {VIEWS.map((v) => (
            <button
              key={v.id}
              onClick={() => setView(v.id)}
              className={"px-3 py-1.5 rounded-full text-xs font-medium border transition " + (view === v.id ? "bg-primary/15 border-primary/40 text-primary" : "border-border/60 text-muted-foreground hover:bg-accent/50")}
            >
              {v.label}
            </button>
          ))}
        </div>

        {/* List */}
        <div className="grid gap-2">
          {isLoading ? (
            <div className="grid gap-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}</div>
          ) : tasks.length === 0 ? (
            <Card className="jarvis-panel p-8 text-center">
              <ListChecks className="size-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No tasks here. Create one to get started.</p>
            </Card>
          ) : (
            tasks.map((t) => <TaskRow key={t.id} t={t} onToggle={() => toggle(t)} onEdit={() => { setEditing(t); setOpen(true); }} onDelete={() => remove(t)} />)
          )}
        </div>
      </div>
    </div>
  );
}

function priorityBadge(p: Priority) {
  const cls = p === "high" ? "bg-destructive/20 text-destructive" : p === "medium" ? "bg-amber-500/20 text-amber-300" : "bg-emerald-500/20 text-emerald-300";
  return <span className={"text-[10px] px-1.5 py-0.5 rounded " + cls}>{p}</span>;
}

function TaskRow({ t, onToggle, onEdit, onDelete }: { t: Task; onToggle: () => void; onEdit: () => void; onDelete: () => void }) {
  const done = t.status === "done";
  return (
    <Card className="jarvis-panel p-3 flex items-start gap-3">
      <button onClick={onToggle} className="mt-0.5" aria-label={done ? "Mark not done" : "Mark done"}>
        {done ? <CheckCircle2 className="size-5 text-emerald-400" /> : <Circle className="size-5 text-muted-foreground hover:text-primary" />}
      </button>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className={"font-medium truncate " + (done ? "line-through text-muted-foreground" : "")}>{t.title}</span>
          {priorityBadge(t.priority)}
          {t.category && <Badge variant="outline" className="text-[10px]">{t.category}</Badge>}
        </div>
        {t.description && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{t.description}</p>}
        {t.dueDate && (
          <div className={"text-[11px] mt-1 flex items-center gap-1 " + (new Date(t.dueDate) < new Date() && !done ? "text-destructive" : "text-muted-foreground")}>
            <Clock className="size-3" /> {new Date(t.dueDate).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
          </div>
        )}
      </div>
      <div className="flex items-center gap-1">
        <Button size="icon" variant="ghost" className="size-8" onClick={onEdit} aria-label="Edit"><Pencil className="size-3.5" /></Button>
        <Button size="icon" variant="ghost" className="size-8 text-destructive" onClick={onDelete} aria-label="Delete"><Trash2 className="size-3.5" /></Button>
      </div>
    </Card>
  );
}

function TaskDialog({ editing, projects, onClose, onSave }: {
  editing: Task | null;
  projects: { id: string; name: string }[];
  onClose: () => void;
  onSave: (p: Partial<Task>) => Promise<void>;
}) {
  const [title, setTitle] = useState(editing?.title ?? "");
  const [description, setDescription] = useState(editing?.description ?? "");
  const [priority, setPriority] = useState<Priority>((editing?.priority as Priority) ?? "medium");
  const [category, setCategory] = useState(editing?.category ?? "");
  const [status, setStatus] = useState<TaskStatus>((editing?.status as TaskStatus) ?? "todo");
  const [dueDate, setDueDate] = useState(editing?.dueDate ? editing.dueDate.slice(0, 16) : "");
  const [projectId, setProjectId] = useState(editing?.projectId ?? "");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setTitle(editing?.title ?? "");
    setDescription(editing?.description ?? "");
    setPriority((editing?.priority as Priority) ?? "medium");
    setCategory(editing?.category ?? "");
    setStatus((editing?.status as TaskStatus) ?? "todo");
    setDueDate(editing?.dueDate ? editing.dueDate.slice(0, 16) : "");
    setProjectId(editing?.projectId ?? "");
  }, [editing]);

  async function submit() {
    if (!title.trim()) { toast.error("Title is required."); return; }
    setBusy(true);
    try {
      await onSave({
        title, description, priority, category, status,
        dueDate: dueDate ? new Date(dueDate).toISOString() : null,
        projectId: projectId || null,
      });
      toast.success(editing ? "Task updated." : "Task created.");
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <DialogContent className="jarvis-panel max-w-lg">
      <DialogHeader>
        <DialogTitle>{editing ? "Edit task" : "New task"}</DialogTitle>
      </DialogHeader>
      <div className="grid gap-3 py-2">
        <div className="grid gap-1.5">
          <Label htmlFor="t-title">Title</Label>
          <Input id="t-title" value={title} onChange={(e) => setTitle(e.target.value)} autoFocus />
        </div>
        <div className="grid gap-1.5">
          <Label htmlFor="t-desc">Description</Label>
          <Textarea id="t-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-1.5">
            <Label>Priority</Label>
            <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label>Status</Label>
            <Select value={status} onValueChange={(v) => setStatus(v as TaskStatus)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="todo">To do</SelectItem>
                <SelectItem value="in_progress">In progress</SelectItem>
                <SelectItem value="done">Done</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="t-cat">Category</Label>
            <Input id="t-cat" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="e.g. health" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="t-due">Due date</Label>
            <Input id="t-due" type="datetime-local" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </div>
        </div>
        <div className="grid gap-1.5">
          <Label>Project (optional)</Label>
          <Select value={projectId || "none"} onValueChange={(v) => setProjectId(v === "none" ? "" : v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">No project</SelectItem>
              {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <DialogFooter>
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button onClick={submit} disabled={busy}>{busy ? "Saving…" : "Save"}</Button>
      </DialogFooter>
    </DialogContent>
  );
}
