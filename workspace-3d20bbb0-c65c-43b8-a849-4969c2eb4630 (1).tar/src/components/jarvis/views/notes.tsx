"use client";

import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { NotebookPen, Plus, Search, Trash2, Save, Sparkles, Eye, Pencil, X } from "lucide-react";
import { toast } from "sonner";
import { useApp } from "@/store/app-store";
import { useNotes, useCreateNote, useUpdateNote, useDeleteNote, useProjects } from "@/hooks/use-data";
import { Markdown } from "@/components/jarvis/markdown";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Note } from "@/lib/types";

export function NotesView() {
  const { quickAction, clearQuick } = useApp();
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<Note | null>(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<Note | null>(null);

  const { data, isLoading, refetch } = useNotes(q);
  const { projects } = useProjects("").data ?? {};
  const createM = useCreateNote();
  const updateM = useUpdateNote();
  const deleteM = useDeleteNote();

  useEffect(() => {
    if (quickAction?.target === "notes" && quickAction.action === "new") {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setEditing(null);
      setEditorOpen(true);
      clearQuick();
    }
  }, [quickAction, clearQuick]);

  const notes = data?.notes ?? [];

  return (
    <div className="h-full grid lg:grid-cols-[320px_1fr]">
      {/* List */}
      <div className={"border-r border-border/70 bg-card/40 flex flex-col " + (selected && "hidden lg:flex")}>
        <div className="p-3 border-b border-border/70 flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search notes…" className="pl-8 bg-background/60" />
          </div>
          <Button size="icon" onClick={() => { setEditing(null); setEditorOpen(true); }} aria-label="New note"><Plus className="size-4" /></Button>
        </div>
        <div className="flex-1 overflow-y-auto jarvis-scrollbar p-2">
          {isLoading ? (
            <div className="grid gap-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
          ) : notes.length === 0 ? (
            <div className="p-6 text-center">
              <NotebookPen className="size-7 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">No notes yet.</p>
            </div>
          ) : (
            <ul className="grid gap-1">
              {notes.map((n) => (
                <li key={n.id}>
                  <button
                    onClick={() => setSelected(n)}
                    className={"w-full text-left rounded-lg p-2.5 transition " + (selected?.id === n.id ? "bg-primary/15 border border-primary/30" : "hover:bg-accent/50 border border-transparent")}
                  >
                    <div className="font-medium text-sm truncate">{n.title || "Untitled"}</div>
                    <div className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{stripMd(n.content)}</div>
                    <div className="text-[10px] text-muted-foreground mt-1">{new Date(n.updatedAt).toLocaleString()}</div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Detail / editor */}
      <div className="overflow-y-auto jarvis-scrollbar">
        {editorOpen ? (
          <NoteEditor
            note={editing}
            projects={projects ?? []}
            onClose={() => { setEditorOpen(false); setEditing(null); }}
            onSave={async (payload) => {
              if (editing) await updateM.mutateAsync({ id: editing.id, patch: payload });
              else { const created = await createM.mutateAsync(payload as Note); setSelected(created); }
              setEditorOpen(false);
              setEditing(null);
              refetch();
            }}
          />
        ) : selected ? (
          <NoteDetail
            note={selected}
            onEdit={() => { setEditing(selected); setEditorOpen(true); }}
            onBack={() => setSelected(null)}
            onDelete={async () => {
              if (!confirm("Delete this note?")) return;
              await deleteM.mutateAsync(selected.id);
              setSelected(null);
              refetch();
              toast.success("Note deleted.");
            }}
          />
        ) : (
          <div className="h-full grid place-items-center p-8 text-center">
            <div>
              <NotebookPen className="size-10 mx-auto text-muted-foreground mb-3" />
              <p className="text-sm text-muted-foreground">Select a note, or create a new one.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function stripMd(md: string) {
  return md.replace(/[#*`>\-]/g, "").replace(/\s+/g, " ").trim().slice(0, 120);
}

function NoteDetail({ note, onEdit, onBack, onDelete }: { note: Note; onEdit: () => void; onBack: () => void; onDelete: () => void }) {
  const [summary, setSummary] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function summarize() {
    setBusy(true); setErr(null);
    try {
      const r = await fetch(`/api/notes/${note.id}/summarize`, { method: "POST" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
      setSummary(j.summary);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Summarization failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6">
      <div className="flex items-start gap-2 mb-3">
        <Button variant="ghost" size="icon" className="lg:hidden" onClick={onBack} aria-label="Back to notes"><X className="size-4" /></Button>
        <div className="flex-1">
          <h2 className="text-xl font-semibold">{note.title || "Untitled"}</h2>
          <p className="text-xs text-muted-foreground">Updated {new Date(note.updatedAt).toLocaleString()}</p>
        </div>
        <Button variant="outline" size="sm" onClick={summarize} disabled={busy}><Sparkles className="size-4" /> {busy ? "Summarizing…" : "Summarize"}</Button>
        <Button variant="ghost" size="icon" onClick={onEdit} aria-label="Edit"><Pencil className="size-4" /></Button>
        <Button variant="ghost" size="icon" className="text-destructive" onClick={onDelete} aria-label="Delete"><Trash2 className="size-4" /></Button>
      </div>
      {err && <p className="text-sm text-destructive mb-3">{err}</p>}
      {summary && (
        <Card className="jarvis-panel p-4 mb-3 border-primary/30">
          <div className="text-[10px] uppercase tracking-wider text-primary mb-1 flex items-center gap-1"><Sparkles className="size-3" /> AI summary</div>
          <Markdown content={summary} />
          <button className="text-xs text-muted-foreground hover:text-foreground mt-2" onClick={() => setSummary(null)}>Dismiss</button>
        </Card>
      )}
      <Card className="jarvis-panel p-4">
        <Markdown content={note.content || "_Empty note._"} />
      </Card>
    </div>
  );
}

function NoteEditor({ note, projects, onClose, onSave }: {
  note: Note | null;
  projects: { id: string; name: string }[];
  onClose: () => void;
  onSave: (p: { title: string; content: string; projectId?: string | null }) => Promise<void>;
}) {
  const [title, setTitle] = useState(note?.title ?? "");
  const [content, setContent] = useState(note?.content ?? "");
  const [projectId, setProjectId] = useState(note?.projectId ?? "");
  const [preview, setPreview] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setTitle(note?.title ?? "");
    setContent(note?.content ?? "");
    setProjectId(note?.projectId ?? "");
    setPreview(false);
  }, [note]);

  async function save() {
    if (!title.trim()) { toast.error("Title is required."); return; }
    setBusy(true);
    try {
      await onSave({ title, content, projectId: projectId || null });
      toast.success(note ? "Note updated." : "Note saved.");
      onClose();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 grid gap-3">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={onClose} aria-label="Close"><X className="size-4" /></Button>
        <h2 className="text-xl font-semibold flex-1">{note ? "Edit note" : "New note"}</h2>
        <Button variant="outline" size="sm" onClick={() => setPreview((p) => !p)}>{preview ? <Pencil className="size-4" /> : <Eye className="size-4" />}{preview ? "Edit" : "Preview"}</Button>
        <Button size="sm" onClick={save} disabled={busy}><Save className="size-4" /> {busy ? "Saving…" : "Save"}</Button>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="n-title">Title</Label>
        <Input id="n-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Note title" />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="n-project">Project (optional)</Label>
        <Select value={projectId || "none"} onValueChange={(v) => setProjectId(v === "none" ? "" : v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No project</SelectItem>
            {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-2 flex-1 min-h-0">
        <Label>{preview ? "Preview" : "Content (Markdown)"}</Label>
        {preview ? (
          <Card className="jarvis-panel p-4 min-h-[300px]"><Markdown content={content || "_Nothing to preview._"} /></Card>
        ) : (
          <Textarea value={content} onChange={(e) => setContent(e.target.value)} rows={16} className="font-mono text-sm bg-background/60 min-h-[300px]" placeholder="# Heading&#10;&#10;Write your note in **markdown**…" />
        )}
      </div>
    </div>
  );
}
