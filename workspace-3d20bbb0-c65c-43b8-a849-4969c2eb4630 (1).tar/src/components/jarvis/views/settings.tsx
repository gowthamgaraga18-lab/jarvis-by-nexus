"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { Settings as SettingsIcon, User, Cpu, Volume2, Palette, ShieldCheck, Trash2, RefreshCw, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useSettings } from "@/hooks/use-settings";
import { useAuth } from "@/components/providers/auth-provider";
import { useQuery } from "@tanstack/react-query";
import type { ConnectionStatus } from "@/lib/types";

export function SettingsView({ micGranted }: { micGranted: "unknown" | "granted" | "denied" | "unsupported" }) {
  const { settings, models, update, isLoading } = useSettings();
  const { user } = useAuth();
  const [displayName, setDisplayName] = useState("");
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => { if (settings) setDisplayName(settings.displayName); }, [settings]);

  const status = useQuery<{ connections: ConnectionStatus[] }>({
    queryKey: ["status"],
    queryFn: async () => {
      const r = await fetch("/api/status", { cache: "no-store" });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
      return j;
    },
  });

  async function patch(key: string, value: any) {
    setSaving(key);
    try {
      await update({ [key]: value });
      toast.success("Saved.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save.");
    } finally {
      setSaving(null);
    }
  }

  if (isLoading || !settings) {
    return (
      <div className="h-full overflow-y-auto jarvis-scrollbar p-6 max-w-3xl mx-auto grid gap-3">
        {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-28" />)}
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto jarvis-scrollbar">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 grid gap-4">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2"><SettingsIcon className="size-5 text-primary" /> Settings</h2>
          <p className="text-sm text-muted-foreground">Personalize JARVIS. Changes apply immediately.</p>
        </div>

        {/* Profile */}
        <Section icon={User} title="Profile">
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="dn">Display name</Label>
              <div className="flex gap-2">
                <Input id="dn" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
                <Button onClick={async () => { await update({ displayName }); toast.success("Name updated."); }}>Save</Button>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label>Email</Label>
              <Input value={user?.email ?? ""} disabled className="bg-muted/40" />
            </div>
          </div>
        </Section>

        {/* AI */}
        <Section icon={Cpu} title="AI brain">
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label>Model</Label>
              <Select value={settings.model} onValueChange={(v) => patch("model", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {models?.map((m) => <SelectItem key={m.id} value={m.id}>{m.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="text-[11px] text-muted-foreground">Availability depends on the configured provider. If a model is unavailable the API will surface a real error.</p>
            </div>
            <div className="grid gap-1.5">
              <Label>Response style</Label>
              <Select value={settings.responseStyle} onValueChange={(v) => patch("responseStyle", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="concise">Concise</SelectItem>
                  <SelectItem value="balanced">Balanced</SelectItem>
                  <SelectItem value="detailed">Detailed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Section>

        {/* Voice */}
        <Section icon={Volume2} title="Voice">
          <div className="grid gap-3">
            <Row label="Enable voice (spoken answers)" desc="JARVIS will read replies aloud in the Voice view.">
              <Switch checked={settings.voiceEnabled} onCheckedChange={(v) => patch("voiceEnabled", v)} />
            </Row>
            <div className="grid gap-1.5">
              <Label>Speech rate</Label>
              <div className="flex items-center gap-3">
                <Slider value={[settings.ttsRate]} min={0.5} max={2} step={0.05} onValueChange={(v) => patch("ttsRate", v[0])} className="flex-1" />
                <span className="text-xs text-muted-foreground w-12 text-right">{settings.ttsRate.toFixed(2)}×</span>
              </div>
            </div>
            <div className="text-xs text-muted-foreground border border-border/60 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <MicStatus granted={micGranted} />
                <span>Microphone permission: {micGranted}</span>
              </div>
              Listening is push-to-talk only — JARVIS never records audio in the background and stores no recordings.
            </div>
          </div>
        </Section>

        {/* Appearance */}
        <Section icon={Palette} title="Appearance">
          <div className="grid gap-3">
            <Row label="Theme" desc="Dark is the canonical JARVIS look.">
              <Select value={settings.theme} onValueChange={(v) => patch("theme", v)}>
                <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="dark">Dark</SelectItem>
                  <SelectItem value="light">Light</SelectItem>
                </SelectContent>
              </Select>
            </Row>
            <Row label="Reduce motion" desc="Disable nonessential animations.">
              <Switch checked={settings.reducedMotion} onCheckedChange={(v) => patch("reducedMotion", v)} />
            </Row>
          </div>
        </Section>

        {/* Memory */}
        <Section icon={ShieldCheck} title="Memory & data">
          <div className="grid gap-3">
            <Row label="Enable memory" desc="Let JARVIS remember preferences across sessions.">
              <Switch checked={settings.memoryEnabled} onCheckedChange={(v) => patch("memoryEnabled", v)} />
            </Row>
            <Row label="Delete all conversations" desc="Permanently removes every chat session and message.">
              <Button variant="destructive" size="sm" onClick={async () => {
                if (!confirm("Permanently delete ALL conversations?")) return;
                // No bulk endpoint exists; iterate sessions.
                const r = await fetch("/api/chat/sessions", { cache: "no-store" });
                const j = await r.json();
                for (const c of j.conversations ?? []) {
                  await fetch(`/api/chat/sessions/${c.id}`, { method: "DELETE" });
                }
                toast.success("All conversations deleted.");
              }}>
                <Trash2 className="size-4" /> Delete
              </Button>
            </Row>
          </div>
        </Section>

        {/* Connected services */}
        <Section icon={RefreshCw} title="Connected services">
          <div className="grid gap-2">
            <div className="flex justify-end">
              <Button variant="outline" size="sm" onClick={() => status.refetch()} disabled={status.isFetching}>
                <RefreshCw className={"size-4 " + (status.isFetching ? "animate-spin" : "")} /> Re-check
              </Button>
            </div>
            {status.data?.connections.map((c) => <ConnectionRow key={c.id} c={c} />)}
            {!status.data && status.isFetching && <Skeleton className="h-14" />}
            <p className="text-[11px] text-muted-foreground pt-1">
              JARVIS shows the real status of each integration. It never claims a connection that isn’t actually configured.
            </p>
          </div>
        </Section>
      </div>
    </div>
  );
}

function Section({ icon: Icon, title, children }: { icon: React.ElementType; title: string; children: React.ReactNode }) {
  return (
    <Card className="jarvis-panel p-5">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="size-4 text-primary" />
        <h3 className="font-semibold text-sm">{title}</h3>
      </div>
      {children}
    </Card>
  );
}

function Row({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <div className="text-sm font-medium">{label}</div>
        {desc && <div className="text-xs text-muted-foreground">{desc}</div>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function ConnectionRow({ c }: { c: ConnectionStatus }) {
  const Icon = c.status === "connected" ? CheckCircle2 : c.status === "error" ? XCircle : Loader2;
  const tone = c.status === "connected" ? "text-emerald-400" : c.status === "error" ? "text-destructive" : "text-muted-foreground";
  return (
    <div className="flex items-start gap-3 border border-border/60 rounded-lg p-3 bg-background/30">
      <Icon className={"size-4 mt-0.5 " + tone + (c.status === "not_configured" ? " animate-pulse" : "")} />
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium">{c.name}</div>
        <div className="text-xs text-muted-foreground">{c.description}</div>
        {c.detail && <div className="text-[11px] text-muted-foreground mt-1">{c.detail}</div>}
      </div>
      <Badge tone={c.status}>{c.status}</Badge>
    </div>
  );
}

function Badge({ tone, children }: { tone: ConnectionStatus["status"]; children: React.ReactNode }) {
  const cls = tone === "connected" ? "bg-emerald-500/15 text-emerald-300" : tone === "error" ? "bg-destructive/15 text-destructive" : "bg-muted/40 text-muted-foreground";
  return <span className={"text-[10px] uppercase tracking-wider px-2 py-0.5 rounded " + cls}>{children}</span>;
}

function MicStatus({ granted }: { granted: string }) {
  const Icon = granted === "granted" ? CheckCircle2 : granted === "denied" || granted === "unsupported" ? XCircle : Loader2;
  const tone = granted === "granted" ? "text-emerald-400" : (granted === "denied" || granted === "unsupported") ? "text-destructive" : "text-muted-foreground";
  return <Icon className={"size-4 " + tone} />;
}
