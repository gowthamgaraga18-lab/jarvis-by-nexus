"use client";

import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Wand2, Loader2, Download, Trash2, Sparkles, ImageIcon, Save } from "lucide-react";
import { toast } from "sonner";
import { useImagesStore } from "@/store/images-store";
import type { ImageSize } from "@/lib/types";

const SIZES: { id: ImageSize; label: string }[] = [
  { id: "1024x1024", label: "Square · 1024×1024" },
  { id: "1344x768", label: "Landscape · 1344×768" },
  { id: "768x1344", label: "Portrait · 768×1344" },
  { id: "1440x720", label: "Wide · 1440×720" },
  { id: "720x1440", label: "Tall · 720×1440" },
];

const PRESETS = [
  "A serene mountain lake at sunset, cinematic, ultra detailed",
  "Futuristic command center, holographic UI, cyan glow, dark graphite",
  "A robot butler serving tea in a sunlit conservatory, studio lighting",
  "Minimalist poster of a fox made of circuit boards",
  "Anime-style city street at night after rain, neon reflections",
];

export function ImageStudioView() {
  const [prompt, setPrompt] = useState("");
  const [size, setSize] = useState<ImageSize>("1024x1024");
  const { images, removeImage, clear } = useImagesStore();

  const generate = useMutation({
    mutationFn: async () => {
      const r = await fetch("/api/images/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, size }),
      });
      const j = await r.json();
      if (!j.ok) throw new Error(j.error);
      return j.images as string[];
    },
    onSuccess: (imgs) => {
      for (const src of imgs) useImagesStore.getState().addImage({ src, prompt, size });
      toast.success(`Generated ${imgs.length} image${imgs.length > 1 ? "s" : ""}.`);
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Generation failed."),
  });

  async function saveAsNote(src: string, p: string) {
    try {
      const r = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: `Image: ${p.slice(0, 50)}`, content: `![${p}](${src})\n\n_Prompt:_ ${p}` }),
      });
      const j = await r.json();
      if (j.ok) toast.success("Saved as note.");
      else toast.error(j.error || "Could not save note (database schema not applied?).");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Save failed.");
    }
  }

  return (
    <div className="h-full overflow-y-auto jarvis-scrollbar">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 grid gap-5">
        <div>
          <h2 className="text-xl font-semibold flex items-center gap-2"><Wand2 className="size-5 text-primary" /> Image Studio</h2>
          <p className="text-sm text-muted-foreground">Generate images from text with z.ai. Generated images stay in this session; save the ones you like to a note.</p>
        </div>

        <Card className="jarvis-panel p-5">
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="prompt">Prompt</Label>
              <Input id="prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Describe the image you want…" className="bg-background/60" />
            </div>
            <div className="grid sm:grid-cols-[1fr_auto] gap-3">
              <div className="grid gap-1.5">
                <Label>Size</Label>
                <Select value={size} onValueChange={(v) => setSize(v as ImageSize)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SIZES.map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button onClick={() => generate.mutate()} disabled={generate.isPending || prompt.trim().length < 3} className="h-9">
                  {generate.isPending ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
                  {generate.isPending ? "Generating…" : "Generate"}
                </Button>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 pt-1">
              {PRESETS.map((p) => (
                <button key={p} onClick={() => setPrompt(p)} className="text-xs rounded-full border border-border/60 px-2.5 py-1 text-muted-foreground hover:bg-accent/50 hover:text-foreground transition">
                  {p.slice(0, 40)}…
                </button>
              ))}
            </div>
          </div>
        </Card>

        {images.length === 0 ? (
          <Card className="jarvis-panel p-10 text-center">
            <ImageIcon className="size-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">No images yet. Enter a prompt and hit Generate.</p>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {images.map((img) => (
              <Card key={img.id} className="jarvis-panel p-3 overflow-hidden">
                <img src={img.src} alt={img.prompt} className="rounded-lg w-full" />
                <div className="px-1 pt-3">
                  <p className="text-xs text-muted-foreground line-clamp-2">{img.prompt}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-[10px] text-muted-foreground">{img.size} · {new Date(img.createdAt).toLocaleTimeString()}</span>
                    <div className="flex gap-1">
                      <a href={img.src} download={`jarvis-${img.id}.png`} className="rounded-md border border-border/60 p-1.5 hover:bg-accent/50" title="Download"><Download className="size-3.5" /></a>
                      <button onClick={() => saveAsNote(img.src, img.prompt)} className="rounded-md border border-border/60 p-1.5 hover:bg-accent/50" title="Save as note"><Save className="size-3.5" /></button>
                      <button onClick={() => removeImage(img.id)} className="rounded-md border border-border/60 p-1.5 hover:bg-accent/50 text-destructive" title="Delete"><Trash2 className="size-3.5" /></button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
        {images.length > 0 && (
          <div className="flex justify-end">
            <Button variant="ghost" size="sm" className="text-destructive" onClick={() => { if (confirm("Clear all generated images from this session?")) clear(); }}>Clear session</Button>
          </div>
        )}
      </div>
    </div>
  );
}
