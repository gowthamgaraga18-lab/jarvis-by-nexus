"use client";

import { useEffect, useState } from "react";
import { JarvisOrb } from "@/components/jarvis/orb";
import { useApp } from "@/store/app-store";
import { useAuth } from "@/components/providers/auth-provider";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ListChecks, NotebookPen, FolderKanban, Mic, Send, Sparkles, CalendarClock, Circle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { TaskCharts } from "@/components/jarvis/task-charts";
import { useTasks } from "@/hooks/use-data";
import type { AssistantState } from "@/lib/types";

interface Briefing {
  greeting: string;
  narrative: string | null;
  narrativeError: string | null;
  counts: { totalOpen: number; totalDone: number; overdue: number; today: number; upcoming: number };
  tasksToday: { id: string; title: string; priority: string; dueDate: string | null }[];
  upcoming: { id: string; title: string; priority: string; dueDate: string | null }[];
  overdue: { id: string; title: string; priority: string; dueDate: string | null }[];
  projects: { id: string; name: string; progress: number }[];
}

export function DashboardView() {
  const { user } = useAuth();
  const { setView, launchQuick, setActiveConversation } = useApp();
  const [orb, setOrb] = useState<AssistantState>("idle");
  const [ask, setAsk] = useState("");
  const [briefing, setBriefing] = useState<Briefing | null>(null);
  const [briefingLoading, setBriefingLoading] = useState(true);
  const allTasks = useTasks("all", "");

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const r = await fetch("/api/briefing", { cache: "no-store" });
        const j = await r.json();
        if (alive && j.ok) setBriefing(j.briefing);
      } finally {
        if (alive) setBriefingLoading(false);
      }
    })();
    return () => { alive = false; };
  }, []);

  async function askJarvis(e: React.FormEvent) {
    e.preventDefault();
    if (!ask.trim()) return;
    setOrb("processing");
    try {
      // Send to chat. Parse the SSE stream so we can (a) wait for the assistant
      // reply to be persisted and (b) capture the new conversationId so the
      // Chat view opens directly on that conversation.
      const r = await fetch("/api/chat/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: ask }),
      });
      if (!r.ok || !r.body) throw new Error("Chat stream failed.");
      const reader = r.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let convId: string | null = null;
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let nl: number;
        while ((nl = buffer.indexOf("\n\n")) !== -1) {
          const block = buffer.slice(0, nl).trim();
          buffer = buffer.slice(nl + 2);
          if (!block.startsWith("data:")) continue;
          const payload = block.slice(5).trim();
          if (!payload) continue;
          try {
            const ev = JSON.parse(payload);
            if (ev.type === "conv" && ev.conversationId) convId = ev.conversationId;
          } catch { /* ignore malformed */ }
        }
      }
      setAsk("");
      if (convId) setActiveConversation(convId);
      setView("chat");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to reach JARVIS.");
      setOrb("error");
      setTimeout(() => setOrb("idle"), 1500);
    } finally {
      setOrb("idle");
    }
  }

  return (
    <div className="h-full overflow-y-auto jarvis-scrollbar">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 grid gap-6">
        {/* Greeting + orb */}
        <section className="grid lg:grid-cols-[1fr_auto_1fr] items-center gap-6">
          <div className="hidden lg:block" />
          <div className="flex flex-col items-center gap-4">
            <JarvisOrb state={orb} size={240} reducedMotion={false} />
            <div className="text-center">
              <p className="text-sm text-muted-foreground">{briefing?.greeting ?? `Welcome back, ${user?.displayName ?? "User"}.`}</p>
              <h2 className="text-2xl font-semibold tracking-tight">How may I help you?</h2>
            </div>
          </div>
          <div className="hidden lg:block" />
        </section>

        {/* Ask JARVIS */}
        <Card className="jarvis-panel p-4">
          <form onSubmit={askJarvis} className="flex flex-col sm:flex-row gap-3">
            <Input
              autoFocus
              value={ask}
              onChange={(e) => setAsk(e.target.value)}
              placeholder="Ask JARVIS anything, or ask me to create a task…"
              className="flex-1 bg-background/60"
            />
            <div className="flex gap-2">
              <Button type="button" variant="outline" size="icon" aria-label="Voice" onClick={() => setView("voice")}>
                <Mic className="size-4" />
              </Button>
              <Button type="submit" size="icon" disabled={orb === "processing"} aria-label="Send">
                <Send className="size-4" />
              </Button>
            </div>
          </form>
          <p className="text-xs text-muted-foreground mt-2">
            Try: <em>“Remind me to call the dentist tomorrow”</em> · JARVIS will draft a task and ask before saving.
          </p>
        </Card>

        {/* Quick actions */}
        <section className="grid sm:grid-cols-3 gap-3">
          <QuickAction icon={ListChecks} label="New Task" desc="Capture something to do" onClick={() => launchQuick("tasks", "new")} />
          <QuickAction icon={NotebookPen} label="New Note" desc="Write down an idea" onClick={() => launchQuick("notes", "new")} />
          <QuickAction icon={FolderKanban} label="New Project" desc="Group tasks & notes" onClick={() => launchQuick("projects", "new")} />
        </section>

        {/* Briefing + counts */}
        <section className="grid lg:grid-cols-3 gap-4">
          <Card className="jarvis-panel p-5 lg:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="size-4 text-primary" />
              <h3 className="font-semibold">Daily Briefing</h3>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground ml-auto">Generated from your data</span>
            </div>
            {briefingLoading ? (
              <div className="grid gap-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-5/6" />
                <Skeleton className="h-4 w-2/3" />
              </div>
            ) : briefing?.narrativeError ? (
              <p className="text-sm text-destructive">Briefing unavailable: {briefing.narrativeError}</p>
            ) : (
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{briefing?.narrative ?? "No briefing right now."}</p>
            )}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-4">
              <Stat label="Open" value={briefing?.counts.totalOpen ?? 0} />
              <Stat label="Today" value={briefing?.counts.today ?? 0} />
              <Stat label="Upcoming" value={briefing?.counts.upcoming ?? 0} />
              <Stat label="Overdue" value={briefing?.counts.overdue ?? 0} tone={briefing?.counts.overdue ? "warn" : "default"} />
              <Stat label="Done" value={briefing?.counts.totalDone ?? 0} tone="ok" />
            </div>
          </Card>

          <Card className="jarvis-panel p-5">
            <div className="flex items-center gap-2 mb-3">
              <CalendarClock className="size-4 text-primary" />
              <h3 className="font-semibold">Today’s Tasks</h3>
              <button className="text-[11px] text-primary ml-auto hover:underline" onClick={() => setView("tasks")}>View all</button>
            </div>
            {briefingLoading ? (
              <div className="grid gap-2"><Skeleton className="h-4 w-3/4" /><Skeleton className="h-4 w-2/3" /></div>
            ) : (briefing?.tasksToday ?? []).length === 0 ? (
              <EmptyRow text="Nothing due today." />
            ) : (
              <ul className="grid gap-2 text-sm">
                {briefing!.tasksToday.slice(0, 6).map((t) => <TaskRow key={t.id} title={t.title} priority={t.priority} />)}
              </ul>
            )}
            {(briefing?.overdue ?? []).length > 0 && (
              <div className="mt-3 pt-3 border-t border-border/60">
                <p className="text-[11px] uppercase tracking-wider text-destructive mb-2">Overdue</p>
                <ul className="grid gap-1.5 text-sm">
                  {briefing!.overdue.slice(0, 3).map((t) => <TaskRow key={t.id} title={t.title} priority={t.priority} overdue />)}
                </ul>
              </div>
            )}
          </Card>
        </section>

        {/* Productivity charts */}
        <section>
          <h3 className="font-semibold mb-3 flex items-center gap-2"><Sparkles className="size-4 text-primary" /> Productivity</h3>
          <TaskCharts tasks={allTasks.data?.tasks ?? []} />
        </section>

        {/* Projects snapshot */}
        {(briefing?.projects ?? []).length > 0 && (
          <section>
            <h3 className="font-semibold mb-3">Projects</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {briefing!.projects.map((p) => (
                <Card key={p.id} className="jarvis-panel p-4 cursor-pointer hover:jarvis-glow transition" onClick={() => { useApp.getState().setActiveProject(p.id); setView("projects"); }}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium truncate">{p.name}</span>
                    <span className="text-xs text-muted-foreground">{p.progress}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div className="h-full bg-primary" style={{ width: `${p.progress}%` }} />
                  </div>
                </Card>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function QuickAction({ icon: Icon, label, desc, onClick }: { icon: React.ElementType; label: string; desc: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="jarvis-panel p-4 text-left hover:jarvis-glow transition-all group">
      <div className="flex items-center gap-3">
        <div className="size-10 rounded-lg bg-primary/15 grid place-items-center text-primary group-hover:bg-primary/25 transition">
          <Icon className="size-5" />
        </div>
        <div>
          <div className="font-medium">{label}</div>
          <div className="text-xs text-muted-foreground">{desc}</div>
        </div>
      </div>
    </button>
  );
}

function Stat({ label, value, tone = "default" }: { label: string; value: number; tone?: "default" | "ok" | "warn" }) {
  const toneCls = tone === "ok" ? "text-emerald-400" : tone === "warn" ? "text-destructive" : "text-foreground";
  return (
    <div className="rounded-lg border border-border/60 bg-background/40 px-2 py-1.5 text-center">
      <div className={"text-lg font-semibold " + toneCls}>{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}

function TaskRow({ title, priority, overdue }: { title: string; priority: string; overdue?: boolean }) {
  return (
    <li className="flex items-center gap-2">
      <Circle className={"size-3 shrink-0 " + (overdue ? "text-destructive" : "text-primary")} />
      <span className="truncate">{title}</span>
      {priority === "high" && <span className="ml-auto text-[10px] px-1.5 py-0.5 rounded bg-destructive/20 text-destructive">high</span>}
    </li>
  );
}

function EmptyRow({ text }: { text: string }) {
  return (
    <div className="flex items-center gap-2 text-sm text-muted-foreground">
      <CheckCircle2 className="size-4 text-emerald-400" /> {text}
    </div>
  );
}
