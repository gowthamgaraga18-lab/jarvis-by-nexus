"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useApp } from "@/store/app-store";
import { useAuth } from "@/components/providers/auth-provider";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, Send, Square, Trash2, Pencil, RefreshCw, MessagesSquare } from "lucide-react";
import { toast } from "sonner";
import { Markdown } from "@/components/jarvis/markdown";
import { ToolCallCard } from "@/components/jarvis/tool-call-card";
import type { ChatMessage, Conversation } from "@/lib/types";

interface StreamEvent {
  type: "conv" | "delta" | "tool" | "done" | "error";
  conversationId?: string;
  text?: string;
  tool?: string;
  input?: Record<string, unknown>;
  message?: string;
}

interface RenderedMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  tools: { tool: string; input: Record<string, unknown> }[];
  streaming?: boolean;
  error?: boolean;
}

export function ChatView() {
  const { user } = useAuth();
  const { activeConversationId, setActiveConversation } = useApp();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<RenderedMessage[]>([]);
  const [input, setInput] = useState("");
  const [loadingConv, setLoadingConv] = useState(false);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const renameRef = useRef<HTMLInputElement | null>(null);

  // Load conversation list.
  const loadConvs = useCallback(async () => {
    setLoadingConv(true);
    try {
      const r = await fetch("/api/chat/sessions", { cache: "no-store" });
      const j = await r.json();
      if (j.ok) setConversations(j.conversations);
    } finally {
      setLoadingConv(false);
    }
  }, []);
  useEffect(() => { loadConvs(); }, [loadConvs]);

  // Load messages for active conversation.
  useEffect(() => {
    if (!activeConversationId) {
      setMessages([]);
      return;
    }
    let alive = true;
    (async () => {
      setLoadingMsgs(true);
      try {
        const r = await fetch(`/api/chat/sessions/${activeConversationId}/messages`, { cache: "no-store" });
        const j = await r.json();
        if (!j.ok) { toast.error(j.error); return; }
        if (!alive) return;
        const msgs: RenderedMessage[] = j.messages.map((m: ChatMessage) => ({
          id: m.id || crypto.randomUUID(),
          role: m.role === "user" ? "user" : "assistant",
          content: m.content,
          tools: [],
        }));
        setMessages(msgs);
      } finally {
        if (alive) setLoadingMsgs(false);
      }
    })();
    return () => { alive = false; };
  }, [activeConversationId]);

  // Auto-scroll on new content.
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages]);

  async function newConversation() {
    const r = await fetch("/api/chat/sessions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: "New conversation" }) });
    const j = await r.json();
    if (j.ok) {
      setConversations((c) => [j.conversation, ...c]);
      setActiveConversation(j.conversation.id);
    }
  }

  async function deleteConversation(id: string) {
    if (!confirm("Delete this conversation and all its messages?")) return;
    const r = await fetch(`/api/chat/sessions/${id}`, { method: "DELETE" });
    const j = await r.json();
    if (j.ok) {
      setConversations((c) => c.filter((x) => x.id !== id));
      if (activeConversationId === id) setActiveConversation(null);
      toast.success("Conversation deleted.");
    }
  }

  async function renameConversation(id: string) {
    const title = renameRef.current?.value?.trim();
    if (!title) return;
    const r = await fetch(`/api/chat/sessions/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title }) });
    const j = await r.json();
    if (j.ok) {
      setConversations((c) => c.map((x) => x.id === id ? j.conversation : x));
      toast.success("Renamed.");
    }
  }

  async function send(text?: string, retryFrom?: number) {
    const content = (text ?? input).trim();
    if (!content || streaming) return;
    setInput("");

    const userMsgId = crypto.randomUUID();
    const assistantId = crypto.randomUUID();
    const baseMessages = retryFrom !== undefined ? messages.slice(0, retryFrom) : messages;
    setMessages([
      ...baseMessages,
      { id: userMsgId, role: "user", content, tools: [] },
      { id: assistantId, role: "assistant", content: "", tools: [], streaming: true },
    ]);
    setStreaming(true);

    const abort = new AbortController();
    abortRef.current = abort;

    try {
      const r = await fetch("/api/chat/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId: activeConversationId ?? undefined, message: content }),
        signal: abort.signal,
      });
      if (!r.ok || !r.body) throw new Error("Chat stream unavailable.");
      // Set the active conversation from the server response.
      const reader = r.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let prose = "";
      const tools: { tool: string; input: Record<string, unknown> }[] = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let nl: number;
        while ((nl = buffer.indexOf("\n\n")) !== -1) {
          const block = buffer.slice(0, nl).trim();
          buffer = buffer.slice(nl + 2);
          if (!block.startsWith("data:")) continue;
          const payload = block.slice(5).trim();
          if (!payload) continue;
          let ev: StreamEvent;
          try { ev = JSON.parse(payload); } catch { continue; }
          if (ev.type === "conv" && ev.conversationId) {
            if (activeConversationId !== ev.conversationId) {
              setActiveConversation(ev.conversationId);
              loadConvs();
            }
          } else if (ev.type === "delta" && ev.text) {
            prose += ev.text;
            setMessages((m) => m.map((x) => x.id === assistantId ? { ...x, content: prose } : x));
          } else if (ev.type === "tool" && ev.tool) {
            tools.push({ tool: ev.tool, input: ev.input ?? {} });
            setMessages((m) => m.map((x) => x.id === assistantId ? { ...x, content: prose, tools: [...tools] } : x));
          } else if (ev.type === "error") {
            setMessages((m) => m.map((x) => x.id === assistantId ? { ...x, content: prose || ev.message!, error: true, streaming: false } : x));
            toast.error(ev.message || "The model returned an error.");
          } else if (ev.type === "done") {
            setMessages((m) => m.map((x) => x.id === assistantId ? { ...x, content: prose, tools, streaming: false } : x));
          }
        }
      }
    } catch (e) {
      if (abort.signal.aborted) {
        setMessages((m) => m.map((x) => x.id === assistantId ? { ...x, streaming: false, content: x.content || "_(stopped)_" } : x));
      } else {
        const msg = e instanceof Error ? e.message : "Chat failed.";
        setMessages((m) => m.map((x) => x.id === assistantId ? { ...x, content: msg, error: true, streaming: false } : x));
        toast.error(msg);
      }
    } finally {
      setStreaming(false);
      abortRef.current = null;
    }
  }

  function stop() {
    abortRef.current?.abort();
  }

  return (
    <div className="h-full grid md:grid-cols-[280px_1fr]">
      {/* Sessions */}
      <div className="hidden md:flex flex-col border-r border-border/70 bg-card/40">
        <div className="p-3 border-b border-border/70 flex items-center gap-2">
          <Button size="sm" className="flex-1" onClick={newConversation}><Plus className="size-4" /> New chat</Button>
        </div>
        <ScrollArea className="flex-1 jarvis-scrollbar">
          <ul className="p-2 grid gap-1">
            {loadingConv && <li className="p-2"><Skeleton className="h-8 w-full" /></li>}
            {!loadingConv && conversations.length === 0 && (
              <li className="text-xs text-muted-foreground p-3">No conversations yet.</li>
            )}
            {conversations.map((c) => (
              <li key={c.id}>
                <div
                  className={"group flex items-center gap-2 rounded-lg px-2.5 py-2 text-sm cursor-pointer transition " + (c.id === activeConversationId ? "bg-primary/15 text-primary-foreground" : "hover:bg-accent/50")}
                  onClick={() => setActiveConversation(c.id)}
                >
                  <MessagesSquare className="size-3.5 shrink-0 opacity-70" />
                  <span className="flex-1 truncate">{c.title}</span>
                  <button className="opacity-0 group-hover:opacity-100 transition" title="Rename" onClick={(e) => { e.stopPropagation(); const v = window.prompt("New title", c.title); if (v) { renameRef.current = { value: v } as any; renameConversation(c.id); } }}>
                    <Pencil className="size-3.5" />
                  </button>
                  <button className="opacity-0 group-hover:opacity-100 transition text-destructive" title="Delete" onClick={(e) => { e.stopPropagation(); deleteConversation(c.id); }}>
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </ScrollArea>
      </div>

      {/* Conversation */}
      <div className="flex flex-col min-h-0">
        <div ref={scrollRef} className="flex-1 overflow-y-auto jarvis-scrollbar">
          <div className="max-w-3xl mx-auto px-4 py-6 grid gap-4">
            {activeConversationId === null && messages.length === 0 ? (
              <EmptyChat onPick={(t) => send(t)} />
            ) : loadingMsgs ? (
              <div className="grid gap-2"><Skeleton className="h-12 w-3/4" /><Skeleton className="h-20 w-full" /></div>
            ) : (
              messages.map((m, i) => <MessageBubble key={m.id} m={m} onRetry={() => send(messages[i - 1]?.content, i)} streaming={streaming} />)
            )}
          </div>
        </div>

        {/* Composer */}
        <div className="border-t border-border/70 bg-background/70 backdrop-blur-xl p-3">
          <form onSubmit={(e) => { e.preventDefault(); send(); }} className="max-w-3xl mx-auto flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={streaming ? "JARVIS is responding…" : "Message JARVIS…"}
              disabled={streaming}
              className="flex-1 bg-background/60"
            />
            {streaming ? (
              <Button type="button" variant="destructive" size="icon" onClick={stop} aria-label="Stop"><Square className="size-4" /></Button>
            ) : (
              <Button type="submit" size="icon" disabled={!input.trim()} aria-label="Send"><Send className="size-4" /></Button>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}

function EmptyChat({ onPick }: { onPick: (t: string) => void }) {
  const suggestions = [
    "Explain the CAP theorem with an analogy",
    "Draft a 3-week study plan for learning Rust",
    "Create a task to renew my passport next month",
    "Summarize the plot of The Matrix in 3 bullets",
  ];
  return (
    <Card className="jarvis-panel p-6">
      <h3 className="font-semibold mb-1">Start a conversation</h3>
      <p className="text-sm text-muted-foreground mb-4">Ask anything, or have JARVIS draft a task or note for you.</p>
      <div className="grid sm:grid-cols-2 gap-2">
        {suggestions.map((s) => (
          <button key={s} onClick={() => onPick(s)} className="text-left text-sm rounded-lg border border-border/60 p-3 hover:bg-accent/50 transition">
            {s}
          </button>
        ))}
      </div>
    </Card>
  );
}

function MessageBubble({ m, onRetry, streaming }: { m: RenderedMessage; onRetry: () => void; streaming: boolean }) {
  const isUser = m.role === "user";
  return (
    <div className={"flex " + (isUser ? "justify-end" : "justify-start")}>
      <div className={"max-w-[85%] " + (isUser ? "items-end" : "items-start")}>
        <div className="flex items-center gap-2 mb-1">
          <span className={"text-[10px] uppercase tracking-wider " + (isUser ? "text-muted-foreground" : "text-primary")}>
            {isUser ? "You" : "JARVIS"}
          </span>
          {!isUser && m.streaming && <span className="size-1.5 rounded-full bg-primary animate-pulse" />}
        </div>
        <div
          className={
            "rounded-2xl px-4 py-3 " +
            (isUser
              ? "bg-primary/15 border border-primary/30"
              : m.error
              ? "bg-destructive/10 border border-destructive/30"
              : "jarvis-panel")
          }
        >
          {m.content ? <Markdown content={m.content} /> : m.streaming ? <span className="text-muted-foreground text-sm">Thinking…</span> : null}
        </div>
        {m.tools.length > 0 && (
          <div className="mt-2 grid gap-2 max-w-full">
            {m.tools.map((t, idx) => <ToolCallCard key={idx} tool={t.tool} input={t.input} />)}
          </div>
        )}
        {!isUser && !m.streaming && m.content && (
          <div className="flex items-center gap-3 mt-1.5 px-1">
            <button className="text-[11px] text-muted-foreground hover:text-foreground flex items-center gap-1" onClick={() => { navigator.clipboard?.writeText(m.content); toast.success("Copied"); }}>
              Copy
            </button>
            {!streaming && <button className="text-[11px] text-muted-foreground hover:text-foreground flex items-center gap-1" onClick={onRetry}><RefreshCw className="size-3" /> Retry</button>}
          </div>
        )}
      </div>
    </div>
  );
}
