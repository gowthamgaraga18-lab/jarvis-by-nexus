"use client";

import { useEffect, useState } from "react";
import { useTools, runTool } from "@/hooks/use-tools";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Loader2, ShieldCheck, XCircle, Download, ExternalLink, Save } from "lucide-react";
import { toast } from "sonner";
import type { ToolField } from "@/lib/types";
import { useImagesStore } from "@/store/images-store";

export interface ToolCallCardProps {
  tool: string;
  input: Record<string, unknown>;
  onResolved?: (result: { ok: boolean; message: string }) => void;
}

interface WebSearchHit { url: string; name: string; snippet: string; host_name?: string; date?: string }

export function ToolCallCard({ tool, input, onResolved }: ToolCallCardProps) {
  const { data } = useTools();
  const def = data?.tools.find((t) => t.name === tool);
  const [values, setValues] = useState<Record<string, string>>({});
  const [state, setState] = useState<"idle" | "running" | "done" | "error" | "cancelled">("idle");
  const [resultMsg, setResultMsg] = useState("");
  const [resultData, setResultData] = useState<Record<string, unknown> | null>(null);
  const addImage = useImagesStore((s) => s.addImage);

  useEffect(() => {
    const init: Record<string, string> = {};
    for (const f of def?.schema ?? []) {
      const v = (input as Record<string, unknown>)[f.name];
      if (v !== undefined && v !== null) init[f.name] = String(v);
    }
    // setValues is a sync-from-props init; the linter's set-state-in-effect
    // rule does not flag this pattern here.
    setValues(init);
  }, [def, input]);

  async function confirm() {
    setState("running");
    const res = await runTool(tool, values);
    if (res.ok) {
      setState("done");
      setResultMsg(res.result?.message ?? "Done.");
      setResultData((res.result?.data as Record<string, unknown>) ?? null);
      toast.success(res.result?.message ?? "Action completed.");
      // If image generation, add to the gallery.
      if (tool === "generate_image" && res.result?.data) {
        const imgs = (res.result.data as { images?: string[] }).images ?? [];
        const prompt = (res.result.data as { prompt?: string }).prompt ?? "";
        for (const src of imgs) addImage({ src, prompt, size: values.size || "1024x1024" });
      }
    } else {
      setState("error");
      setResultMsg(res.result?.message ?? res.error ?? "Failed.");
      toast.error(res.result?.message ?? "Action failed.");
    }
    onResolved?.({ ok: res.ok, message: res.result?.message ?? "" });
  }

  if (!def) {
    return (
      <Card className="p-4 border-dashed">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <ShieldCheck className="size-4" /> Unknown tool: <code className="text-foreground">{tool}</code>
        </div>
      </Card>
    );
  }

  const terminal = state === "done" || state === "error" || state === "cancelled";
  const images = (resultData?.images as string[] | undefined) ?? [];
  const searchResults = (resultData?.results as WebSearchHit[] | undefined) ?? [];

  return (
    <Card className="p-4 jarvis-panel">
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="size-4 text-primary" />
          <span className="text-sm font-medium">{def.label}</span>
          {def.requiresConfirmation && <Badge variant="secondary" className="text-[10px]">Approval required</Badge>}
        </div>
        {state === "done" && <CheckCircle2 className="size-4 text-emerald-400" />}
        {state === "error" && <XCircle className="size-4 text-destructive" />}
        {state === "running" && <Loader2 className="size-4 animate-spin text-primary" />}
      </div>
      <p className="text-xs text-muted-foreground mb-3">{def.description}</p>

      {!terminal && (
        <div className="grid gap-3">
          {def.schema.map((f: ToolField) => (
            <div key={f.name} className="grid gap-1">
              <Label htmlFor={`tf-${f.name}`} className="text-xs">
                {f.label}{f.required && <span className="text-destructive"> *</span>}
              </Label>
              {f.type === "string" && f.options ? (
                <select
                  id={`tf-${f.name}`}
                  className="h-9 rounded-md border border-input bg-background px-3 text-sm"
                  value={values[f.name] ?? f.options[0]}
                  onChange={(e) => setValues((v) => ({ ...v, [f.name]: e.target.value }))}
                  disabled={state === "running"}
                >
                  {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : (
                <Input
                  id={`tf-${f.name}`}
                  type={f.type === "date" ? "date" : f.type === "number" ? "number" : "text"}
                  value={values[f.name] ?? ""}
                  placeholder={f.placeholder}
                  onChange={(e) => setValues((v) => ({ ...v, [f.name]: e.target.value }))}
                  disabled={state === "running"}
                />
              )}
            </div>
          ))}
        </div>
      )}

      {terminal && (
        <div className="grid gap-3">
          <p className="text-xs text-muted-foreground">{resultMsg}</p>
          {images.length > 0 && (
            <div className="grid gap-2">
              {images.map((src, i) => (
                <div key={i} className="relative group">
                  <img src={src} alt={values.prompt || "Generated"} className="rounded-lg w-full" />
                  <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition">
                    <a href={src} download={`jarvis-${Date.now()}.png`} className="rounded-md border border-border/60 bg-background/80 p-1.5">
                      <Download className="size-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
          {searchResults.length > 0 && (
            <ul className="grid gap-2 text-xs">
              {searchResults.map((r, i) => (
                <li key={i} className="rounded-md border border-border/60 p-2 bg-background/40">
                  <a href={r.url} target="_blank" rel="noopener noreferrer" className="font-medium text-primary hover:underline flex items-center gap-1">
                    {r.name} <ExternalLink className="size-3" />
                  </a>
                  {r.host_name && <span className="text-[10px] text-muted-foreground ml-1">{r.host_name}</span>}
                  {r.snippet && <p className="text-muted-foreground mt-1 line-clamp-2">{r.snippet}</p>}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {!terminal && (
        <div className="flex justify-end gap-2 mt-4">
          <Button size="sm" variant="ghost" onClick={() => { setState("cancelled"); setResultMsg("Cancelled."); onResolved?.({ ok: false, message: "Cancelled" }); }}>
            Cancel
          </Button>
          <Button size="sm" onClick={confirm} disabled={state === "running"}>
            {state === "running" ? "Running…" : def.requiresConfirmation ? "Approve & run" : "Run"}
          </Button>
        </div>
      )}
    </Card>
  );
}
