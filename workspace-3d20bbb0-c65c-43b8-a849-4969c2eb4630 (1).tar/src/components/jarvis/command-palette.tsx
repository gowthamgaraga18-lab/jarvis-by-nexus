"use client";

import { useEffect, useState } from "react";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from "@/components/ui/command";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useApp, type View } from "@/store/app-store";
import {
  LayoutDashboard, MessagesSquare, Mic, ListChecks, NotebookPen, FolderKanban, Wand2, Brain, Settings,
  Plus, Search, Sparkles, Home,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useTasks, useNotes, useProjects } from "@/hooks/use-data";

interface PaletteItem {
  id: string;
  label: string;
  hint?: string;
  icon: React.ElementType;
  group: string;
  run: () => void;
}

const VIEW_ITEMS: { id: View; label: string; icon: React.ElementType }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "chat", label: "Chat with JARVIS", icon: MessagesSquare },
  { id: "voice", label: "Voice assistant", icon: Mic },
  { id: "tasks", label: "Tasks", icon: ListChecks },
  { id: "notes", label: "Notes", icon: NotebookPen },
  { id: "projects", label: "Projects", icon: FolderKanban },
  { id: "studio", label: "Image Studio", icon: Wand2 },
  { id: "memory", label: "Memory", icon: Brain },
  { id: "settings", label: "Settings", icon: Settings },
];

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const { setView, launchQuick, setActiveConversation, setActiveProject } = useApp();

  // Global Cmd/Ctrl+K to open, plus view shortcuts Cmd+1..9, N for new task.
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((o) => !o);
        return;
      }
      if (mod && /^[1-9]$/.test(e.key)) {
        const idx = Number(e.key) - 1;
        const item = VIEW_ITEMS[idx];
        if (item) { e.preventDefault(); setView(item.id); }
        return;
      }
      // Plain "n" (no modifier, not typing) → new task.
      const el = document.activeElement as HTMLElement | null;
      const typing = el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable);
      if (!typing && !mod && !e.altKey && e.key.toLowerCase() === "n") {
        e.preventDefault();
        launchQuick("tasks", "new");
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setView, launchQuick]);

  const tasks = useTasks("active", "");
  const notes = useNotes("");
  const projects = useProjects("");

  const items: PaletteItem[] = [
    ...VIEW_ITEMS.map((v) => ({
      id: `view-${v.id}`,
      label: v.label,
      hint: "Go to",
      icon: v.icon,
      group: "Navigation",
      run: () => setView(v.id),
    })),
    { id: "new-task", label: "Create a new task", icon: Plus, group: "Quick actions", run: () => launchQuick("tasks", "new") },
    { id: "new-note", label: "Create a new note", icon: Plus, group: "Quick actions", run: () => launchQuick("notes", "new") },
    { id: "new-project", label: "Create a new project", icon: Plus, group: "Quick actions", run: () => launchQuick("projects", "new") },
    { id: "ask-jarvis", label: "Ask JARVIS…", icon: Sparkles, group: "Quick actions", run: () => setView("chat") },
    ...((tasks.data?.tasks ?? []).slice(0, 6).map((t) => ({
      id: `task-${t.id}`, label: t.title, hint: "Open task", icon: ListChecks, group: "Tasks",
      run: () => setView("tasks"),
    }))),
    ...((notes.data?.notes ?? []).slice(0, 6).map((n) => ({
      id: `note-${n.id}`, label: n.title, hint: "Open note", icon: NotebookPen, group: "Notes",
      run: () => setView("notes"),
    }))),
    ...((projects.data?.projects ?? []).slice(0, 6).map((p) => ({
      id: `proj-${p.id}`, label: p.name, hint: `${p.progress}%`, icon: FolderKanban, group: "Projects",
      run: () => { setActiveProject(p.id); setView("projects"); },
    }))),
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="jarvis-panel p-0 overflow-hidden max-w-xl">
        <Command className="bg-transparent">
          <CommandInput placeholder="Type a command or search…" autoFocus />
          <CommandList className="max-h-[60vh] jarvis-scrollbar">
            <CommandEmpty>No results.</CommandEmpty>
            <CommandGroup heading="Navigation">
              {items.filter((i) => i.group === "Navigation").map((i) => (
                <CommandItem key={i.id} value={`${i.label} ${i.group}`} onSelect={() => { i.run(); setOpen(false); }}>
                  <i.icon className="size-4 shrink-0 text-muted-foreground" />
                  <span className="flex-1">{i.label}</span>
                  <span className="text-[10px] text-muted-foreground">{i.hint}</span>
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
            <CommandGroup heading="Quick actions">
              {items.filter((i) => i.group === "Quick actions").map((i) => (
                <CommandItem key={i.id} value={i.label} onSelect={() => { i.run(); setOpen(false); }}>
                  <i.icon className="size-4 shrink-0 text-primary" />
                  <span className="flex-1">{i.label}</span>
                </CommandItem>
              ))}
            </CommandGroup>
            {tasks.data?.tasks && tasks.data.tasks.length > 0 && (
              <CommandGroup heading="Tasks">
                {items.filter((i) => i.group === "Tasks").map((i) => (
                  <CommandItem key={i.id} value={i.label} onSelect={() => { i.run(); setOpen(false); }}>
                    <i.icon className="size-4 shrink-0 text-muted-foreground" />
                    <span className="flex-1 truncate">{i.label}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {notes.data?.notes && notes.data.notes.length > 0 && (
              <CommandGroup heading="Notes">
                {items.filter((i) => i.group === "Notes").map((i) => (
                  <CommandItem key={i.id} value={i.label} onSelect={() => { i.run(); setOpen(false); }}>
                    <i.icon className="size-4 shrink-0 text-muted-foreground" />
                    <span className="flex-1 truncate">{i.label}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {projects.data?.projects && projects.data.projects.length > 0 && (
              <CommandGroup heading="Projects">
                {items.filter((i) => i.group === "Projects").map((i) => (
                  <CommandItem key={i.id} value={i.label} onSelect={() => { i.run(); setOpen(false); }}>
                    <i.icon className="size-4 shrink-0 text-muted-foreground" />
                    <span className="flex-1 truncate">{i.label}</span>
                    <span className="text-[10px] text-muted-foreground">{i.hint}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
          </CommandList>
          <div className="border-t border-border/60 px-3 py-2 text-[10px] text-muted-foreground flex items-center justify-between">
            <span className="flex items-center gap-1"><Home className="size-3" /> ⌘K to toggle · ⌘1-9 for views · N for new task</span>
            <Search className="size-3" />
          </div>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
