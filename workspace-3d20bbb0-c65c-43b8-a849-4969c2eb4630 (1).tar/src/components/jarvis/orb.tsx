"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { AssistantState } from "@/lib/types";

interface OrbProps {
  state: AssistantState;
  size?: number;
  reducedMotion?: boolean;
}

/**
 * Central JARVIS orb. Purely decorative + state-reactive (no audio/telemetry).
 * Layers:
 *  - outer rotating ring (conic gradient)
 *  - counter-rotating ring
 *  - inner core that pulses when processing/listening/speaking
 */
export function JarvisOrb({ state, size = 220, reducedMotion = false }: OrbProps) {
  const palette = stateColor(state);
  const idle = state === "idle";
  const dim = reducedMotion;

  return (
    <div
      className="relative grid place-items-center"
      style={{ width: size, height: size }}
      role="img"
      aria-label={`JARVIS ${state}`}
    >
      {/* outer glow */}
      <div
        className="absolute inset-0 rounded-full blur-2xl"
        style={{ background: `radial-gradient(circle, ${palette.glow}, transparent 70%)`, opacity: idle ? 0.4 : 0.85 }}
      />
      {/* rotating ring */}
      <div
        className={cn("absolute inset-0 rounded-full jarvis-orb-ring", !dim && "jarvis-spin")}
        style={{ opacity: idle ? 0.6 : 0.95 }}
      />
      {/* counter ring */}
      <div
        className={cn("absolute rounded-full", !dim && "jarvis-spin-rev")}
        style={{ inset: size * 0.12, background: palette.ring2, opacity: idle ? 0.35 : 0.7, maskImage: "radial-gradient(transparent 60%, black 62%)", WebkitMaskImage: "radial-gradient(transparent 60%, black 62%)" }}
      />
      {/* core */}
      <motion.div
        className="absolute rounded-full"
        animate={dim ? {} : { scale: idle ? 1 : [1, 1.06, 1], opacity: idle ? 0.85 : [0.85, 1, 0.85] }}
        transition={dim ? {} : { duration: 2.6, repeat: Infinity, ease: "easeInOut" }}
        style={{ inset: size * 0.22, background: palette.core, boxShadow: `0 0 60px -8px ${palette.glow}` }}
      />
      {/* innermost node */}
      <div
        className={cn("absolute rounded-full", !dim && !idle && "jarvis-breathe")}
        style={{ inset: size * 0.38, background: palette.node }}
      />
    </div>
  );
}

function stateColor(s: AssistantState) {
  switch (s) {
    case "listening":
      return {
        core: "radial-gradient(circle at 35% 30%, oklch(0.85 0.16 190), oklch(0.45 0.14 200))",
        node: "oklch(0.95 0.05 190)",
        ring2: "conic-gradient(from 90deg, transparent, oklch(0.85 0.16 190 / 0.8), transparent)",
        glow: "oklch(0.7 0.16 190 / 0.6)",
      };
    case "processing":
      return {
        core: "radial-gradient(circle at 35% 30%, oklch(0.85 0.14 230), oklch(0.45 0.16 250))",
        node: "oklch(0.9 0.06 230)",
        ring2: "conic-gradient(from 90deg, transparent, oklch(0.8 0.16 235 / 0.8), transparent)",
        glow: "oklch(0.7 0.16 240 / 0.6)",
      };
    case "speaking":
      return {
        core: "radial-gradient(circle at 35% 30%, oklch(0.85 0.16 175), oklch(0.5 0.16 165))",
        node: "oklch(0.95 0.06 175)",
        ring2: "conic-gradient(from 90deg, transparent, oklch(0.8 0.16 170 / 0.8), transparent)",
        glow: "oklch(0.72 0.16 170 / 0.6)",
      };
    case "error":
      return {
        core: "radial-gradient(circle at 35% 30%, oklch(0.78 0.2 25), oklch(0.5 0.22 25))",
        node: "oklch(0.92 0.06 25)",
        ring2: "conic-gradient(from 90deg, transparent, oklch(0.78 0.2 25 / 0.8), transparent)",
        glow: "oklch(0.7 0.2 25 / 0.6)",
      };
    default:
      return {
        core: "radial-gradient(circle at 35% 30%, oklch(0.78 0.16 210), oklch(0.45 0.14 220))",
        node: "oklch(0.9 0.08 210)",
        ring2: "conic-gradient(from 90deg, transparent, oklch(0.78 0.16 210 / 0.8), transparent)",
        glow: "oklch(0.7 0.16 210 / 0.55)",
      };
  }
}
