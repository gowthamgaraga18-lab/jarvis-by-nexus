"use client";

import { Menu, PanelLeftClose, PanelLeft, Mic, MicOff, Wifi, WifiOff, Command } from "lucide-react";
import { useApp, type View } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

const TITLES: Record<View, string> = {
  dashboard: "Dashboard",
  chat: "Chat",
  voice: "Voice",
  tasks: "Tasks",
  notes: "Notes",
  projects: "Projects",
  memory: "Memory",
  settings: "Settings",
};

export function Topbar({ micGranted }: { micGranted: "unknown" | "granted" | "denied" | "unsupported" }) {
  const { view, toggleSidebar, sidebarCollapsed, setMobileNav } = useApp();
  const [online, setOnline] = useState(true);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  return (
    <header className="sticky top-0 z-30 h-16 flex items-center gap-3 border-b border-border/70 bg-background/70 backdrop-blur-xl px-4">
      <Button
        variant="ghost"
        size="icon"
        className="lg:hidden"
        onClick={() => setMobileNav(true)}
        aria-label="Open navigation"
      >
        <Menu className="size-5" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="hidden lg:inline-flex"
        onClick={toggleSidebar}
        aria-label="Toggle sidebar"
      >
        {sidebarCollapsed ? <PanelLeft className="size-5" /> : <PanelLeftClose className="size-5" />}
      </Button>
      <h1 className="text-lg font-semibold tracking-tight">{TITLES[view]}</h1>
      <button
        onClick={() => { window.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true })); }}
        className="hidden md:inline-flex items-center gap-1.5 rounded-md border border-border/60 bg-background/40 px-2.5 py-1 text-xs text-muted-foreground hover:bg-accent/50 transition"
        title="Open command palette (⌘K)"
      >
        <Command className="size-3" />
        <span>Search</span>
        <kbd className="ml-1 rounded bg-muted/60 px-1 text-[10px]">⌘K</kbd>
      </button>
      <div className="ml-auto flex items-center gap-2">
        <StatusPill ok={online} okLabel="Online" badLabel="Offline" iconOn={Wifi} iconOff={WifiOff} />
        <StatusPill
          ok={micGranted === "granted"}
          okLabel="Mic ready"
          badLabel={micGranted === "unsupported" ? "No mic" : micGranted === "denied" ? "Mic blocked" : "Mic idle"}
          iconOn={Mic}
          iconOff={MicOff}
        />
      </div>
    </header>
  );
}

function StatusPill({
  ok,
  okLabel,
  badLabel,
  iconOn: IconOn,
  iconOff: IconOff,
}: {
  ok: boolean;
  okLabel: string;
  badLabel: string;
  iconOn: React.ElementType;
  iconOff: React.ElementType;
}) {
  return (
    <span
      className={
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium " +
        (ok
          ? "border-primary/40 bg-primary/10 text-primary"
          : "border-border bg-muted/40 text-muted-foreground")
      }
    >
      {ok ? <IconOn className="size-3" /> : <IconOff className="size-3" />}
      <span className="hidden sm:inline">{ok ? okLabel : badLabel}</span>
    </span>
  );
}
