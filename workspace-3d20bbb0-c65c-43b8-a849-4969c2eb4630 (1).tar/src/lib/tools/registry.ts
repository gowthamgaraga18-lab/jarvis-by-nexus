import { chatCompletion, generateImage, webSearch, type ImageSize } from "@/lib/jarvis-ai";
import { createTask, createNote, listTasks, listNotes, addAudit } from "@/lib/data";
import type { ToolDef, ToolField, ToolResult } from "@/lib/types";

// ---- Field schemas -------------------------------------------------------
const taskFields: ToolField[] = [
  { name: "title", type: "string", label: "Title", required: true, placeholder: "Call the optometrist" },
  { name: "description", type: "string", label: "Description", required: false, placeholder: "Optional details" },
  { name: "priority", type: "string", label: "Priority", required: false, options: ["low", "medium", "high"] },
  { name: "category", type: "string", label: "Category", required: false, placeholder: "e.g. health" },
  { name: "dueDate", type: "date", label: "Due date", required: false },
];

const noteFields: ToolField[] = [
  { name: "title", type: "string", label: "Title", required: true, placeholder: "Meeting notes" },
  { name: "content", type: "string", label: "Content (Markdown)", required: true, placeholder: "Write in markdown..." },
  { name: "projectId", type: "string", label: "Project (optional)", required: false, placeholder: "Project id" },
];

const searchFields: ToolField[] = [
  { name: "query", type: "string", label: "Query", required: true, placeholder: "dentist" },
  { name: "scope", type: "string", label: "Scope", required: false, options: ["all", "tasks", "notes"] },
];

const summarizeFields: ToolField[] = [
  { name: "text", type: "string", label: "Text to summarize", required: true, placeholder: "Paste content..." },
];

const URL_ALLOWLIST = [
  "https://en.wikipedia.org",
  "https://www.google.com",
  "https://github.com",
  "https://developer.mozilla.org",
];

const openUrlFields: ToolField[] = [
  { name: "url", type: "string", label: "URL", required: true, placeholder: "https://..." },
];

// ---- Helpers -------------------------------------------------------------
function bad(msg: string): ToolResult {
  return { ok: false, status: "error", message: msg };
}

function validateFields(input: Record<string, unknown>, fields: ToolField[]): { ok: boolean; error?: string; value?: Record<string, unknown> } {
  const out: Record<string, unknown> = {};
  for (const f of fields) {
    const raw = input[f.name];
    if (raw === undefined || raw === null || raw === "") {
      if (f.required) return { ok: false, error: `Missing required field: ${f.label}` };
      continue;
    }
    if (f.type === "string") {
      const v = String(raw).slice(0, 5000);
      if (f.options && !f.options.includes(v)) return { ok: false, error: `Invalid option for ${f.label}` };
      out[f.name] = v;
    } else if (f.type === "number") {
      const n = Number(raw);
      if (!isFinite(n)) return { ok: false, error: `${f.label} must be a number` };
      out[f.name] = n;
    } else if (f.type === "boolean") {
      out[f.name] = Boolean(raw);
    } else if (f.type === "date") {
      const d = new Date(String(raw));
      if (isNaN(d.getTime())) return { ok: false, error: `${f.label} is not a valid date` };
      out[f.name] = d.toISOString();
    }
  }
  return { ok: true, value: out };
}

// ---- Tool definitions ----------------------------------------------------
const createTaskTool: ToolDef = {
  name: "create_task",
  label: "Create a task",
  description: "Adds a new task to the user's task list.",
  requiresConfirmation: true,
  schema: taskFields,
  async execute(input) {
    const v = validateFields(input, taskFields);
    if (!v.ok || !v.value) return bad(v.error || "Invalid input");
    const val = v.value;
    const task = await createTask({
      title: String(val.title),
      description: String(val.description ?? ""),
      priority: (val.priority as "low" | "medium" | "high") ?? "medium",
      category: String(val.category ?? ""),
      dueDate: val.dueDate ? String(val.dueDate) : null,
      projectId: val.projectId ? String(val.projectId) : null,
    });
    return { ok: true, status: "success", message: "Task created.", data: { id: task.id, title: task.title } };
  },
};

const saveNoteTool: ToolDef = {
  name: "save_note",
  label: "Save a note",
  description: "Creates a new note with markdown content.",
  requiresConfirmation: true,
  schema: noteFields,
  async execute(input) {
    const v = validateFields(input, noteFields);
    if (!v.ok || !v.value) return bad(v.error || "Invalid input");
    const val = v.value;
    const note = await createNote({
      title: String(val.title),
      content: String(val.content).slice(0, 20000),
      projectId: val.projectId ? String(val.projectId) : null,
    });
    return { ok: true, status: "success", message: "Note saved.", data: { id: note.id, title: note.title } };
  },
};

const searchTool: ToolDef = {
  name: "search_user_data",
  label: "Search your tasks & notes",
  description: "Read-only search across the user's own tasks and notes.",
  requiresConfirmation: false,
  schema: searchFields,
  async execute(input) {
    const v = validateFields(input, searchFields);
    if (!v.ok || !v.value) return bad(v.error || "Invalid input");
    const val = v.value;
    const q = String(val.query).trim();
    if (q.length < 2) return bad("Query too short.");
    const scope = String(val.scope ?? "all");
    const tasks = (scope === "all" || scope === "tasks") ? await listTasks({ q }) : [];
    const notes = (scope === "all" || scope === "notes") ? await listNotes({ q }) : [];
    return { ok: true, status: "success", message: `Found ${tasks.length} tasks, ${notes.length} notes.`, data: { tasks, notes } };
  },
};

const summarizeTool: ToolDef = {
  name: "summarize_text",
  label: "Summarize content",
  description: "Produces a concise summary of the provided text using z.ai.",
  requiresConfirmation: false,
  schema: summarizeFields,
  async execute(input) {
    const v = validateFields(input, summarizeFields);
    if (!v.ok || !v.value) return bad(v.error || "Invalid input");
    const text = String(v.value.text).slice(0, 12000);
    if (text.length < 20) return bad("Text too short to summarize.");
    try {
      const summary = await chatCompletion(
        [
          { role: "system", content: "You are JARVIS. Summarize the user's text in 3-5 concise bullet points. Use markdown." },
          { role: "user", content: text },
        ],
        { maxTokens: 600 }
      );
      return { ok: true, status: "success", message: "Summary ready.", data: { summary } };
    } catch (e) {
      return bad(e instanceof Error ? e.message : "Summarization failed.");
    }
  },
};

const openUrlTool: ToolDef = {
  name: "open_url",
  label: "Open an allowlisted URL",
  description: "Returns a URL from a strict allowlist for the client to open in a new tab.",
  requiresConfirmation: true,
  schema: openUrlFields,
  async execute(input) {
    const v = validateFields(input, openUrlFields);
    if (!v.ok || !v.value) return bad(v.error || "Invalid input");
    const url = String(v.value.url);
    const allowed = URL_ALLOWLIST.some((base) => url.startsWith(base));
    if (!allowed) {
      return { ok: false, status: "denied", message: `URL not in allowlist. Allowed bases: ${URL_ALLOWLIST.join(", ")}` };
    }
    return { ok: true, status: "success", message: "URL approved to open.", data: { url } };
  },
};

// ---- Advanced AI tools (web search + image generation) -------------------
const webSearchFields: ToolField[] = [
  { name: "query", type: "string", label: "Search query", required: true, placeholder: "latest TypeScript features" },
  { name: "num", type: "number", label: "Number of results", required: false, placeholder: "5" },
  { name: "recencyDays", type: "number", label: "Recency (days)", required: false, placeholder: "30" },
];

const imageGenFields: ToolField[] = [
  { name: "prompt", type: "string", label: "Image prompt", required: true, placeholder: "A serene mountain lake at sunset" },
  { name: "size", type: "string", label: "Size", required: false, options: ["1024x1024", "1344x768", "768x1344", "1440x720", "720x1440"] },
];

const webSearchTool: ToolDef = {
  name: "web_search",
  label: "Search the web",
  description: "Fetches live web results via z.ai web_search. Use for current events, docs, facts you can't verify from memory.",
  requiresConfirmation: false,
  schema: webSearchFields,
  async execute(input) {
    const v = validateFields(input, webSearchFields);
    if (!v.ok || !v.value) return bad(v.error || "Invalid input");
    const query = String(v.value.query).trim();
    const num = v.value.num ? Math.min(Math.max(Number(v.value.num), 1), 10) : 5;
    const recencyDays = v.value.recencyDays ? Number(v.value.recencyDays) : undefined;
    try {
      const results = await webSearch(query, num, recencyDays);
      return { ok: true, status: "success", message: `Found ${results.length} results for "${query}".`, data: { results } };
    } catch (e) {
      return bad(e instanceof Error ? e.message : "Web search failed.");
    }
  },
};

const generateImageTool: ToolDef = {
  name: "generate_image",
  label: "Generate an image",
  description: "Creates an image from a text prompt using z.ai image generation. Returns a base64 PNG.",
  requiresConfirmation: true,
  schema: imageGenFields,
  async execute(input) {
    const v = validateFields(input, imageGenFields);
    if (!v.ok || !v.value) return bad(v.error || "Invalid input");
    const prompt = String(v.value.prompt).trim();
    const size = (v.value.size as ImageSize) || "1024x1024";
    try {
      const images = await generateImage(prompt, size);
      if (images.length === 0) return bad("No image returned.");
      return { ok: true, status: "success", message: "Image generated.", data: { images, prompt } };
    } catch (e) {
      return bad(e instanceof Error ? e.message : "Image generation failed.");
    }
  },
};

// ---- Registry ------------------------------------------------------------
export const TOOL_REGISTRY: Record<string, ToolDef> = {
  create_task: createTaskTool,
  save_note: saveNoteTool,
  search_user_data: searchTool,
  summarize_text: summarizeTool,
  open_url: openUrlTool,
  web_search: webSearchTool,
  generate_image: generateImageTool,
};

export function listTools(): { name: string; label: string; description: string; requiresConfirmation: boolean; schema: ToolField[] }[] {
  return Object.values(TOOL_REGISTRY).map((t) => ({
    name: t.name,
    label: t.label,
    description: t.description,
    requiresConfirmation: t.requiresConfirmation,
    schema: t.schema,
  }));
}

export async function runTool(
  name: string,
  input: Record<string, unknown>,
  _userId: string
): Promise<ToolResult & { auditId?: string }> {
  const tool = TOOL_REGISTRY[name];
  if (!tool) return { ok: false, status: "error", message: `Unknown tool: ${name}` };
  const inputStr = JSON.stringify(input).slice(0, 4000);
  try {
    const res = await tool.execute(input, _userId);
    // Best-effort audit: never let a missing/empty audit_events table break the
    // tool's result. The audit is a nice-to-have; the result is the priority.
    try {
      await addAudit(name, inputStr, res.message.slice(0, 1000), res.status);
    } catch { /* schema not ready or write failed — non-fatal */ }
    return { ...res, auditId: "supabase" };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    try { await addAudit(name, inputStr, msg.slice(0, 1000), "error"); } catch { /* non-fatal */ }
    return { ok: false, status: "error", message: msg };
  }
}
