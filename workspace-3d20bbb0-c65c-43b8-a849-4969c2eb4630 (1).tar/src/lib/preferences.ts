import {
  getSettings as getSettingsMap,
  saveSetting as saveSettingRow,
  getMemory,
  saveMemory as saveMemoryRow,
  deleteMemory as deleteMemoryRow,
  clearMemory,
} from "@/lib/data";
import type { Settings, MemoryEntry } from "@/lib/types";

export async function getSettings(): Promise<Settings> {
  const map = await getSettingsMap();
  return {
    displayName: "Operator",
    model: map.model ?? "auto",
    responseStyle: (map.responseStyle as Settings["responseStyle"]) ?? "balanced",
    voiceEnabled: map.voiceEnabled !== "false",
    ttsVoice: map.ttsVoice ?? "default",
    ttsRate: Number(map.ttsRate ?? 1),
    theme: (map.theme as Settings["theme"]) ?? "dark",
    reducedMotion: map.reducedMotion === "true",
    memoryEnabled: map.memoryEnabled !== "false",
  };
}

export async function saveSetting(userId: string, key: string, value: string): Promise<void> {
  void userId; // single-operator; id baked into the data layer
  await saveSettingRow(key, value);
}

export async function updateDisplayName(_userId: string, name: string): Promise<void> {
  // Display name is fixed to "Operator" in the single-user model; store it as
  // a setting so Settings can still show/edit it.
  await saveSettingRow("displayName", name.trim().slice(0, 60) || "Operator");
}

export async function getMemoryList(): Promise<MemoryEntry[]> {
  return getMemory();
}

export async function saveMemory(userId: string, key: string, value: string): Promise<MemoryEntry> {
  void userId;
  const k = key.trim().slice(0, 80);
  const v = value.trim().slice(0, 2000);
  if (!k || !v) throw new Error("Key and value are required.");
  return saveMemoryRow(k, v);
}

export async function deleteMemory(userId: string, id: string): Promise<void> {
  void userId;
  await deleteMemoryRow(id);
}

export async function clearAllMemory(userId: string): Promise<void> {
  void userId;
  await clearMemory();
}

// Returns memory entries as a compact string for inclusion in the system prompt.
export async function getMemoryContext(userId: string): Promise<string> {
  void userId;
  const settings = await getSettings();
  if (!settings.memoryEnabled) return "";
  const mem = await getMemory();
  if (mem.length === 0) return "";
  const lines = mem.map((m) => `- ${m.key}: ${m.value}`).join("\n");
  return `\n\nSaved user preferences (respect these; the user may edit or delete them):\n${lines}`;
}
