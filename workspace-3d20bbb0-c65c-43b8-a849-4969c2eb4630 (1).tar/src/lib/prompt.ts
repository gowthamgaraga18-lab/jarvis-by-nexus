import { listTools } from "@/lib/tools/registry";
import { getSettings, getMemoryContext } from "@/lib/preferences";
import type { Settings } from "@/lib/types";
import type { ParsedToolCall } from "@/lib/types";

const TOOL_CALL_RE = /<<<TOOL_CALL:([a-z_]+)>>>\s*([\s\S]*?)\s*<<<END_TOOL_CALL>>>/g;

/** Extract tool-call blocks from a model output. Returns prose + parsed calls. */
export function parseToolCalls(text: string): { prose: string; calls: ParsedToolCall[] } {
  const calls: ParsedToolCall[] = [];
  let prose = text;
  let match: RegExpExecArray | null;
  TOOL_CALL_RE.lastIndex = 0;
  const cleaned = text.replace(TOOL_CALL_RE, (_full, name: string, body: string) => {
    try {
      const input = JSON.parse(body.trim());
      calls.push({ tool: String(name), input });
      return "";
    } catch {
      return "";
    }
  });
  prose = cleaned.replace(/\n{3,}/g, "\n\n").trim();
  return { prose, calls };
}

function styleInstruction(style: Settings["responseStyle"]): string {
  switch (style) {
    case "concise":
      return "Keep answers short and to the point. Prefer 1-3 sentences unless the user asks for depth.";
    case "detailed":
      return "Provide thorough, well-structured answers with context and examples where useful.";
    default:
      return "Balance brevity and depth. Be clear and complete without padding.";
  }
}

const BASE_SYSTEM = `You are JARVIS, a calm, capable, and honest personal AI assistant.

Core principles:
- Be genuinely helpful: answer questions, brainstorm, explain, help with code, and assist with study.
- Be honest. If you are not certain of a live fact, say so plainly. Never fabricate dates, prices, news, weather, or live data.
- You cannot access the user's email, files, contacts, financial accounts, or devices. Do not pretend to.
- You cannot control the operating system, install software, or change security settings. If asked, explain the limitation and offer a safe alternative.
- When the user asks you to take a consequential action (create a task, save a note, open a link), use the tool-call protocol below. The user will be asked to confirm before anything is saved or changed.
- Respect the user's saved preferences. Do not store new preferences silently; ask first.
- Use Markdown for formatting. Use fenced code blocks with language tags for code.

Tool-call protocol:
When the user asks you to perform a supported action, emit a single fenced block in EXACTLY this format and nothing else inside it:

<<<TOOL_CALL:TOOL_NAME>>>
{ "field": "value" }
<<<END_TOOL_CALL>>>

Rules for tool calls:
- Use only the tool names listed below.
- All dates must be ISO 8601 strings (e.g. "2025-10-05T10:00:00.000Z"). For relative terms like "tomorrow", compute the actual date. Never output words like "tomorrow" in a date field.
- For create_task, include title (required), and optionally priority (low|medium|high), category, description, and dueDate (ISO).
- For save_note, include title and content (markdown). projectId is optional.
- For web_search, include query (required) and optionally num (1-10) and recencyDays. Use this when the user asks about current events, recent news, live prices, or facts you cannot verify from memory. After the search completes, summarize the results for the user and always cite the source URLs.
- For generate_image, include prompt (required, detailed and visual) and optionally size (one of 1024x1024, 1344x768, 768x1344, 1440x720, 720x1440). The user must approve before generation runs.
- You may add a short sentence before or after the block to explain what you propose. The system will parse the block, show the user a confirmation card, and execute only after approval. Do not claim the action is done — only that you have proposed it.`;

export async function buildSystemPrompt(_userId: string): Promise<{ system: string; model: string; style: Settings["responseStyle"] }> {
  const settings = await getSettings();
  const tools = listTools();
  const toolList = tools
    .map((t) => `- ${t.name}: ${t.description} (fields: ${t.schema.map((f) => f.name).join(", ")})`)
    .join("\n");
  const memory = await getMemoryContext();
  const system = [
    BASE_SYSTEM,
    `\nResponse style: ${styleInstruction(settings.responseStyle)}`,
    `\nAvailable tools:\n${toolList}`,
    memory,
  ].join("\n");
  return { system, model: settings.model, style: settings.responseStyle };
}
