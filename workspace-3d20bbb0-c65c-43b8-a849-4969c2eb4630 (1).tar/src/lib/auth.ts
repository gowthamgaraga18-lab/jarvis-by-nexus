import { cookies } from "next/headers";
import { OPERATOR_ID } from "@/lib/supabase";

export const SESSION_COOKIE = "jarvis_session";
const SESSION_TTL_DAYS = 30;

// With the sign-in page removed, JARVIS is a single-user app. Every request
// acts as the fixed local "Operator" whose profile + data live in Supabase.
// The cookie is just an "initialized" marker for the client; there is no
// server-side session table.

export interface SafeUser {
  id: string;
  email: string;
  displayName: string;
}

const OPERATOR: SafeUser = {
  id: OPERATOR_ID,
  email: "operator@jarvis.local",
  displayName: "Operator",
};

function isProd() {
  return process.env.NODE_ENV === "production";
}

async function setSessionCookie(): Promise<void> {
  (await cookies()).set(SESSION_COOKIE, "operator", {
    httpOnly: true,
    sameSite: "lax",
    secure: isProd(),
    path: "/",
    maxAge: SESSION_TTL_DAYS * 24 * 60 * 60,
  });
}

/** Always returns the Operator; sets the init cookie on first contact. */
export async function ensureDefaultUser(): Promise<SafeUser> {
  await setSessionCookie();
  return OPERATOR;
}

/** Returns the Operator if the init cookie is present, else null. */
export async function getCurrentUser(): Promise<SafeUser | null> {
  const c = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!c) return null;
  return OPERATOR;
}

/** Every protected route calls this — always the Operator. */
export async function requireUser(): Promise<SafeUser> {
  return OPERATOR;
}
