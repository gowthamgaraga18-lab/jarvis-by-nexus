// Shared TypeScript types for JARVIS AI.

export type Role = "user" | "assistant" | "system";

export interface SafeUser {
  id: string;
  email: string;
  displayName: string;
  createdAt: Date;
}

export interface ChatMessage {
  id?: string;
  role: Role;
  content: string;
  createdAt?: string;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
}

export type Priority = "low" | "medium" | "high";
export type TaskStatus = "todo" | "in_progress" | "done";

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: Priority;
  status: TaskStatus;
  category: string;
  dueDate: string | null;
  projectId: string | null;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  projectId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  goal: string;
  createdAt: string;
  updatedAt: string;
  taskCount?: number;
  completedTaskCount?: number;
  noteCount?: number;
  progress?: number; // 0..100
}

export type ResponseStyle = "concise" | "balanced" | "detailed";
export type ThemeMode = "dark" | "light";

export interface Settings {
  displayName: string;
  model: string; // "auto" or a specific model id
  responseStyle: ResponseStyle;
  voiceEnabled: boolean;
  ttsVoice: string;
  ttsRate: number;
  theme: ThemeMode;
  reducedMotion: boolean;
  memoryEnabled: boolean;
}

export interface MemoryEntry {
  id: string;
  key: string;
  value: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditEvent {
  id: string;
  toolName: string;
  input: string;
  result: string;
  status: "success" | "denied" | "error";
  createdAt: string;
}

export interface ConnectionStatus {
  id: string;
  name: string;
  description: string;
  status: "connected" | "not_configured" | "error";
  detail?: string;
}

// ---- Permissioned tool registry types ----
export type ToolStatus = "success" | "denied" | "error";

export interface ToolResult {
  ok: boolean;
  status: ToolStatus;
  message: string;
  data?: unknown;
}

export interface ToolDef<TInput = Record<string, unknown>> {
  name: string;
  label: string;
  description: string;
  requiresConfirmation: boolean;
  // Zod-style schema description (lightweight, for UI + validation)
  schema: ToolField[];
  // Server-side execution. Receives validated input + authenticated userId.
  execute: (input: TInput, userId: string) => Promise<ToolResult>;
}

export interface ToolField {
  name: string;
  type: "string" | "number" | "boolean" | "date";
  label: string;
  required: boolean;
  options?: string[];
  placeholder?: string;
}

// In-stream tool call emitted by the model (parsed from fenced blocks).
export interface ParsedToolCall {
  tool: string;
  input: Record<string, unknown>;
}

export type AssistantState = "idle" | "listening" | "processing" | "speaking" | "error";

export type ImageSize = "1024x1024" | "768x1344" | "864x1152" | "1344x768" | "1152x864" | "1440x720" | "720x1440";
