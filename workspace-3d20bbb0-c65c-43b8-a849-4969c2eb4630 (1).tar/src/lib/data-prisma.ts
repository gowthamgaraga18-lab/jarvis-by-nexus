import { db } from "@/lib/db";
import type { Task, Note, Project, Conversation, ChatMessage, Priority, TaskStatus, Settings, MemoryEntry } from "@/lib/types";

// ============================================================================
// Prisma+SQLite fallback for the data layer. Used automatically when the
// Supabase schema isn't applied yet (anon key can't run DDL). Once the user
// runs supabase/schema.sql, the Supabase path takes over and this is dormant.
// All data is scoped to a single local Operator account (find-or-create).
// ============================================================================

const OPERATOR_EMAIL = "operator@jarvis.local";

async function operatorId(): Promise<string> {
  let u = await db.user.findUnique({ where: { email: OPERATOR_EMAIL } });
  if (!u) {
    u = await db.user.create({
      data: { email: OPERATOR_EMAIL, displayName: "Operator", passwordHash: "local-only:no-password" },
    });
    // seed default settings
    const defaults: { key: string; value: string }[] = [
      { key: "model", value: "auto" },
      { key: "responseStyle", value: "balanced" },
      { key: "voiceEnabled", value: "true" },
      { key: "ttsVoice", value: "default" },
      { key: "ttsRate", value: "1" },
      { key: "theme", value: "dark" },
      { key: "reducedMotion", value: "false" },
      { key: "memoryEnabled", value: "true" },
    ];
    for (const d of defaults) {
      await db.preference.upsert({
        where: { userId_category_key: { userId: u.id, category: "settings", key: d.key } },
        update: {},
        create: { userId: u.id, category: "settings", key: d.key, value: d.value },
      });
    }
  }
  return u.id;
}

function taskSer(t: any): Task {
  return {
    id: t.id, title: t.title, description: t.description ?? "", priority: t.priority, status: t.status,
    category: t.category ?? "", dueDate: t.dueDate ? t.dueDate.toISOString() : null, projectId: t.projectId ?? null,
    createdAt: t.createdAt.toISOString(), updatedAt: t.updatedAt.toISOString(),
    completedAt: t.completedAt ? t.completedAt.toISOString() : null,
  };
}
function noteSer(n: any): Note {
  return { id: n.id, title: n.title, content: n.content ?? "", projectId: n.projectId ?? null, createdAt: n.createdAt.toISOString(), updatedAt: n.updatedAt.toISOString() };
}
function projSer(p: any, taskCount = 0, done = 0, noteCount = 0): Project {
  return { id: p.id, name: p.name, description: p.description ?? "", goal: p.goal ?? "", createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString(), taskCount, completedTaskCount: done, noteCount, progress: taskCount ? Math.round((done / taskCount) * 100) : 0 };
}

// ---- Tasks ---------------------------------------------------------------
export async function listTasksPrisma(opts: { view?: string; q?: string; projectId?: string | null }): Promise<Task[]> {
  const uid = await operatorId();
  const where: any = { userId: uid };
  const view = opts.view ?? "all";
  if (opts.projectId) where.projectId = opts.projectId;
  if (opts.q) where.OR = [{ title: { contains: opts.q } }, { description: { contains: opts.q } }, { category: { contains: opts.q } }];
  const now = new Date();
  const startOfDay = new Date(now); startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(now); endOfDay.setHours(23, 59, 59, 999);
  const in7 = new Date(now.getTime() + 7 * 86400000);
  if (view === "today") { where.dueDate = { gte: startOfDay, lte: endOfDay }; where.status = { not: "done" }; }
  else if (view === "upcoming") { where.dueDate = { gte: now, lte: in7 }; where.status = { not: "done" }; }
  else if (view === "completed") { where.status = "done"; }
  else if (view === "active") { where.status = { not: "done" }; }
  const orderBy = view === "completed" ? [{ completedAt: "desc" as const }] : [{ dueDate: "asc" as const }, { createdAt: "desc" as const }];
  const tasks = await db.task.findMany({ where, orderBy, take: 200 });
  return tasks.map(taskSer);
}

export async function getTaskPrisma(id: string): Promise<Task | null> {
  const uid = await operatorId();
  const t = await db.task.findFirst({ where: { id, userId: uid } });
  return t ? taskSer(t) : null;
}

export async function createTaskPrisma(data: { title: string; description?: string; priority?: Priority; status?: TaskStatus; category?: string; dueDate?: string | null; projectId?: string | null }): Promise<Task> {
  const uid = await operatorId();
  const t = await db.task.create({
    data: {
      userId: uid,
      title: String(data.title).slice(0, 200),
      description: String(data.description ?? "").slice(0, 4000),
      priority: (data.priority as Priority) ?? "medium",
      status: (data.status as TaskStatus) ?? "todo",
      category: String(data.category ?? "").slice(0, 60),
      dueDate: data.dueDate ? new Date(data.dueDate) : null,
      projectId: data.projectId ?? null,
      completedAt: data.status === "done" ? new Date() : null,
    },
  });
  return taskSer(t);
}

export async function updateTaskPrisma(id: string, patch: Partial<Task>): Promise<Task | null> {
  const uid = await operatorId();
  const existing = await db.task.findFirst({ where: { id, userId: uid } });
  if (!existing) return null;
  const data: any = {};
  if (patch.title !== undefined) data.title = String(patch.title).slice(0, 200);
  if (patch.description !== undefined) data.description = String(patch.description).slice(0, 4000);
  if (patch.priority !== undefined && ["low", "medium", "high"].includes(patch.priority)) data.priority = patch.priority;
  if (patch.category !== undefined) data.category = String(patch.category).slice(0, 60);
  if (patch.dueDate !== undefined) data.dueDate = patch.dueDate ? new Date(patch.dueDate) : null;
  if (patch.projectId !== undefined) data.projectId = patch.projectId || null;
  if (patch.status !== undefined && ["todo", "in_progress", "done"].includes(patch.status)) {
    data.status = patch.status;
    if (patch.status === "done" && !existing.completedAt) data.completedAt = new Date();
    if (patch.status !== "done") data.completedAt = null;
  }
  const t = await db.task.update({ where: { id }, data });
  return taskSer(t);
}

export async function deleteTaskPrisma(id: string): Promise<void> {
  const uid = await operatorId();
  await db.task.deleteMany({ where: { id, userId: uid } });
}

export async function countTasksPrisma(opts: { status?: TaskStatus; statusNot?: TaskStatus; dueLt?: Date; dueGte?: Date; dueLte?: Date }): Promise<number> {
  const uid = await operatorId();
  const where: any = { userId: uid };
  if (opts.status) where.status = opts.status;
  if (opts.statusNot) where.status = { not: opts.statusNot };
  if (opts.dueGte || opts.dueLte || opts.dueLt) {
    where.dueDate = {};
    if (opts.dueGte) where.dueDate.gte = opts.dueGte;
    if (opts.dueLte) where.dueDate.lte = opts.dueLte;
    if (opts.dueLt) where.dueDate.lt = opts.dueLt;
  }
  return db.task.count({ where });
}

// ---- Notes ---------------------------------------------------------------
export async function listNotesPrisma(opts: { q?: string; projectId?: string | null }): Promise<Note[]> {
  const uid = await operatorId();
  const where: any = { userId: uid };
  if (opts.projectId) where.projectId = opts.projectId;
  if (opts.q) where.OR = [{ title: { contains: opts.q } }, { content: { contains: opts.q } }];
  const notes = await db.note.findMany({ where, orderBy: { updatedAt: "desc" }, take: 200 });
  return notes.map(noteSer);
}

export async function getNotePrisma(id: string): Promise<Note | null> {
  const uid = await operatorId();
  const n = await db.note.findFirst({ where: { id, userId: uid } });
  return n ? noteSer(n) : null;
}

export async function createNotePrisma(data: { title: string; content?: string; projectId?: string | null }): Promise<Note> {
  const uid = await operatorId();
  const n = await db.note.create({
    data: { userId: uid, title: String(data.title).slice(0, 200), content: String(data.content ?? "").slice(0, 20000), projectId: data.projectId ?? null },
  });
  return noteSer(n);
}

export async function updateNotePrisma(id: string, patch: Partial<Note>): Promise<Note | null> {
  const uid = await operatorId();
  const existing = await db.note.findFirst({ where: { id, userId: uid } });
  if (!existing) return null;
  const data: any = {};
  if (patch.title !== undefined) data.title = String(patch.title).slice(0, 200);
  if (patch.content !== undefined) data.content = String(patch.content).slice(0, 20000);
  if (patch.projectId !== undefined) data.projectId = patch.projectId || null;
  const n = await db.note.update({ where: { id }, data });
  return noteSer(n);
}

export async function deleteNotePrisma(id: string): Promise<void> {
  const uid = await operatorId();
  await db.note.deleteMany({ where: { id, userId: uid } });
}

export async function countNotesPrisma(opts: { projectId?: string }): Promise<number> {
  const uid = await operatorId();
  const where: any = { userId: uid };
  if (opts.projectId) where.projectId = opts.projectId;
  return db.note.count({ where });
}

// ---- Projects -----------------------------------------------------------
export async function listProjectsPrisma(opts: { q?: string }): Promise<Project[]> {
  const uid = await operatorId();
  const where: any = { userId: uid };
  if (opts.q) where.OR = [{ name: { contains: opts.q } }, { description: { contains: opts.q } }, { goal: { contains: opts.q } }];
  const projects = await db.project.findMany({ where, orderBy: { updatedAt: "desc" }, take: 100, include: { tasks: true } });
  const out: Project[] = [];
  for (const p of projects) {
    const total = p.tasks.length;
    const done = p.tasks.filter((t: any) => t.status === "done").length;
    const noteCount = await db.note.count({ where: { projectId: p.id } });
    out.push(projSer(p, total, done, noteCount));
  }
  return out;
}

export async function getProjectPrisma(id: string): Promise<(Project & { tasks: Task[]; notes: Note[] }) | null> {
  const uid = await operatorId();
  const p: any = await db.project.findFirst({ where: { id, userId: uid }, include: { tasks: true } });
  if (!p) return null;
  const notes = await db.note.findMany({ where: { projectId: id } });
  const tasks = p.tasks.map(taskSer);
  const done = tasks.filter((t) => t.status === "done").length;
  return { ...projSer(p, tasks.length, done, notes.length), tasks, notes };
}

export async function createProjectPrisma(data: { name: string; description?: string; goal?: string }): Promise<Project> {
  const uid = await operatorId();
  const p = await db.project.create({
    data: { userId: uid, name: String(data.name).slice(0, 120), description: String(data.description ?? "").slice(0, 2000), goal: String(data.goal ?? "").slice(0, 2000) },
  });
  return projSer(p);
}

export async function updateProjectPrisma(id: string, patch: Partial<Project>): Promise<(Project & { tasks: Task[]; notes: Note[] }) | null> {
  const uid = await operatorId();
  const existing = await db.project.findFirst({ where: { id, userId: uid } });
  if (!existing) return null;
  const data: any = {};
  if (patch.name !== undefined) data.name = String(patch.name).slice(0, 120);
  if (patch.description !== undefined) data.description = String(patch.description).slice(0, 2000);
  if (patch.goal !== undefined) data.goal = String(patch.goal).slice(0, 2000);
  await db.project.update({ where: { id }, data });
  return getProjectPrisma(id);
}

export async function deleteProjectPrisma(id: string): Promise<void> {
  const uid = await operatorId();
  await db.task.updateMany({ where: { projectId: id, userId: uid }, data: { projectId: null } });
  await db.note.updateMany({ where: { projectId: id, userId: uid }, data: { projectId: null } });
  await db.project.deleteMany({ where: { id, userId: uid } });
}

// ---- Conversations & messages -------------------------------------------
function convSer(c: any): Conversation {
  return { id: c.id, title: c.title, createdAt: c.createdAt.toISOString(), updatedAt: c.updatedAt.toISOString() };
}

export async function listConversationsPrisma(): Promise<Conversation[]> {
  const uid = await operatorId();
  const convs = await db.conversation.findMany({ where: { userId: uid }, orderBy: { updatedAt: "desc" } });
  return convs.map(convSer);
}

export async function createConversationPrisma(title: string): Promise<Conversation> {
  const uid = await operatorId();
  const c = await db.conversation.create({ data: { userId: uid, title: String(title).slice(0, 120) } });
  return convSer(c);
}

export async function getConversationPrisma(id: string): Promise<Conversation | null> {
  const uid = await operatorId();
  const c = await db.conversation.findFirst({ where: { id, userId: uid } });
  return c ? convSer(c) : null;
}

export async function renameConversationPrisma(id: string, title: string): Promise<Conversation | null> {
  const uid = await operatorId();
  const existing = await db.conversation.findFirst({ where: { id, userId: uid } });
  if (!existing) return null;
  const c = await db.conversation.update({ where: { id }, data: { title: String(title).slice(0, 120) } });
  return convSer(c);
}

export async function deleteConversationPrisma(id: string): Promise<void> {
  const uid = await operatorId();
  const c = await db.conversation.findFirst({ where: { id, userId: uid } });
  if (!c) return;
  await db.conversation.delete({ where: { id } });
}

export async function listMessagesPrisma(conversationId: string): Promise<ChatMessage[]> {
  const conv = await db.conversation.findUnique({ where: { id: conversationId } });
  if (!conv) return [];
  const msgs = await db.message.findMany({ where: { conversationId }, orderBy: { createdAt: "asc" }, take: 100 });
  return msgs.map((m: any) => ({ id: m.id, role: m.role as ChatMessage["role"], content: m.content, createdAt: m.createdAt.toISOString() }));
}

export async function addMessagePrisma(conversationId: string, role: "user" | "assistant" | "system", content: string): Promise<void> {
  await db.message.create({ data: { conversationId, role, content } });
}

export async function touchConversationPrisma(id: string): Promise<void> {
  await db.conversation.update({ where: { id }, data: { updatedAt: new Date() } }).catch(() => {});
}

// ---- Preferences (settings + memory) ------------------------------------
export async function getSettingsPrisma(): Promise<Record<string, string>> {
  const uid = await operatorId();
  const rows = await db.preference.findMany({ where: { userId: uid, category: "settings" } });
  const map: Record<string, string> = {};
  for (const r of rows) map[r.key] = r.value;
  return map;
}

export async function saveSettingPrisma(key: string, value: string): Promise<void> {
  const uid = await operatorId();
  await db.preference.upsert({
    where: { userId_category_key: { userId: uid, category: "settings", key } },
    update: { value },
    create: { userId: uid, category: "settings", key, value },
  });
}

export async function getMemoryPrisma(): Promise<MemoryEntry[]> {
  const uid = await operatorId();
  const rows = await db.preference.findMany({ where: { userId: uid, category: "memory" }, orderBy: { updatedAt: "desc" } });
  return rows.map((r) => ({ id: r.id, key: r.key, value: r.value, createdAt: r.createdAt.toISOString(), updatedAt: r.updatedAt.toISOString() }));
}

export async function saveMemoryPrisma(key: string, value: string): Promise<MemoryEntry> {
  const uid = await operatorId();
  const k = key.trim().slice(0, 80);
  const v = value.trim().slice(0, 2000);
  if (!k || !v) throw new Error("Key and value are required.");
  const row = await db.preference.upsert({
    where: { userId_category_key: { userId: uid, category: "memory", key: k } },
    update: { value: v },
    create: { userId: uid, category: "memory", key: k, value: v },
  });
  return { id: row.id, key: row.key, value: row.value, createdAt: row.createdAt.toISOString(), updatedAt: row.updatedAt.toISOString() };
}

export async function deleteMemoryPrisma(id: string): Promise<void> {
  const uid = await operatorId();
  await db.preference.deleteMany({ where: { id, userId: uid, category: "memory" } });
}

export async function clearMemoryPrisma(): Promise<void> {
  const uid = await operatorId();
  await db.preference.deleteMany({ where: { userId: uid, category: "memory" } });
}

export async function deleteAllConversationsPrisma(): Promise<void> {
  const uid = await operatorId();
  await db.conversation.deleteMany({ where: { userId: uid } });
}

// ---- Audit ---------------------------------------------------------------
export async function addAuditPrisma(toolName: string, input: string, result: string, status: string): Promise<void> {
  const uid = await operatorId();
  await db.auditEvent.create({ data: { userId: uid, toolName, input: input.slice(0, 4000), result: result.slice(0, 1000), status } });
}

// ---- Settings aggregate --------------------------------------------------
export async function loadSettingsPrisma(): Promise<Settings> {
  const map = await getSettingsPrisma();
  const u = await db.user.findUnique({ where: { email: OPERATOR_EMAIL } });
  return {
    displayName: u?.displayName ?? "Operator",
    model: map.model ?? "auto",
    responseStyle: (map.responseStyle as Settings["responseStyle"]) ?? "balanced",
    voiceEnabled: map.voiceEnabled !== "false",
    ttsVoice: map.ttsVoice ?? "default",
    ttsRate: Number(map.ttsRate ?? 1),
    theme: (map.theme as Settings["theme"]) ?? "dark",
    reducedMotion: map.reducedMotion === "true",
    memoryEnabled: map.memoryEnabled !== "false",
  };
}

export async function probeTablesPrisma(): Promise<{ ready: boolean; tables: string[] }> {
  // Prisma always works; report ready so the banner doesn't show.
  return { ready: true, tables: ["profiles", "conversations", "messages", "tasks", "notes", "projects", "preferences", "audit_events"] };
}
