import ZAI from "z-ai-web-dev-sdk";

// Server-only z.ai SDK wrapper. Config is auto-loaded from
// /etc/.z-ai-config (or ./z-ai-config / ~/.z-ai-config). No API keys in code.

let cached: ZAI | null = null;
let initError: string | null = null;

export async function getZAI(): Promise<ZAI> {
  if (cached) return cached;
  try {
    cached = await ZAI.create();
    initError = null;
    return cached;
  } catch (e) {
    initError = e instanceof Error ? e.message : String(e);
    cached = null;
    throw new Error(`z.ai SDK initialization failed: ${initError}`);
  }
}

export function getZaiInitError(): string | null {
  return initError;
}

// Curated list of model ids the user can pick in Settings. "auto" omits the
// model parameter so the provider uses its default. Availability depends on the
// configured provider; an invalid choice surfaces a real API error in the chat.
export const AVAILABLE_MODELS: { id: string; label: string }[] = [
  { id: "auto", label: "Auto (provider default)" },
  { id: "glm-4.6", label: "GLM-4.6" },
  { id: "glm-4.5", label: "GLM-4.5" },
  { id: "glm-4-plus", label: "GLM-4-Plus" },
  { id: "glm-4-flash", label: "GLM-4-Flash (fast)" },
];

export interface ZaiChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface StreamCallbacks {
  onDelta: (text: string) => void;
  onDone?: () => void;
  onError?: (err: Error) => void;
  signal?: AbortSignal;
}

/**
 * Streams a chat completion from z.ai. Parses the OpenAI-style SSE stream
 * server-side and invokes `onDelta` with each content chunk. Resolves when the
 * stream completes. Throws on non-2xx responses or parse failures.
 */
export async function streamChatCompletion(
  messages: ZaiChatMessage[],
  opts: { model?: string; temperature?: number } = {},
  cb: StreamCallbacks
): Promise<void> {
  const zai = await getZAI();
  const body: Record<string, unknown> = {
    messages,
    stream: true,
    thinking: { type: "disabled" },
  };
  if (opts.model && opts.model !== "auto") body.model = opts.model;
  if (typeof opts.temperature === "number") body.temperature = opts.temperature;

  // The SDK returns the raw Response.body (Web ReadableStream<Uint8Array>) when
  // stream:true and the response is event-stream/plain.
  const stream = (await zai.chat.completions.create(body as never)) as ReadableStream<Uint8Array>;
  if (!stream || typeof (stream as any).getReader !== "function") {
    throw new Error("z.ai did not return a readable stream.");
  }

  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    while (true) {
      if (cb.signal?.aborted) {
        await reader.cancel().catch(() => {});
        break;
      }
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let nl: number;
      while ((nl = buffer.indexOf("\n")) !== -1) {
        const line = buffer.slice(0, nl).trim();
        buffer = buffer.slice(nl + 1);
        if (!line) continue;
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (payload === "[DONE]") {
          cb.onDone?.();
          return;
        }
        try {
          const json = JSON.parse(payload);
          const delta: string | undefined =
            json?.choices?.[0]?.delta?.content ??
            json?.choices?.[0]?.message?.content;
          if (delta) cb.onDelta(delta);
        } catch {
          // Ignore malformed SSE lines (keep-aliv etc.).
        }
      }
    }
    cb.onDone?.();
  } catch (err) {
    cb.onError?.(err instanceof Error ? err : new Error(String(err)));
    throw err;
  } finally {
    try {
      await reader.releaseLock();
    } catch {
      /* noop */
    }
  }
}

/** Non-streaming completion for short utility calls (summarize, plan, etc). */
export async function chatCompletion(
  messages: ZaiChatMessage[],
  opts: { model?: string; temperature?: number; maxTokens?: number } = {}
): Promise<string> {
  const zai = await getZAI();
  const body: Record<string, unknown> = {
    messages,
    thinking: { type: "disabled" },
  };
  if (opts.model && opts.model !== "auto") body.model = opts.model;
  if (typeof opts.temperature === "number") body.temperature = opts.temperature;
  if (typeof opts.maxTokens === "number") body.max_tokens = opts.maxTokens;

  const res = (await zai.chat.completions.create(body as never)) as {
    choices?: { message?: { content?: string } }[];
  };
  return res?.choices?.[0]?.message?.content ?? "";
}

/** Lightweight connectivity probe used by /api/status. */
export async function pingZai(): Promise<{ ok: boolean; detail?: string }> {
  try {
    const txt = await chatCompletion(
      [{ role: "user", content: "Reply with the single word: online" }],
      { maxTokens: 8 }
    );
    return { ok: true, detail: txt.slice(0, 60) };
  } catch (e) {
    return { ok: false, detail: e instanceof Error ? e.message : String(e) };
  }
}

// ---------------------------------------------------------------------------
// Advanced z.ai capabilities (image generation, web search, page reader,
// vision). These unlock a much richer assistant experience.
// ---------------------------------------------------------------------------

export type ImageSize = "1024x1024" | "768x1344" | "864x1152" | "1344x768" | "1152x864" | "1440x720" | "720x1440";

/** Generate an image from a text prompt. Returns base64 PNG data URLs. */
export async function generateImage(prompt: string, size: ImageSize = "1024x1024"): Promise<string[]> {
  const zai = await getZAI();
  const res = await zai.images.generations.create({ prompt: prompt.slice(0, 1000), size });
  const data = (res as { data?: { base64?: string }[] }).data ?? [];
  return data.filter((d) => d.base64).map((d) => `data:image/png;base64,${d.base64}`);
}

export interface WebSearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  date: string;
  favicon: string;
}

/** Live web search via z.ai's web_search function. */
export async function webSearch(query: string, num = 5, recencyDays?: number): Promise<WebSearchResult[]> {
  const zai = await getZAI();
  const args: { query: string; num?: number; recency_days?: number } = { query: query.slice(0, 200), num };
  if (recencyDays) args.recency_days = recencyDays;
  const results = await zai.functions.invoke("web_search", args);
  return (results as WebSearchResult[]) ?? [];
}

export interface PageContent {
  title: string;
  url: string;
  html: string;
  publishedTime?: string;
}

/** Fetch + parse a web page's content via z.ai's page_reader function. */
export async function readPage(url: string): Promise<PageContent> {
  const zai = await getZAI();
  const res = await zai.functions.invoke("page_reader", { url });
  const data = (res as { data?: PageContent }).data;
  if (!data) throw new Error("page_reader returned no data.");
  return data;
}

export interface VisionMessage {
  role: "system" | "user" | "assistant";
  content: string | VisionContentItem[];
}
export interface VisionContentItem {
  type: "text" | "image_url";
  text?: string;
  image_url?: { url: string };
}

/** Describe/analyze an image (URL or base64 data URL) using z.ai vision. */
export async function visionChat(prompt: string, imageUrl: string): Promise<string> {
  const zai = await getZAI();
  const body: Record<string, unknown> = {
    model: "glm-4.5v",
    messages: [
      {
        role: "user",
        content: [
          { type: "text", text: prompt.slice(0, 2000) },
          { type: "image_url", image_url: { url: imageUrl } },
        ],
      },
    ] as VisionMessage[],
    thinking: { type: "disabled" },
  };
  const res = (await zai.chat.completions.createVision(body as never)) as {
    choices?: { message?: { content?: string } }[];
  };
  return res?.choices?.[0]?.message?.content ?? "";
}

