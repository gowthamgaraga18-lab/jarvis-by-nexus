import { createClient, type SupabaseClient } from "@supabase/supabase-js";

// The fixed single-user "Operator" id under which all rows are stored. With
// the sign-in page removed and Supabase Auth not used, every row is scoped to
// this UUID. RLS policies in supabase/schema.sql allow the anon key to access
// these rows (single-user local app). For multi-user, switch to Supabase Auth
// and change policies to `user_id = auth.uid()`.
export const OPERATOR_ID = "00000000-0000-0000-0000-000000000001";

function env(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

let _client: SupabaseClient | null = null;

/**
 * Server-side Supabase client. Uses the anon key by default (subject to RLS).
 * If `SUPABASE_SERVICE_ROLE_KEY` is set, uses that to bypass RLS for trusted
 * server operations. The service-role key NEVER reaches the browser.
 */
export function supabaseServer(): SupabaseClient {
  if (_client) return _client;
  const url = env("NEXT_PUBLIC_SUPABASE_URL");
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const anonKey = env("NEXT_PUBLIC_SUPABASE_ANON_KEY");
  // Prefer service role when configured (server-only).
  const key = serviceKey && serviceKey.length > 0 ? serviceKey : anonKey;
  _client = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return _client;
}

/** True when Supabase env vars are configured. */
export function isSupabaseConfigured(): boolean {
  return !!process.env.NEXT_PUBLIC_SUPABASE_URL && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
}
