import { supabaseServer, OPERATOR_ID } from "@/lib/supabase";
import type { Task, Note, Project, Conversation, ChatMessage, Priority, TaskStatus, Settings, MemoryEntry } from "@/lib/types";
import * as P from "@/lib/data-prisma";

// ============================================================================
// Data-access layer. Tries Supabase first; on SCHEMA_NOT_READY (tables not yet
// applied — the anon key can't run DDL) it transparently falls back to the
// local Prisma+SQLite store. So the app is fully functional immediately, and
// once the user runs supabase/schema.sql, Supabase takes over automatically.
// All rows are scoped to the fixed OPERATOR_ID (single-user app).
// ============================================================================

const UID = OPERATOR_ID;

class DbError extends Error {
  constructor(public code: string, message: string) { super(message); }
}

function assertReady(res: { error: unknown | null; data: unknown }) {
  if (res.error && typeof res.error === "object" && "code" in res.error) {
    const code = String((res.error as { code?: string }).code ?? "");
    if (code === "PGRST205" || code === "42P01" || code === "404") {
      throw new DbError("SCHEMA_NOT_READY", "Supabase schema is not set up. Run supabase/schema.sql in the Supabase SQL editor (link in the yellow banner at the top).");
    }
  }
}

function isNotReady(e: unknown): boolean {
  return e instanceof DbError && e.code === "SCHEMA_NOT_READY";
}

async function withFallback<T>(sb: () => Promise<T>, prisma: () => Promise<T>): Promise<T> {
  try {
    return await sb();
  } catch (e) {
    if (isNotReady(e)) return prisma();
    throw e;
  }
}

// ---- mappers -------------------------------------------------------------
interface TaskRow {
  id: string; user_id: string; title: string; description: string;
  priority: Priority; status: TaskStatus; category: string; due_date: string | null;
  project_id: string | null; created_at: string; updated_at: string; completed_at: string | null;
}
function taskFromRow(r: TaskRow): Task {
  return {
    id: r.id, title: r.title, description: r.description ?? "", priority: r.priority, status: r.status,
    category: r.category ?? "", dueDate: r.due_date, projectId: r.project_id,
    createdAt: r.created_at, updatedAt: r.updated_at, completedAt: r.completed_at,
  };
}
interface NoteRow { id: string; user_id: string; title: string; content: string; project_id: string | null; created_at: string; updated_at: string; }
function noteFromRow(r: NoteRow): Note {
  return { id: r.id, title: r.title, content: r.content ?? "", projectId: r.project_id, createdAt: r.created_at, updatedAt: r.updated_at };
}
interface ProjectRow { id: string; user_id: string; name: string; description: string; goal: string; created_at: string; updated_at: string; }
function projectBase(r: ProjectRow): Project {
  return { id: r.id, name: r.name, description: r.description ?? "", goal: r.goal ?? "", createdAt: r.created_at, updatedAt: r.updated_at };
}
function convFromRow(r: { id: string; title: string; created_at: string; updated_at: string }): Conversation {
  return { id: r.id, title: r.title, createdAt: r.created_at, updatedAt: r.updated_at };
}

// ============================ TASKS =======================================
export async function listTasks(opts: { view?: string; q?: string; projectId?: string | null }): Promise<Task[]> {
  return withFallback(async () => {
    const sb = supabaseServer();
    let q = sb.from("tasks").select("*").eq("user_id", UID);
    const view = opts.view ?? "all";
    if (opts.projectId) q = q.eq("project_id", opts.projectId);
    if (opts.q) { const s = `%${opts.q}%`; q = q.or(`title.ilike.${s},description.ilike.${s},category.ilike.${s}`); }
    const now = new Date();
    const startOfDay = new Date(now); startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(now); endOfDay.setHours(23, 59, 59, 999);
    const in7 = new Date(now.getTime() + 7 * 86400000);
    if (view === "today") q = q.gte("due_date", startOfDay.toISOString()).lte("due_date", endOfDay.toISOString()).neq("status", "done");
    else if (view === "upcoming") q = q.gte("due_date", now.toISOString()).lte("due_date", in7.toISOString()).neq("status", "done");
    else if (view === "completed") q = q.eq("status", "done");
    else if (view === "active") q = q.neq("status", "done");
    if (view === "completed") q = q.order("completed_at", { ascending: false, nullsFirst: false });
    else q = q.order("due_date", { ascending: true, nullsFirst: true }).order("created_at", { ascending: false });
    const res = await q.limit(200);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return (res.data as TaskRow[]).map(taskFromRow);
  }, () => P.listTasksPrisma(opts));
}

export async function getTask(id: string): Promise<Task | null> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("tasks").select("*").eq("id", id).eq("user_id", UID).maybeSingle();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return res.data ? taskFromRow(res.data as TaskRow) : null;
  }, () => P.getTaskPrisma(id));
}

export async function createTask(data: { title: string; description?: string; priority?: Priority; status?: TaskStatus; category?: string; dueDate?: string | null; projectId?: string | null }): Promise<Task> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const insert: Record<string, unknown> = {
      user_id: UID, title: String(data.title).slice(0, 200),
      description: String(data.description ?? "").slice(0, 4000),
      priority: data.priority ?? "medium", status: data.status ?? "todo",
      category: String(data.category ?? "").slice(0, 60),
      due_date: data.dueDate ? new Date(data.dueDate).toISOString() : null,
      project_id: data.projectId ?? null,
      completed_at: data.status === "done" ? new Date().toISOString() : null,
    };
    const res = await sb.from("tasks").insert(insert).select("*").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return taskFromRow(res.data as TaskRow);
  }, () => P.createTaskPrisma(data));
}

export async function updateTask(id: string, patch: Partial<Task>): Promise<Task | null> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const existing = await getTask(id);
    if (!existing) return null;
    const upd: Record<string, unknown> = {};
    if (patch.title !== undefined) upd.title = String(patch.title).slice(0, 200);
    if (patch.description !== undefined) upd.description = String(patch.description).slice(0, 4000);
    if (patch.priority !== undefined && ["low", "medium", "high"].includes(patch.priority)) upd.priority = patch.priority;
    if (patch.category !== undefined) upd.category = String(patch.category).slice(0, 60);
    if (patch.dueDate !== undefined) upd.due_date = patch.dueDate ? new Date(patch.dueDate).toISOString() : null;
    if (patch.projectId !== undefined) upd.project_id = patch.projectId || null;
    if (patch.status !== undefined && ["todo", "in_progress", "done"].includes(patch.status)) {
      upd.status = patch.status;
      if (patch.status === "done" && !existing.completedAt) upd.completed_at = new Date().toISOString();
      if (patch.status !== "done") upd.completed_at = null;
    }
    const res = await sb.from("tasks").update(upd).eq("id", id).eq("user_id", UID).select("*").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return taskFromRow(res.data as TaskRow);
  }, () => P.updateTaskPrisma(id, patch));
}

export async function deleteTask(id: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("tasks").delete().eq("id", id).eq("user_id", UID);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.deleteTaskPrisma(id));
}

export async function countTasks(opts: { status?: TaskStatus; statusNot?: TaskStatus; dueLt?: Date; dueGte?: Date; dueLte?: Date }): Promise<number> {
  return withFallback(async () => {
    const sb = supabaseServer();
    // Use a real select (not head:true) so a missing table surfaces PGRST205
    // (head:true returns 204 even for absent tables → false-positive 0).
    let q = sb.from("tasks").select("id", { count: "exact" }).eq("user_id", UID);
    if (opts.status) q = q.eq("status", opts.status);
    if (opts.statusNot) q = q.neq("status", opts.statusNot);
    if (opts.dueGte) q = q.gte("due_date", opts.dueGte.toISOString());
    if (opts.dueLte) q = q.lte("due_date", opts.dueLte.toISOString());
    if (opts.dueLt) q = q.lt("due_date", opts.dueLt.toISOString());
    const res = await q.limit(1);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return res.count ?? 0;
  }, () => P.countTasksPrisma(opts));
}

// ============================ NOTES =======================================
export async function listNotes(opts: { q?: string; projectId?: string | null }): Promise<Note[]> {
  return withFallback(async () => {
    const sb = supabaseServer();
    let q = sb.from("notes").select("*").eq("user_id", UID);
    if (opts.projectId) q = q.eq("project_id", opts.projectId);
    if (opts.q) { const s = `%${opts.q}%`; q = q.or(`title.ilike.${s},content.ilike.${s}`); }
    q = q.order("updated_at", { ascending: false });
    const res = await q.limit(200);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return (res.data as NoteRow[]).map(noteFromRow);
  }, () => P.listNotesPrisma(opts));
}

export async function getNote(id: string): Promise<Note | null> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("notes").select("*").eq("id", id).eq("user_id", UID).maybeSingle();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return res.data ? noteFromRow(res.data as NoteRow) : null;
  }, () => P.getNotePrisma(id));
}

export async function createNote(data: { title: string; content?: string; projectId?: string | null }): Promise<Note> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("notes").insert({
      user_id: UID, title: String(data.title).slice(0, 200),
      content: String(data.content ?? "").slice(0, 20000), project_id: data.projectId ?? null,
    }).select("*").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return noteFromRow(res.data as NoteRow);
  }, () => P.createNotePrisma(data));
}

export async function updateNote(id: string, patch: Partial<Note>): Promise<Note | null> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const existing = await getNote(id);
    if (!existing) return null;
    const upd: Record<string, unknown> = {};
    if (patch.title !== undefined) upd.title = String(patch.title).slice(0, 200);
    if (patch.content !== undefined) upd.content = String(patch.content).slice(0, 20000);
    if (patch.projectId !== undefined) upd.project_id = patch.projectId || null;
    const res = await sb.from("notes").update(upd).eq("id", id).eq("user_id", UID).select("*").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return noteFromRow(res.data as NoteRow);
  }, () => P.updateNotePrisma(id, patch));
}

export async function deleteNote(id: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("notes").delete().eq("id", id).eq("user_id", UID);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.deleteNotePrisma(id));
}

export async function countNotes(opts: { projectId?: string }): Promise<number> {
  return withFallback(async () => {
    const sb = supabaseServer();
    // Real select (not head:true) so missing tables surface PGRST205.
    let q = sb.from("notes").select("id", { count: "exact" }).eq("user_id", UID);
    if (opts.projectId) q = q.eq("project_id", opts.projectId);
    const res = await q.limit(1);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return res.count ?? 0;
  }, () => P.countNotesPrisma(opts));
}

// ============================ PROJECTS ====================================
export async function listProjects(opts: { q?: string }): Promise<Project[]> {
  return withFallback(async () => {
    const sb = supabaseServer();
    let q = sb.from("projects").select("*").eq("user_id", UID);
    if (opts.q) { const s = `%${opts.q}%`; q = q.or(`name.ilike.${s},description.ilike.${s},goal.ilike.${s}`); }
    q = q.order("updated_at", { ascending: false });
    const res = await q.limit(100);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    const projects = (res.data as ProjectRow[]).map(projectBase);
    const out: Project[] = [];
    for (const p of projects) {
      const total = await sb.from("tasks").select("id,status", { count: "exact" }).eq("user_id", UID).eq("project_id", p.id);
      const notesCount = await countNotes({ projectId: p.id });
      const tasks = (total.data as { status: string }[]) ?? [];
      const done = tasks.filter((t) => t.status === "done").length;
      out.push({ ...p, taskCount: tasks.length, completedTaskCount: done, noteCount: notesCount, progress: tasks.length ? Math.round((done / tasks.length) * 100) : 0 });
    }
    return out;
  }, () => P.listProjectsPrisma(opts));
}

export async function getProject(id: string): Promise<(Project & { tasks: Task[]; notes: Note[] }) | null> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("projects").select("*").eq("id", id).eq("user_id", UID).maybeSingle();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    if (!res.data) return null;
    const p = projectBase(res.data as ProjectRow);
    const tasksRes = await sb.from("tasks").select("*").eq("user_id", UID).eq("project_id", id);
    const notesRes = await sb.from("notes").select("*").eq("user_id", UID).eq("project_id", id);
    const tasks = (tasksRes.data as TaskRow[]).map(taskFromRow);
    const notes = (notesRes.data as NoteRow[]).map(noteFromRow);
    const done = tasks.filter((t) => t.status === "done").length;
    return { ...p, tasks, notes, taskCount: tasks.length, completedTaskCount: done, noteCount: notes.length, progress: tasks.length ? Math.round((done / tasks.length) * 100) : 0 };
  }, () => P.getProjectPrisma(id));
}

export async function createProject(data: { name: string; description?: string; goal?: string }): Promise<Project> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("projects").insert({
      user_id: UID, name: String(data.name).slice(0, 120),
      description: String(data.description ?? "").slice(0, 2000), goal: String(data.goal ?? "").slice(0, 2000),
    }).select("*").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return projectBase(res.data as ProjectRow);
  }, () => P.createProjectPrisma(data));
}

export async function updateProject(id: string, patch: Partial<Project>): Promise<(Project & { tasks: Task[]; notes: Note[] }) | null> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const existing = await getProject(id);
    if (!existing) return null;
    const upd: Record<string, unknown> = {};
    if (patch.name !== undefined) upd.name = String(patch.name).slice(0, 120);
    if (patch.description !== undefined) upd.description = String(patch.description).slice(0, 2000);
    if (patch.goal !== undefined) upd.goal = String(patch.goal).slice(0, 2000);
    const res = await sb.from("projects").update(upd).eq("id", id).eq("user_id", UID).select("*").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return getProject(id);
  }, () => P.updateProjectPrisma(id, patch));
}

export async function deleteProject(id: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    await sb.from("tasks").update({ project_id: null }).eq("project_id", id).eq("user_id", UID);
    await sb.from("notes").update({ project_id: null }).eq("project_id", id).eq("user_id", UID);
    const res = await sb.from("projects").delete().eq("id", id).eq("user_id", UID);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.deleteProjectPrisma(id));
}

// ======================== CONVERSATIONS & MESSAGES ========================
export async function listConversations(): Promise<Conversation[]> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("conversations").select("id,title,created_at,updated_at").eq("user_id", UID).order("updated_at", { ascending: false });
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return (res.data as Conversation[]).map(convFromRow);
  }, () => P.listConversationsPrisma());
}

export async function createConversation(title: string): Promise<Conversation> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("conversations").insert({ user_id: UID, title: String(title).slice(0, 120) }).select("id,title,created_at,updated_at").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return convFromRow(res.data);
  }, () => P.createConversationPrisma(title));
}

export async function getConversation(id: string): Promise<Conversation | null> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("conversations").select("id,title,created_at,updated_at").eq("id", id).eq("user_id", UID).maybeSingle();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return res.data ? convFromRow(res.data) : null;
  }, () => P.getConversationPrisma(id));
}

export async function renameConversation(id: string, title: string): Promise<Conversation | null> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("conversations").update({ title: String(title).slice(0, 120) }).eq("id", id).eq("user_id", UID).select("id,title,created_at,updated_at").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return res.data ? convFromRow(res.data) : null;
  }, () => P.renameConversationPrisma(id, title));
}

export async function deleteConversation(id: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("conversations").delete().eq("id", id).eq("user_id", UID);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.deleteConversationPrisma(id));
}

export async function listMessages(conversationId: string): Promise<ChatMessage[]> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("messages").select("id,role,content,created_at").eq("conversation_id", conversationId).order("created_at", { ascending: true }).limit(100);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return (res.data as { id: string; role: string; content: string; created_at: string }[]).map((m) => ({ id: m.id, role: m.role as ChatMessage["role"], content: m.content, createdAt: m.created_at }));
  }, () => P.listMessagesPrisma(conversationId));
}

export async function addMessage(conversationId: string, role: "user" | "assistant" | "system", content: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("messages").insert({ conversation_id: conversationId, role, content });
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.addMessagePrisma(conversationId, role, content));
}

export async function touchConversation(id: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", id);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.touchConversationPrisma(id));
}

// ========================== PREFERENCES ==================================
export async function getSettings(): Promise<Record<string, string>> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("preferences").select("key,value").eq("user_id", UID).eq("category", "settings");
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    const map: Record<string, string> = {};
    for (const r of (res.data as { key: string; value: string }[])) {
      map[r.key] = r.value;
    }
    return map;
  }, () => P.getSettingsPrisma());
}

export async function saveSetting(key: string, value: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    await sb.from("preferences").delete().eq("user_id", UID).eq("category", "settings").eq("key", key);
    const res = await sb.from("preferences").insert({ user_id: UID, category: "settings", key, value });
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.saveSettingPrisma(key, value));
}

export async function getMemory(): Promise<MemoryEntry[]> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("preferences").select("id,key,value,created_at,updated_at").eq("user_id", UID).eq("category", "memory").order("updated_at", { ascending: false });
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return (res.data as { id: string; key: string; value: string; created_at: string; updated_at: string }[]).map((r) => ({ id: r.id, key: r.key, value: r.value, createdAt: r.created_at, updatedAt: r.updated_at }));
  }, () => P.getMemoryPrisma());
}

export async function saveMemory(key: string, value: string): Promise<MemoryEntry> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const existing = await sb.from("preferences").select("id").eq("user_id", UID).eq("category", "memory").eq("key", key).maybeSingle();
    if (existing.data) {
      const res = await sb.from("preferences").update({ value }).eq("id", existing.data.id).select("id,key,value,created_at,updated_at").single();
      assertReady(res);
      if (res.error) throw new Error(res.error.message);
      return res.data as MemoryEntry;
    }
    const res = await sb.from("preferences").insert({ user_id: UID, category: "memory", key, value }).select("id,key,value,created_at,updated_at").single();
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
    return res.data as MemoryEntry;
  }, () => P.saveMemoryPrisma(key, value));
}

export async function deleteMemory(id: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("preferences").delete().eq("id", id).eq("user_id", UID).eq("category", "memory");
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.deleteMemoryPrisma(id));
}

export async function clearMemory(): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("preferences").delete().eq("user_id", UID).eq("category", "memory");
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.clearMemoryPrisma());
}

export async function deleteAllConversations(): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("conversations").delete().eq("user_id", UID);
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.deleteAllConversationsPrisma());
}

// ============================== AUDIT =====================================
export async function addAudit(toolName: string, input: string, result: string, status: string): Promise<void> {
  return withFallback(async () => {
    const sb = supabaseServer();
    const res = await sb.from("audit_events").insert({ user_id: UID, tool_name: toolName, input: input.slice(0, 4000), result: result.slice(0, 1000), status });
    assertReady(res);
    if (res.error) throw new Error(res.error.message);
  }, () => P.addAuditPrisma(toolName, input, result, status));
}

// ============================ AGGREGATES ==================================
export async function loadSettings(): Promise<Settings> {
  return withFallback(async () => {
    const map = await getSettings();
    return {
      displayName: "Operator",
      model: map.model ?? "auto",
      responseStyle: (map.responseStyle as Settings["responseStyle"]) ?? "balanced",
      voiceEnabled: map.voiceEnabled !== "false",
      ttsVoice: map.ttsVoice ?? "default",
      ttsRate: Number(map.ttsRate ?? 1),
      theme: (map.theme as Settings["theme"]) ?? "dark",
      reducedMotion: map.reducedMotion === "true",
      memoryEnabled: map.memoryEnabled !== "false",
    };
  }, () => P.loadSettingsPrisma());
}

export async function probeTables(): Promise<{ ready: boolean; tables: string[] }> {
  // Reports the REAL Supabase readiness (does NOT fall back to Prisma). This
  // keeps the Connected Services status + setup banner honest: when Supabase
  // tables aren't applied yet, the banner shows, but the data layer silently
  // uses the local Prisma store so the app stays fully functional.
  try {
    const sb = supabaseServer();
    const expected = ["profiles", "conversations", "messages", "tasks", "notes", "projects", "preferences", "audit_events"];
    const present: string[] = [];
    for (const t of expected) {
      try {
        const r = await sb.from(t).select("id").limit(1);
        if (!r.error) present.push(t);
      } catch {
        /* not ready */
      }
    }
    return { ready: present.length === expected.length, tables: present };
  } catch {
    return { ready: false, tables: [] };
  }
}
