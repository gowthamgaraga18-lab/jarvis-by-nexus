#!/usr/bin/env python3
"""
Generate a PDF containing the full source code of the JARVIS AI project.
Excludes shadcn/ui boilerplate (src/components/ui/**) — those are generated
library components, not project-specific code. A note in the TOC documents this.
"""
import os
import sys
from datetime import datetime

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.colors import HexColor
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Preformatted,
    KeepTogether, Table, TableStyle
)
from reportlab.pdfgen import canvas

PROJECT_ROOT = "/home/z/my-project"
OUTPUT_PDF = "/home/z/my-project/JARVIS-AI-Source-Code.pdf"

# Colors (JARVIS theme: dark graphite + cyan)
C_BG = HexColor("#0f1419")
C_PRIMARY = HexColor("#22d3ee")
C_TEXT = HexColor("#e6edf3")
C_MUTED = HexColor("#7c8db5")
C_ACCENT = HexColor("#3b82f6")
C_CODE_BG = HexColor("#161b22")
C_BORDER = HexColor("#30363d")

FILE_GROUPS = [
    ("Project Configuration", [
        "package.json", "tsconfig.json", "next.config.ts", "tailwind.config.ts",
        "postcss.config.mjs", "components.json", "eslint.config.mjs", "Caddyfile",
    ]),
    ("Database & Schema", ["prisma/schema.prisma", "supabase/schema.sql"]),
    ("App Shell & Layout", ["src/app/layout.tsx", "src/app/page.tsx", "src/app/globals.css"]),
    ("Server Library (src/lib)", [
        "src/lib/types.ts", "src/lib/utils.ts", "src/lib/db.ts", "src/lib/auth.ts",
        "src/lib/supabase.ts", "src/lib/jarvis-ai.ts", "src/lib/data.ts",
        "src/lib/data-prisma.ts", "src/lib/preferences.ts", "src/lib/prompt.ts",
        "src/lib/tools/registry.ts",
    ]),
    ("State Stores (src/store)", ["src/store/app-store.ts", "src/store/images-store.ts"]),
    ("Client Hooks (src/hooks)", [
        "src/hooks/use-mobile.ts", "src/hooks/use-toast.ts", "src/hooks/use-settings.ts",
        "src/hooks/use-data.ts", "src/hooks/use-tools.ts", "src/hooks/use-supabase-setup.ts",
    ]),
    ("Providers (src/components/providers)", [
        "src/components/providers/providers.tsx", "src/components/providers/auth-provider.tsx",
    ]),
    ("JARVIS Components (src/components/jarvis)", [
        "src/components/jarvis/orb.tsx", "src/components/jarvis/sidebar.tsx",
        "src/components/jarvis/topbar.tsx", "src/components/jarvis/app-shell.tsx",
        "src/components/jarvis/markdown.tsx", "src/components/jarvis/tool-call-card.tsx",
        "src/components/jarvis/confirm-dialog.tsx", "src/components/jarvis/command-palette.tsx",
        "src/components/jarvis/task-charts.tsx", "src/components/jarvis/supabase-setup-banner.tsx",
    ]),
    ("Views (src/components/jarvis/views)", [
        "src/components/jarvis/views/dashboard.tsx", "src/components/jarvis/views/chat.tsx",
        "src/components/jarvis/views/voice.tsx", "src/components/jarvis/views/tasks.tsx",
        "src/components/jarvis/views/notes.tsx", "src/components/jarvis/views/projects.tsx",
        "src/components/jarvis/views/image-studio.tsx", "src/components/jarvis/views/memory.tsx",
        "src/components/jarvis/views/settings.tsx",
    ]),
    ("API Routes (src/app/api)", [
        "src/app/api/route.ts", "src/app/api/auth/me/route.ts",
        "src/app/api/tasks/route.ts", "src/app/api/tasks/[id]/route.ts",
        "src/app/api/notes/route.ts", "src/app/api/notes/[id]/route.ts",
        "src/app/api/notes/[id]/summarize/route.ts",
        "src/app/api/projects/route.ts", "src/app/api/projects/[id]/route.ts",
        "src/app/api/projects/[id]/plan/route.ts",
        "src/app/api/chat/sessions/route.ts", "src/app/api/chat/sessions/[id]/route.ts",
        "src/app/api/chat/sessions/[id]/messages/route.ts", "src/app/api/chat/send/route.ts",
        "src/app/api/briefing/route.ts", "src/app/api/memory/route.ts",
        "src/app/api/memory/[id]/route.ts", "src/app/api/settings/route.ts",
        "src/app/api/tools/route.ts", "src/app/api/status/route.ts",
        "src/app/api/voice/tts/route.ts", "src/app/api/images/generate/route.ts",
        "src/app/api/search/route.ts", "src/app/api/vision/route.ts",
        "src/app/api/supabase/schema/route.ts", "src/app/api/supabase/setup/route.ts",
    ]),
]


def read_file(rel_path):
    full = os.path.join(PROJECT_ROOT, rel_path)
    try:
        with open(full, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception as e:
        return f"// (could not read file: {e})"


def line_count(rel_path):
    return len(read_file(rel_path).splitlines())


def draw_cover(c, doc):
    c.setFillColor(C_BG)
    c.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
    cx, cy = A4[0] / 2, A4[1] / 2 + 30
    for i, alpha in enumerate([0.04, 0.06, 0.08, 0.10, 0.12]):
        c.setFillColor(C_PRIMARY)
        c.setFillAlpha(alpha)
        c.circle(cx, cy, 260 - i * 40, fill=1, stroke=0)
    c.setFillAlpha(1)
    c.setStrokeColor(C_PRIMARY)
    c.setLineWidth(1.5)
    c.circle(cx, cy, 70, fill=0, stroke=1)
    c.setStrokeColor(HexColor("#3b82f6"))
    c.setLineWidth(0.8)
    c.circle(cx, cy, 55, fill=0, stroke=1)
    c.setFillColor(C_PRIMARY)
    c.setFillAlpha(0.85)
    c.circle(cx, cy, 28, fill=1, stroke=0)
    c.setFillAlpha(1)

    c.setFillColor(C_TEXT)
    c.setFont("Helvetica-Bold", 38)
    c.drawCentredString(cx, 300, "JARVIS AI")
    c.setFillColor(C_PRIMARY)
    c.setFont("Helvetica", 14)
    c.drawCentredString(cx, 278, "Personal AI Assistant — Full Source Code")
    c.setStrokeColor(C_PRIMARY)
    c.setLineWidth(0.5)
    c.line(cx - 120, 264, cx + 120, 264)
    c.setFillColor(C_MUTED)
    c.setFont("Helvetica", 10)
    c.drawCentredString(cx, 246, "Next.js 16  ·  TypeScript  ·  Tailwind CSS 4  ·  shadcn/ui")
    c.drawCentredString(cx, 232, "Prisma + SQLite  ·  Supabase  ·  z-ai-web-dev-sdk")

    total_files = sum(len(files) for _, files in FILE_GROUPS)
    total_lines = sum(line_count(f) for _, files in FILE_GROUPS for f in files)
    c.setFillColor(C_TEXT)
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(cx, 180, f"{total_files} source files  ·  {total_lines:,} lines of code")

    c.setFillColor(C_MUTED)
    c.setFont("Helvetica", 8)
    c.drawCentredString(cx, 40, f"Generated {datetime.now().strftime('%Y-%m-%d')}  ·  JARVIS AI")
    c.showPage()


def draw_body_bg(c, doc):
    c.setFillColor(C_CODE_BG)
    c.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
    c.setFillColor(HexColor("#0d1117"))
    c.rect(0, A4[1] - 28, A4[0], 28, fill=1, stroke=0)
    c.setFillColor(C_MUTED)
    c.setFont("Helvetica", 8)
    c.drawString(40, A4[1] - 18, "JARVIS AI — Source Code")
    c.setFillColor(C_PRIMARY)
    c.drawRightString(A4[0] - 40, A4[1] - 18, f"p. {doc.page}")
    c.setFillColor(HexColor("#0d1117"))
    c.rect(0, 0, A4[0], 22, fill=1, stroke=0)
    c.setFillColor(C_MUTED)
    c.setFont("Helvetica", 7)
    c.drawString(40, 8, "JARVIS AI  ·  local-first personal assistant")
    c.drawRightString(A4[0] - 40, 8, f"Page {doc.page}")


def build():
    doc = SimpleDocTemplate(
        OUTPUT_PDF, pagesize=A4,
        leftMargin=1.2 * cm, rightMargin=1.2 * cm,
        topMargin=1.6 * cm, bottomMargin=1.4 * cm,
        title="JARVIS AI — Source Code", author="JARVIS AI",
        subject="Full source code of the JARVIS AI personal assistant", creator="JARVIS AI",
    )
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("H1", parent=styles["Heading1"], fontSize=16, textColor=C_PRIMARY,
                         spaceBefore=10, spaceAfter=8, fontName="Helvetica-Bold")
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=11, textColor=C_TEXT,
                         spaceBefore=6, spaceAfter=4, fontName="Helvetica-Bold")
    body = ParagraphStyle("Body", parent=styles["BodyText"], fontSize=9, textColor=C_TEXT,
                           fontName="Helvetica", leading=13)
    code_style = ParagraphStyle("Code", parent=styles["Code"], fontSize=6.8, textColor=C_TEXT,
                                 fontName="Courier", leading=8.2, backColor=C_CODE_BG,
                                 leftIndent=0, rightIndent=0, spaceBefore=2, spaceAfter=2)
    path_style = ParagraphStyle("Path", parent=body, fontSize=8.5, textColor=C_ACCENT,
                                 fontName="Courier-Bold", spaceBefore=4, spaceAfter=2)
    meta_style = ParagraphStyle("Meta", parent=body, fontSize=8, textColor=C_MUTED,
                                 fontName="Helvetica", spaceAfter=2)

    story = []
    # Table of contents
    story.append(Spacer(1, 6))
    story.append(Paragraph("Table of Contents", h1))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "This document contains the complete source code of the JARVIS AI personal assistant. "
        "shadcn/ui components in <font face='Courier'>src/components/ui/*</font> are generated library "
        "boilerplate and are omitted — they are standard shadcn/ui (New York) primitives, not "
        "project-specific code. All application, library, API, view, and configuration code is included below.",
        body))
    story.append(Spacer(1, 10))

    total_files = 0
    total_lines = 0
    for group_name, files in FILE_GROUPS:
        story.append(Paragraph(group_name, h2))
        rows = []
        for f in files:
            lc = line_count(f)
            total_files += 1
            total_lines += lc
            rows.append([f, f"{lc:,} lines"])
        tbl = Table(rows, colWidths=[12 * cm, 3 * cm])
        tbl.setStyle(TableStyle([
            ("FONTNAME", (0, 0), (-1, -1), "Courier"),
            ("FONTSIZE", (0, 0), (-1, -1), 7.5),
            ("TEXTCOLOR", (0, 0), (0, -1), C_ACCENT),
            ("TEXTCOLOR", (1, 0), (1, -1), C_MUTED),
            ("ALIGN", (1, 0), (1, -1), "RIGHT"),
            ("ROWBACKGROUNDS", (0, 0), (-1, -1), [HexColor("#0d1117"), HexColor("#161b22")]),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("LINEBELOW", (0, 0), (-1, -1), 0.25, C_BORDER),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 6))

    story.append(Spacer(1, 8))
    story.append(Paragraph(f"<b>Total: {total_files} files · {total_lines:,} lines of code</b>", meta_style))
    story.append(PageBreak())

    # File listings
    for group_name, files in FILE_GROUPS:
        story.append(Paragraph(group_name, h1))
        story.append(Spacer(1, 4))
        for rel_path in files:
            content = read_file(rel_path)
            lc = len(content.splitlines())
            story.append(KeepTogether([
                Paragraph(rel_path, path_style),
                Paragraph(f"{lc} lines", meta_style),
            ]))
            numbered = []
            for i, line in enumerate(content.splitlines(), 1):
                if len(line) > 110:
                    line = line[:107] + "..."
                safe = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                numbered.append(f"{i:>4}  {safe}")
            story.append(Preformatted("\n".join(numbered), code_style))
            story.append(Spacer(1, 8))
        story.append(PageBreak())

    doc.build(story, onFirstPage=draw_cover, onLaterPages=draw_body_bg)
    size = os.path.getsize(OUTPUT_PDF)
    print(f"Generated: {OUTPUT_PDF}")
    print(f"Size: {size:,} bytes ({size/1024/1024:.1f} MB)")
    print(f"Files: {total_files}, Lines: {total_lines:,}")


if __name__ == "__main__":
    build()
